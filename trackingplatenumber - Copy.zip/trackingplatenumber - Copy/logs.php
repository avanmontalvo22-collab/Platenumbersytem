<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    // Background refresh calls get a JSON 401 instead of a redirect (avoids JSON parse errors)
    if (isset($_GET['action']) && $_GET['action'] === 'fetch_logs_updates') {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'unauthorized']);
        exit();
    }
    header("Location: admin.php");
    exit();
}

const LOGS_PER_PAGE = 20;

$error = null;

// 1. MANUAL LOG ENTRY HANDLER (with optional snapshot upload & vehicle type support)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_entry'])) {
    $plate        = strtoupper(trim($_POST['plate_number'] ?? ''));
    $manual_name  = ucwords(strtolower(trim($_POST['manual_name'] ?? '')));
    $vehicle_type = ucwords(strtolower(trim($_POST['vehicle_type'] ?? '')));
    $action       = (isset($_POST['action']) && in_array(strtoupper($_POST['action']), ['IN', 'OUT'], true))
                    ? strtoupper($_POST['action'])
                    : 'IN';
    $photoFileName = null;

    // Optional uploaded snapshot
    if (isset($_FILES['snapshot_photo']) && $_FILES['snapshot_photo']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath       = $_FILES['snapshot_photo']['tmp_name'];
        $fileExtension     = strtolower(pathinfo($_FILES['snapshot_photo']['name'], PATHINFO_EXTENSION));
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];

        // Check the extension AND that the file really is an image
        if (in_array($fileExtension, $allowedExtensions, true) && @getimagesize($fileTmpPath) !== false) {
            if (!is_dir('camdetect')) {
                mkdir('camdetect', 0755, true);
            }

            $newFileName = 'manual_' . time() . '_' . uniqid() . '.' . $fileExtension;
            $dest_path   = 'camdetect/' . $newFileName;

            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                $photoFileName = $newFileName;
            }
        }
    }

    if (!empty($plate) && !empty($manual_name)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO logs (plate_number, manual_name, vehicle_type, action, photo, log_time) VALUES (?, ?, ?, ?, ?, NOW())");
            if ($stmt->execute([$plate, $manual_name, $vehicle_type, $action, $photoFileName])) {
                header("Location: logs.php?status=success");
                exit();
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}

// 2. FETCH LOGS DATA (IN/OUT filter + search + paging, all done in the database)
$dirFilter = (isset($_GET['dir']) && in_array($_GET['dir'], ['IN', 'OUT'], true)) ? $_GET['dir'] : '';
$searchQ   = isset($_GET['q']) ? trim($_GET['q']) : '';
$page      = max(1, (int)($_GET['page'] ?? 1));

$logs       = [];
$totalRows  = 0;
$totalPages = 1;

try {
    $where  = [];
    $params = [];

    if ($dirFilter !== '') {
        $where[]  = "action = ?";
        $params[] = $dirFilter;
    }

    if ($searchQ !== '') {
        $like = '%' . addcslashes($searchQ, '%_\\') . '%';
        $where[] = "(plate_number LIKE ? OR manual_name LIKE ? OR owner_name LIKE ? OR vehicle_type LIKE ?
                     OR brand LIKE ? OR color LIKE ? OR action LIKE ?
                     OR DATE_FORMAT(log_time, '%b %d, %Y %a %h:%i %p') LIKE ?)";
        for ($i = 0; $i < 8; $i++) { $params[] = $like; }
    }

    $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

    // Total rows -> total pages
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM logs $whereSql");
    $stmtCount->execute($params);
    $totalRows  = (int)$stmtCount->fetchColumn();
    $totalPages = max(1, (int)ceil($totalRows / LOGS_PER_PAGE));
    $page       = min($page, $totalPages);

    $limit  = (int)LOGS_PER_PAGE;
    $offset = (int)(($page - 1) * LOGS_PER_PAGE);

    $sql = "
        SELECT
            id, plate_number, manual_name, owner_name,
            vehicle_type, brand, color, log_time, action, photo
        FROM logs
        $whereSql
        ORDER BY log_time DESC, id DESC
        LIMIT $limit OFFSET $offset
    ";
    $stmtLogs = $pdo->prepare($sql);
    $stmtLogs->execute($params);
    $logs = $stmtLogs->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $logs = [];
    if (!$error) {
        $error = "Failed to load log history: " . $e->getMessage();
    }
}

// Renders the table rows. Wrapped in function_exists() so it can never be "redeclared".
if (!function_exists('renderLogRows')) {
    function renderLogRows(array $logs): string {
        if (empty($logs)) {
            return '<tr><td colspan="10" class="text-center py-5 text-muted"><i class="bi bi-journal-x fs-2 d-block mb-2 opacity-50"></i>No campus activity recorded.</td></tr>';
        }

        $html = '';
        foreach ($logs as $row) {
            $isRegistered = !empty($row['owner_name']) && $row['owner_name'] !== 'Not Registered';
            $hasPhoto     = !empty($row['photo']) && file_exists('camdetect/' . $row['photo']);
            $photoPath    = $hasPhoto ? 'camdetect/' . $row['photo'] : '';

            $timestamp = strtotime($row['log_time']);
            $fullTime  = date('M d, Y - h:i A', $timestamp);
            $timeStr   = date('h:i A', $timestamp);
            $dateStr   = date('M d, Y', $timestamp);
            $dayStr    = date('D', $timestamp);

            // Values are passed through data-attributes (safe against quotes in plate numbers)
            $dataAttrs = ' data-photo="' . htmlspecialchars($photoPath, ENT_QUOTES) . '"'
                       . ' data-plate="' . htmlspecialchars($row['plate_number'], ENT_QUOTES) . '"'
                       . ' data-time="'  . htmlspecialchars($fullTime, ENT_QUOTES) . '"';

            $html .= '<tr class="log-row" data-dir="' . htmlspecialchars($row['action'] ?? 'IN', ENT_QUOTES) . '">';

            // Photo (6%)
            $html .= '<td class="ps-3" style="width: 6%;">';
            $html .= '<button type="button" class="btn p-0 border-0 bg-transparent js-open-photo"' . $dataAttrs . '>';
            if ($hasPhoto) {
                $html .= '<img src="' . htmlspecialchars($photoPath, ENT_QUOTES) . '" class="avatar-img shadow-sm hover-zoom" alt="Cam Snapshot">';
            } else {
                $html .= '<div class="avatar-placeholder hover-zoom" title="Click to view capture info"><i class="bi bi-person-bounding-box"></i></div>';
            }
            $html .= '</button>';
            $html .= '</td>';

            // Plate (11%)
            $html .= '<td style="width: 11%;"><span class="plate-badge font-monospace">' . htmlspecialchars($row['plate_number']) . '</span></td>';

            // Type (9%)
            $html .= '<td style="width: 9%;">';
            $html .= !empty($row['vehicle_type'])
                ? '<span class="badge bg-light text-dark border px-2 py-1 small fw-semibold">' . htmlspecialchars($row['vehicle_type']) . '</span>'
                : '<span class="text-muted small">---</span>';
            $html .= '</td>';

            // Brand / status (11%)
            $html .= '<td style="width: 11%;">';
            if (!empty($row['brand']) && $row['brand'] !== 'Not Registered') {
                $html .= '<span class="fw-semibold text-dark small">' . htmlspecialchars($row['brand']) . '</span>';
            } elseif ($isRegistered) {
                $html .= '<span class="text-muted small">Registered</span>';
            } else {
                $html .= '<span class="fw-semibold text-dark small">Not Registered</span>';
            }
            $html .= '</td>';

            // Color (8%)
            $html .= '<td style="width: 8%;">';
            $html .= !empty($row['color'])
                ? '<span class="text-dark small fw-medium">' . htmlspecialchars($row['color']) . '</span>'
                : '<span class="text-muted small">---</span>';
            $html .= '</td>';

            // Owner (13%)
            $html .= '<td class="small fw-semibold text-dark" style="width: 13%;">';
            $html .= !empty($row['owner_name'])
                ? htmlspecialchars($row['owner_name'])
                : '<span class="text-muted fw-normal">Not Registered</span>';
            $html .= '</td>';

            // Manual visitor name (11%)
            $html .= '<td class="small text-muted" style="width: 11%;">';
            $html .= !empty($row['manual_name']) ? htmlspecialchars($row['manual_name']) : '--';
            $html .= '</td>';

            // IN / OUT badge (10%)
            $actionVal   = $row['action'] ?? 'IN';
            $actionClass = ($actionVal === 'IN') ? 'badge-in' : 'badge-out';
            $actionIcon  = ($actionVal === 'IN') ? 'bi-arrow-down-left-circle-fill' : 'bi-arrow-up-right-circle-fill';
            $html .= '<td class="text-center col-dir" style="width: 10%;">';
            $html .= '<span class="status-badge ' . $actionClass . '"><i class="bi ' . $actionIcon . ' me-1"></i>' . htmlspecialchars($actionVal) . '</span>';
            $html .= '</td>';

            // Date (11%)
            $html .= '<td style="width: 11%;">';
            $html .= '<div class="fw-bold text-dark small">' . $dateStr . '</div>';
            $html .= '<div class="text-muted" style="font-size: 0.725rem;">' . $dayStr . '</div>';
            $html .= '</td>';

            // Time (10%)
            $html .= '<td style="width: 10%;">';
            $html .= '<span class="fw-bold text-dark small">' . $timeStr . '</span>';
            $html .= '</td>';

            $html .= '</tr>';
        }
        return $html;
    }
}

// Renders the "Showing X-Y of Z" text and the page buttons
if (!function_exists('renderPager')) {
    function renderPager(int $page, int $totalPages, int $totalRows, int $perPage): string {
        if ($totalRows === 0) {
            return '<div class="small text-muted">No records</div>';
        }

        $from = (($page - 1) * $perPage) + 1;
        $to   = min($totalRows, $page * $perPage);

        $html  = '<div class="small text-muted">Showing <span class="fw-bold text-dark">' . $from . '&ndash;' . $to . '</span>'
               . ' of <span class="fw-bold text-dark">' . $totalRows . '</span> records</div>';

        if ($totalPages > 1) {
            // Page numbers: first, last, and 2 either side of the current page
            $pages = [];
            for ($i = 1; $i <= $totalPages; $i++) {
                if ($i === 1 || $i === $totalPages || abs($i - $page) <= 2) {
                    $pages[] = $i;
                }
            }

            $btn = function (string $label, int $target, bool $disabled, bool $active = false, string $title = '') {
                $cls = 'page-btn' . ($active ? ' active' : '') . ($disabled ? ' disabled' : '');
                return '<button type="button" class="' . $cls . '" data-page="' . $target . '"'
                     . ($disabled ? ' disabled' : '') . ($title ? ' title="' . $title . '"' : '') . '>' . $label . '</button>';
            };

            $html .= '<nav class="page-nav" aria-label="Logs pages">';
            $html .= $btn('<i class="bi bi-chevron-left"></i>', max(1, $page - 1), $page <= 1, false, 'Previous');

            $prev = 0;
            foreach ($pages as $p) {
                if ($prev && $p - $prev > 1) {
                    $html .= '<span class="page-gap">&hellip;</span>';
                }
                $html .= $btn((string)$p, $p, false, $p === $page);
                $prev = $p;
            }

            $html .= $btn('<i class="bi bi-chevron-right"></i>', min($totalPages, $page + 1), $page >= $totalPages, false, 'Next');
            $html .= '</nav>';
        }

        return $html;
    }
}

// 3. BACKGROUND REFRESH API ENDPOINT
if (isset($_GET['action']) && $_GET['action'] === 'fetch_logs_updates') {
    header('Content-Type: application/json');
    echo json_encode([
        'table_html' => renderLogRows($logs),
        'pager_html' => renderPager($page, $totalPages, $totalRows, LOGS_PER_PAGE),
        'page'       => $page,
        'total_pages'=> $totalPages
    ]);
    exit();
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Access Logs | KCC Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        /* Prevents navbar/layout shift when a page has or lacks a scrollbar */
        html {
            overflow-y: scroll;
        }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .nav-link-custom {
            color: #94a3b8;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.875rem;
        }

        .nav-link-custom:hover {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.08);
        }

        .nav-link-custom.active {
            color: #ffffff;
            background-color: #2563eb;
        }

        /* Main Container Wrapper (with smooth page-load fade-in) */
        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            animation: pageFadeIn 0.25s ease-out;
        }

        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        .search-box {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .search-box:focus-within {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        /* IN / OUT segmented filter */
        .dir-toggle {
            display: inline-flex;
            background: #f1f5f9;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 4px;
            gap: 4px;
            flex-shrink: 0;
        }

        .dir-btn {
            border: 0;
            background: transparent;
            font-weight: 700;
            font-size: 0.8rem;
            padding: 0.5rem 1.1rem;
            border-radius: 9px;
            color: var(--text-secondary);
            display: inline-flex;
            align-items: center;
            white-space: nowrap;          /* keep "OUT" on one line */
            word-break: normal;
            transition: background-color 0.2s ease, color 0.2s ease, box-shadow 0.2s ease;
        }

        .dir-btn:hover {
            color: var(--text-primary);
        }

        .dir-btn.active {
            background: #ffffff;
            color: var(--text-primary);
            box-shadow: 0 2px 6px rgba(15, 23, 42, 0.08);
        }

        .dir-btn[data-dir="IN"].active  { color: #10b981; }
        .dir-btn[data-dir="OUT"].active { color: #ef4444; }

        .table {
            margin-bottom: 0;
            table-layout: fixed;
            width: 100%;
        }

        .table thead th {
            background: #f8fafc;
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 1rem 1rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
        }

        .table tbody td {
            padding: 1rem 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
            word-break: break-word;
        }

        /* IN/OUT column: tighter padding so the badge always fits */
        .table tbody td.col-dir,
        .table thead th.col-dir {
            padding-left: 0.5rem;
            padding-right: 0.5rem;
        }

        .table tbody tr:last-child td {
            border-bottom: none;
        }

        .log-row:hover {
            background-color: #f8fafc;
        }

        .avatar-img {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 10px;
            cursor: pointer;
            transition: transform 0.2s ease;
            border: 1px solid var(--border-color);
        }

        .avatar-placeholder {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #f1f5f9;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            cursor: pointer;
            transition: transform 0.2s ease, background 0.2s ease;
            border: 1px solid var(--border-color);
        }

        .hover-zoom:hover {
            transform: scale(1.08);
            background: #e2e8f0;
        }

        .plate-badge {
            background-color: #1e293b;
            color: #38bdf8;
            padding: 0.35rem 0.75rem;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.825rem;
            letter-spacing: 0.05em;
            display: inline-block;
            border: 1px solid #334155;
        }

        .status-badge {
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0.35rem 0.85rem;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            white-space: nowrap;          /* never wrap the badge text */
            word-break: normal;           /* ignore the table's break-word rule */
        }

        .badge-in {
            background-color: #10b981;
            color: #ffffff;
        }

        .badge-out {
            background-color: #ef4444;
            color: #ffffff;
        }

        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }

        .btn-primary-custom:hover {
            background-color: var(--accent-blue-hover);
            color: #ffffff;
        }

        .btn-report {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            background: #ffffff;
            font-weight: 600;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-report:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--text-primary);
        }

        .pulse-icon {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #ef4444;
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
            animation: pulse-red 2s infinite;
        }

        @keyframes pulse-red {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(239, 68, 68, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }

        .offcanvas-photo {
            width: 420px !important;
            max-width: 100vw;
            border-top-left-radius: 20px;
            border-bottom-left-radius: 20px;
            border: none;
            box-shadow: -10px 0 30px rgba(0, 0, 0, 0.1);
        }

        /* ---------- Pagination ---------- */
        .pager-bar {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            padding: 0.9rem 1.25rem;
            border-top: 1px solid var(--border-color);
            background: #ffffff;
        }

        .page-nav {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            flex-wrap: wrap;
        }

        .page-btn {
            min-width: 36px;
            height: 36px;
            padding: 0 0.6rem;
            border: 1px solid var(--border-color);
            background: #ffffff;
            color: var(--text-primary);
            font-weight: 700;
            font-size: 0.8rem;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease;
        }

        .page-btn:hover:not(.disabled):not(.active) {
            background: #f1f5f9;
            border-color: #cbd5e1;
        }

        .page-btn.active {
            background: var(--accent-blue);
            border-color: var(--accent-blue);
            color: #ffffff;
        }

        .page-btn.disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }

        .page-gap {
            color: var(--text-secondary);
            padding: 0 0.25rem;
            font-weight: 700;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo" onerror="this.style.display='none'">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>

        <div class="d-none d-md-flex align-items-center gap-2">
            <a href="dashboard.php" class="nav-link-custom"><i class="bi bi-house-door me-1"></i> Overview</a>
            <a href="owner_list.php" class="nav-link-custom"><i class="bi bi-people me-1"></i> Owners</a>
            <a href="vehicle_list.php" class="nav-link-custom"><i class="bi bi-car-front me-1"></i> Vehicles</a>
            <a href="logs.php" class="nav-link-custom active"><i class="bi bi-journal-text me-1"></i> Logs</a>
        </div>

        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<main class="main-container">
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark">Vehicle Access Logs</h4>
            <p class="text-muted mb-0 small">Real-time telemetry and entry records for campus vehicles.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="monthlyreport.php" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                <i class="bi bi-file-earmark-bar-graph me-2"></i> Reports
            </a>
            <button class="btn btn-primary-custom rounded-3 px-3 py-2 text-sm d-flex align-items-center" data-bs-toggle="modal" data-bs-target="#manualEntryModal">
                <i class="bi bi-plus-lg me-2"></i> Manual Entry
            </button>
        </div>
    </header>

    <?php if (isset($_GET['status']) && $_GET['status'] === 'success'): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-3 mb-4 d-flex align-items-center py-2 px-3" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <div class="fw-medium small">Log entry added successfully.</div>
            <button type="button" class="btn-close ms-auto small" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-3 mb-4 d-flex align-items-center py-2 px-3" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <div class="fw-medium small"><?= htmlspecialchars($error) ?></div>
            <button type="button" class="btn-close ms-auto small" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Search + IN / OUT filter -->
    <div class="dashboard-card p-2 mb-4">
        <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2">
            <div class="search-box d-flex align-items-center px-3 py-1 flex-grow-1">
                <i class="bi bi-search text-muted fs-6 me-2"></i>
                <input type="text" id="liveSearch" class="form-control border-0 shadow-none py-2 bg-transparent text-sm" placeholder="Search plate, type, color, owner, date, or visitor..." autocomplete="off" value="<?= htmlspecialchars($searchQ, ENT_QUOTES) ?>">
            </div>

            <div class="dir-toggle" id="dirToggle" role="group" aria-label="Filter by direction">
                <button type="button" class="dir-btn <?= $dirFilter === '' ? 'active' : '' ?>" data-dir="">
                    <i class="bi bi-list-ul me-1"></i> All
                </button>
                <button type="button" class="dir-btn <?= $dirFilter === 'IN' ? 'active' : '' ?>" data-dir="IN">
                    <i class="bi bi-arrow-down-left-circle-fill me-1"></i> IN
                </button>
                <button type="button" class="dir-btn <?= $dirFilter === 'OUT' ? 'active' : '' ?>" data-dir="OUT">
                    <i class="bi bi-arrow-up-right-circle-fill me-1"></i> OUT
                </button>
            </div>
        </div>
    </div>

    <div class="dashboard-card overflow-hidden">
        <div class="p-3 border-bottom bg-white d-flex align-items-center gap-2">
            <span class="pulse-icon"></span>
            <h6 class="fw-bold mb-0 text-dark">Live Traffic Activity</h6>
        </div>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th class="ps-3" style="width: 6%;">PHOTO</th>
                        <th style="width: 11%;">PLATE</th>
                        <th style="width: 9%;">TYPE</th>
                        <th style="width: 11%;">BRAND</th>
                        <th style="width: 8%;">COLOR</th>
                        <th style="width: 13%;">OWNER</th>
                        <th style="width: 11%;">MANUAL ENTRY</th>
                        <th class="text-center col-dir" style="width: 10%;">IN/OUT</th>
                        <th style="width: 11%;">DATE</th>
                        <th style="width: 10%;">TIME</th>
                    </tr>
                </thead>
                <tbody id="liveTrafficFeed">
                    <?= renderLogRows($logs) ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="pager-bar" id="pagerBar">
            <?= renderPager($page, $totalPages, $totalRows, LOGS_PER_PAGE) ?>
        </div>
    </div>
</main>

<!-- SLIDE-IN OVERLAY / OFFCANVAS FOR CAMDETECT PHOTO -->
<div class="offcanvas offcanvas-end offcanvas-photo" tabindex="-1" id="photoOffcanvas" aria-labelledby="photoOffcanvasLabel">
    <div class="offcanvas-header border-bottom py-3">
        <h6 class="offcanvas-title fw-bold text-dark mb-0" id="photoOffcanvasLabel"><i class="bi bi-camera me-2 text-primary"></i>Snapshot Preview</h6>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body p-4 text-center">
        <div class="mb-3 text-start">
            <span class="badge bg-dark font-monospace fs-6 px-3 py-2" id="drawerPlateNum">---</span>
            <span class="text-muted small d-block mt-2" id="drawerTimestamp"><i class="bi bi-clock me-1"></i>---</span>
        </div>

        <div id="drawerPhotoContainer" class="p-2 border rounded-3 bg-light shadow-sm">
            <!-- Captured image dynamically loaded via JS -->
        </div>

        <a id="drawerDownloadBtn" href="#" download class="btn btn-primary-custom w-100 rounded-3 py-2 mt-4 fw-bold text-sm">
            <i class="bi bi-download me-2"></i> Download Image
        </a>
    </div>
</div>

<!-- MANUAL ENTRY MODAL -->
<div class="modal fade" id="manualEntryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-3 border-0 shadow-lg" style="border-radius: 16px;">
            <div class="modal-header border-0 pb-0">
                <h6 class="fw-bold text-dark mb-0"><i class="bi bi-pencil-square text-primary me-2"></i>Manual Entry Registration</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body py-3">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Full Name (Visitor / Guest)</label>
                        <input type="text" name="manual_name" class="form-control text-sm rounded-3 py-2" placeholder="e.g. Juan Dela Cruz" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Plate Number</label>
                        <input type="text" name="plate_number" class="form-control text-sm font-monospace text-uppercase rounded-3 py-2" placeholder="e.g. ABC1234" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Vehicle Type</label>
                        <select name="vehicle_type" class="form-select text-sm rounded-3 py-2">
                            <option value="">Select Type (Optional)</option>
                            <option value="Car">Car</option>
                            <option value="Motorcycle">Motorcycle</option>
                            <option value="SUV">SUV</option>
                            <option value="Van">Van</option>
                            <option value="Truck">Truck</option>
                            <option value="Tricycle">Tricycle</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Optional Snapshot Capture</label>
                        <input type="file" name="snapshot_photo" class="form-control text-sm rounded-3 py-2" accept="image/*">
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold text-secondary">Gate Direction</label>
                        <div class="d-flex gap-3">
                            <input type="radio" class="btn-check" name="action" id="act_in" value="IN" checked>
                            <label class="btn btn-outline-success w-100 py-2 rounded-3 fw-bold border-1 text-sm text-nowrap" for="act_in"><i class="bi bi-arrow-down-left-circle me-1"></i> IN</label>
                            <input type="radio" class="btn-check" name="action" id="act_out" value="OUT">
                            <label class="btn btn-outline-danger w-100 py-2 rounded-3 fw-bold border-1 text-sm text-nowrap" for="act_out"><i class="bi bi-arrow-up-right-circle me-1"></i> OUT</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-3 px-3 py-2 text-sm fw-medium text-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="manual_entry" class="btn btn-primary-custom rounded-3 px-4 py-2 text-sm fw-bold">Save Entry</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Current view state: IN/OUT filter ('' = all), page number, search text
    let currentDir   = <?= json_encode($dirFilter); ?>;
    let currentPage  = <?= (int)$page; ?>;
    let currentQuery = <?= json_encode($searchQ); ?>;
    let loadToken    = 0;   // ignore out-of-date responses

    // Escape text before putting it into innerHTML
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function openPhotoDrawer(photoUrl, plate, timestamp) {
        document.getElementById('drawerPlateNum').textContent = plate;
        document.getElementById('drawerTimestamp').innerHTML = '<i class="bi bi-clock me-1"></i> ' + escapeHtml(timestamp);

        const photoContainer = document.getElementById('drawerPhotoContainer');
        const downloadBtn = document.getElementById('drawerDownloadBtn');

        if (photoUrl !== "") {
            photoContainer.innerHTML = '<img src="' + escapeHtml(photoUrl) + '" class="img-fluid rounded-3 shadow-sm w-100" alt="Detection Capture">';
            downloadBtn.href = photoUrl;
            downloadBtn.classList.remove('disabled');
        } else {
            photoContainer.innerHTML =
                '<div class="py-5 text-muted">' +
                    '<i class="bi bi-camera-video-off fs-1 opacity-50 d-block mb-2"></i>' +
                    'No camera snapshot available.' +
                '</div>';
            downloadBtn.href = "#";
            downloadBtn.classList.add('disabled');
        }

        bootstrap.Offcanvas.getOrCreateInstance(document.getElementById('photoOffcanvas')).show();
    }

    // Event delegation: keeps working after the table is refreshed in the background
    document.getElementById('liveTrafficFeed').addEventListener('click', function (e) {
        const btn = e.target.closest('.js-open-photo');
        if (!btn) return;
        openPhotoDrawer(btn.dataset.photo || '', btn.dataset.plate || '', btn.dataset.time || '');
    });

    // Keep the address bar in sync so refresh / back keeps the same view
    function syncUrl() {
        const p = new URLSearchParams();
        if (currentDir !== '')    p.set('dir', currentDir);
        if (currentQuery !== '')  p.set('q', currentQuery);
        if (currentPage > 1)      p.set('page', currentPage);
        const qs = p.toString();
        history.replaceState(null, '', window.location.pathname + (qs ? '?' + qs : ''));
    }

    // Load the table for the current filter / search / page
    function loadLogs() {
        const token = ++loadToken;

        const p = new URLSearchParams();
        p.set('action', 'fetch_logs_updates');
        if (currentDir !== '')   p.set('dir', currentDir);
        if (currentQuery !== '') p.set('q', currentQuery);
        p.set('page', currentPage);

        return fetch(window.location.pathname + '?' + p.toString(), { cache: 'no-store' })
            .then(function (response) {
                if (response.status === 401) {
                    // Session expired: send the user back to the login page
                    window.location.href = 'admin.php';
                    throw new Error('Session expired');
                }
                return response.json();
            })
            .then(function (data) {
                if (token !== loadToken) return;   // a newer request is already in flight

                document.getElementById('liveTrafficFeed').innerHTML = data.table_html;
                document.getElementById('pagerBar').innerHTML = data.pager_html;
                currentPage = data.page;           // server clamps the page if it no longer exists
                syncUrl();
            })
            .catch(function (err) { console.warn('Telemetry stream dropped: ', err); });
    }

    // Search (server-side, so it covers every page). Debounced while typing.
    let searchTimer = null;
    document.getElementById('liveSearch').addEventListener('input', function () {
        clearTimeout(searchTimer);
        const value = this.value.trim();
        searchTimer = setTimeout(function () {
            currentQuery = value;
            currentPage = 1;
            loadLogs();
        }, 300);
    });

    // IN / OUT filter buttons
    document.getElementById('dirToggle').addEventListener('click', function (e) {
        const btn = e.target.closest('.dir-btn');
        if (!btn) return;

        currentDir = btn.dataset.dir || '';
        currentPage = 1;
        document.querySelectorAll('#dirToggle .dir-btn').forEach(function (b) {
            b.classList.toggle('active', b === btn);
        });
        loadLogs();
    });

    // Page buttons
    document.getElementById('pagerBar').addEventListener('click', function (e) {
        const btn = e.target.closest('.page-btn');
        if (!btn || btn.disabled) return;

        currentPage = parseInt(btn.dataset.page, 10) || 1;
        loadLogs().then(function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    // Background refresh every 5 seconds (keeps the current filter, search and page)
    setInterval(function () {
        const modal = document.getElementById('manualEntryModal');
        const offcanvas = document.getElementById('photoOffcanvas');

        const isModalOpen = modal ? modal.classList.contains('show') : false;
        const isOffcanvasOpen = offcanvas ? offcanvas.classList.contains('show') : false;

        if (document.hidden || isModalOpen || isOffcanvasOpen) return;

        loadLogs();
    }, 5000);
</script>
</body>
</html>