<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));

// One-time message from backup.php (shown only if a backup failed)
$flashError = $_SESSION['flash_error'] ?? '';
unset($_SESSION['flash_error']);

try {
    $total_owners = $pdo->query("SELECT COUNT(*) FROM owners")->fetchColumn() ?: 0;
    $total_vehicles = $pdo->query("SELECT COUNT(*) FROM vehicles")->fetchColumn() ?: 0;
    
    // Query to count only today's logs
    $stmtTodayLogs = $pdo->query("
        SELECT COUNT(*) FROM logs 
        WHERE DATE(log_time) = CURRENT_DATE()
    ");
    $total_logs = $stmtTodayLogs->fetchColumn() ?: 0;

    // Direct query on logs table matching schema
    $stmtRecent = $pdo->query("
        SELECT 
            id, plate_number, manual_name, owner_name, 
            vehicle_type, brand, color, log_time, action, photo
        FROM logs 
        ORDER BY log_time DESC 
        LIMIT 10
    ");
    $recent_activities = $stmtRecent->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { 
    $recent_activities = []; 
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KCC Tracking | Dashboard</title>
    <!-- Bootstrap CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bs-body-bg: #f0f4f8;
            --bs-body-font-family: 'Plus Jakarta Sans', sans-serif;
            --accent-blue: #2563eb;
        }

        body {
            font-family: var(--bs-body-font-family);
            background-color: var(--bs-body-bg);
            color: #1e293b;
        }

        /* Nav Header Standardized Sizing */
        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
        }

        .stat-card-link {
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .stat-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
        }

        .card-owners::before { background: #2563eb; }
        .card-vehicles::before { background: #10b981; }
        .card-logs::before { background: #f59e0b; }

        .stat-card-link:hover .stat-card {
            transform: translateY(-5px);
            box-shadow: 0 12px 20px -3px rgba(0, 0, 0, 0.1);
        }

        .icon-shape {
            width: 58px;
            height: 58px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            margin-right: 1.25rem;
        }

        .icon-owners { background: rgba(37, 99, 235, 0.12); color: #2563eb; }
        .icon-vehicles { background: rgba(16, 185, 129, 0.12); color: #10b981; }
        .icon-logs { background: rgba(245, 158, 11, 0.12); color: #d97706; }

        .glass-panel {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
        }

        .table thead th {
            background-color: #f8fafc;
            color: #475569;
            font-size: 0.75rem;
            letter-spacing: 0.08em;
            padding: 1.1rem 1rem;
            border-bottom: 2px solid #e2e8f0;
        }

        .table tbody td {
            padding: 1.1rem 1rem;
            border-bottom: 1px solid #f1f5f9;
        }

        .plate-badge {
            font-family: 'Courier New', Courier, monospace;
            background-color: #1e293b;
            color: #38bdf8;
            padding: 0.4rem 0.75rem;
            border-radius: 6px;
            font-size: 0.85rem;
            border: 1px solid #334155;
        }

        .color-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            background-color: #f1f5f9;
            border: 1px solid #cbd5e1;
            padding: 0.25rem 0.6rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            color: #334155;
        }

        .color-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            border: 1px solid rgba(0, 0, 0, 0.2);
        }

        .action-badge {
            font-weight: 700;
            font-size: 0.75rem;
            padding: 0.45rem 1rem;
            border-radius: 50rem;
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            white-space: nowrap;
        }

        .action-badge.action-in { background-color: #10b981; color: #ffffff; }
        .action-badge.action-out { background-color: #ef4444; color: #ffffff; }

        .btn-backup {
            background-color: #2563eb;
            color: #ffffff;
            border: none;
            font-weight: 600;
            white-space: nowrap;
            transition: background-color 0.2s ease;
        }

        .btn-backup:hover:not(:disabled) { background-color: #1d4ed8; color: #ffffff; }
        .btn-backup:disabled { opacity: 0.75; }

        .live-dot {
            width: 10px;
            height: 10px;
            background-color: #ef4444;
            border-radius: 50%;
            display: inline-block;
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
            animation: pulse-red 2s infinite;
        }

        @keyframes pulse-red {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }
    </style>

    <script>
        // Auto-refresh every 5 seconds, but never while a backup is being prepared
        let backingUp = false;
        setTimeout(function reloadLater() {
            if (backingUp) { setTimeout(reloadLater, 2000); return; }
            window.location.reload(1);
        }, 5000);
    </script>
</head>
<body>

<!-- Unified Header Navigation -->
<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<main class="main-container">
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h2 class="fw-bold mb-1">KCC Dashboard</h2>
            <p class="text-muted small mb-0">Live monitoring of campus vehicle access.</p>
        </div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <!-- BACKUP: saves the database + camdetect files into one .zip download -->
            <form method="POST" action="backup.php" id="backupForm" class="m-0">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="token" id="backupToken" value="">
                <button type="submit" id="backupBtn" class="btn btn-backup rounded-pill px-3 py-2 shadow-sm"
                        title="Download a backup of the database and photo files">
                    <i class="bi bi-cloud-arrow-down-fill me-2"></i><span id="backupLabel">Backup Now</span>
                </button>
            </form>

            <div class="bg-white border border-primary border-opacity-25 px-3 py-2 rounded-pill shadow-sm">
                <i class="bi bi-calendar3 text-primary me-2"></i>
                <span class="small fw-bold text-primary"><?= date('l, F j, Y'); ?></span>
            </div>
        </div>
    </header>

    <?php if ($flashError !== ''): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-3 mb-4 d-flex align-items-center py-2 px-3" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <div class="fw-medium small"><?= htmlspecialchars($flashError) ?></div>
            <button type="button" class="btn-close ms-auto small" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <a href="owner_list.php" class="stat-card-link">
                <div class="stat-card card-owners">
                    <div class="icon-shape icon-owners"><i class="bi bi-people-fill"></i></div>
                    <div>
                        <h6 class="text-muted mb-1 small fw-bold text-uppercase">Total Owners</h6>
                        <h3 class="fw-bold mb-0 text-dark"><?= number_format($total_owners); ?></h3>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="vehicle_list.php" class="stat-card-link">
                <div class="stat-card card-vehicles">
                    <div class="icon-shape icon-vehicles"><i class="bi bi-car-front-fill"></i></div>
                    <div>
                        <h6 class="text-muted mb-1 small fw-bold text-uppercase">Total Vehicles</h6>
                        <h3 class="fw-bold mb-0 text-dark"><?= number_format($total_vehicles); ?></h3>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="logs.php" class="stat-card-link">
                <div class="stat-card card-logs">
                    <div class="icon-shape icon-logs"><i class="bi bi-clock-history"></i></div>
                    <div>
                        <h6 class="text-muted mb-1 small fw-bold text-uppercase">Logs Today</h6>
                        <h3 class="fw-bold mb-0 text-dark"><?= number_format($total_logs); ?></h3>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="glass-panel">
        <div class="p-3 px-4 border-bottom d-flex justify-content-between align-items-center bg-white">
            <h5 class="fw-bold mb-0 d-flex align-items-center gap-2">
                <span class="live-dot"></span>
                <span>Live Traffic Feed</span>
            </h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr class="fw-bold">
                        <th class="ps-4">PHOTO</th>
                        <th>PLATE</th>
                        <th>BRAND</th>
                        <th>COLOR</th>
                        <th>OWNER</th>
                        <th>MANUAL ENTRY</th>
                        <th class="text-center">IN/OUT</th>
                        <th>TIME</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($recent_activities): foreach($recent_activities as $row): 
                        $is_in = strtoupper(trim($row['action'])) === 'IN';
                        $color_name = htmlspecialchars($row['color'] ?? '');
                    ?>
                    <tr>
                        <td class="ps-4">
                            <?php if(!empty($row['photo']) && file_exists("camdetect/".$row['photo'])): ?>
                                <img src="camdetect/<?= htmlspecialchars($row['photo'], ENT_QUOTES) ?>" class="shadow-sm border border-primary border-opacity-25" style="width:42px; height:42px; object-fit:cover; border-radius:10px;">
                            <?php else: ?>
                                <div class="bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-3 d-flex align-items-center justify-content-center" style="width:42px; height:42px;">
                                    <i class="bi bi-person-bounding-box fs-5"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><span class="plate-badge fw-bold"><?= htmlspecialchars($row['plate_number']) ?></span></td>
                        
                        <td class="fw-semibold text-dark small"><?= !empty($row['brand']) ? htmlspecialchars($row['brand']) : '---' ?></td>
                        
                        <td>
                            <?php if(!empty($color_name) && $color_name !== 'NULL'): ?>
                                <span class="color-badge">
                                    <span class="color-dot" style="background-color: <?= strtolower($color_name) ?>;"></span>
                                    <?= $color_name ?>
                                </span>
                            <?php else: ?>
                                <span class="text-muted small">---</span>
                            <?php endif; ?>
                        </td>

                        <td class="small fw-bold text-dark">
                            <?= !empty($row['owner_name']) ? htmlspecialchars($row['owner_name']) : '<span class="text-muted fw-normal">--</span>' ?>
                        </td>

                        <td class="small text-primary">
                            <?= !empty($row['manual_name']) ? htmlspecialchars($row['manual_name']) : '<span class="text-muted">--</span>' ?>
                        </td>

                        <td class="text-center">
                            <span class="action-badge <?= $is_in ? 'action-in' : 'action-out' ?>">
                                <i class="bi <?= $is_in ? 'bi-arrow-down-left-circle-fill' : 'bi-arrow-up-right-circle-fill' ?>"></i>
                                <?= strtoupper($row['action']) ?>
                            </span>
                        </td>
                        <td>
                            <div class="fw-bold text-dark small"><?= date('h:i A', strtotime($row['log_time'])) ?></div>
                            <div class="text-primary fw-semibold" style="font-size: 0.72rem;"><?= date('M d, Y', strtotime($row['log_time'])) ?></div>
                        </td>
                    </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="8" class="text-center py-5 text-muted">No campus activity recorded.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Backup button: shows "Preparing..." until the browser starts the .zip download
    (function () {
        const form  = document.getElementById('backupForm');
        const btn   = document.getElementById('backupBtn');
        const label = document.getElementById('backupLabel');
        const icon  = btn.querySelector('i');

        form.addEventListener('submit', function () {
            const token = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
            document.getElementById('backupToken').value = token;

            backingUp = true;                 // pauses the 5-second auto refresh
            btn.disabled = true;
            icon.className = 'spinner-border spinner-border-sm me-2';
            label.textContent = 'Preparing backup...';

            // The server sets a cookie with this token as soon as the download starts
            const timer = setInterval(function () {
                if (document.cookie.indexOf('backup_done=' + token) !== -1) {
                    clearInterval(timer);
                    document.cookie = 'backup_done=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/';
                    backingUp = false;
                    btn.disabled = false;
                    icon.className = 'bi bi-check-circle-fill me-2';
                    label.textContent = 'Backup saved';
                    setTimeout(function () {
                        icon.className = 'bi bi-cloud-arrow-down-fill me-2';
                        label.textContent = 'Backup Now';
                    }, 3000);
                }
            }, 400);
        });
    })();
</script>
</body>
</html>