<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    // Background calls get a JSON 401 instead of a redirect
    if (isset($_GET['action'])) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'unauthorized']);
        exit();
    }
    header("Location: admin.php");
    exit();
}

// ---------------------------------------------------------------
// SOFT DELETE SETUP: owners are kept for 30 days after deletion
// ---------------------------------------------------------------
const DELETE_RETENTION_DAYS = 30;

// Make sure the owners table has a deleted_at column (added once, automatically)
try {
    $pdo->query("SELECT deleted_at FROM owners LIMIT 1");
} catch (PDOException $e) {
    try {
        $pdo->exec("ALTER TABLE owners ADD COLUMN deleted_at DATETIME NULL DEFAULT NULL");
    } catch (PDOException $e2) {
        die("Database error: could not add deleted_at column. " . $e2->getMessage());
    }
}

// Permanently removes one owner row and their uploaded photos
function purgeOwner(PDO $pdo, int $ownerId): void
{
    $find = $pdo->prepare("SELECT photo, license_photo FROM owners WHERE id = ?");
    $find->execute([$ownerId]);
    $row = $find->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        foreach (['photo', 'license_photo'] as $col) {
            if (!empty($row[$col])) {
                $path = "uploads/" . $row[$col];
                if (file_exists($path)) @unlink($path);
            }
        }
    }

    $del = $pdo->prepare("DELETE FROM owners WHERE id = ?");
    $del->execute([$ownerId]);
}

// Auto-purge: anything deleted more than 30 days ago is removed for good
try {
    $cutoff = date('Y-m-d H:i:s', strtotime('-' . DELETE_RETENTION_DAYS . ' days'));
    $expired = $pdo->prepare("SELECT id FROM owners WHERE deleted_at IS NOT NULL AND deleted_at < ?");
    $expired->execute([$cutoff]);
    foreach ($expired->fetchAll(PDO::FETCH_COLUMN) as $expiredId) {
        purgeOwner($pdo, (int)$expiredId);
    }
} catch (PDOException $e) {
    // A failed cleanup should never break the page
}

// 0. OWNER ACTION LOGS ENDPOINT (called when the Logs button is tapped)
if (isset($_GET['action']) && $_GET['action'] === 'owner_logs') {
    header('Content-Type: application/json');
    $oid = (int)($_GET['id'] ?? 0);

    try {
        $stmtOwner = $pdo->prepare("SELECT firstname, middlename, lastname, id_number FROM owners WHERE id = ?");
        $stmtOwner->execute([$oid]);
        $ownerRow = $stmtOwner->fetch(PDO::FETCH_ASSOC);

        if (!$ownerRow) {
            echo json_encode(['ok' => false, 'error' => 'Owner not found.']);
            exit();
        }

        $fullName = trim($ownerRow['firstname'] . ' ' . ($ownerRow['middlename'] ? $ownerRow['middlename'] . ' ' : '') . $ownerRow['lastname']);

        // Vehicles registered to this owner
        $stmtV = $pdo->prepare("SELECT plate_number, brand, model FROM vehicles WHERE owner_id = ? ORDER BY id DESC");
        $stmtV->execute([$oid]);
        $ownerVehicles = $stmtV->fetchAll(PDO::FETCH_ASSOC);

        // Logs for those vehicles (plate matched ignoring spaces, dashes and letter case)
        $stmtL = $pdo->prepare("
            SELECT l.plate_number, l.action, l.log_time, l.photo
            FROM logs l
            INNER JOIN vehicles v
                    ON REPLACE(REPLACE(UPPER(v.plate_number), ' ', ''), '-', '')
                     = REPLACE(REPLACE(UPPER(l.plate_number), ' ', ''), '-', '')
            WHERE v.owner_id = ?
            ORDER BY l.log_time DESC
            LIMIT 200
        ");
        $stmtL->execute([$oid]);
        $ownerLogs = $stmtL->fetchAll(PDO::FETCH_ASSOC);

        $totalIn = 0;
        $totalOut = 0;
        $rowsHtml = '';

        foreach ($ownerLogs as $r) {
            $ts   = strtotime($r['log_time']);
            $isIn = ($r['action'] ?? '') === 'IN';
            $isIn ? $totalIn++ : $totalOut++;

            $hasPhoto = !empty($r['photo']) && file_exists('camdetect/' . $r['photo']);
            $photoUrl = $hasPhoto ? 'camdetect/' . htmlspecialchars($r['photo'], ENT_QUOTES) : '';

            $rowsHtml .= '<tr class="drawer-log-row" data-dir="' . ($isIn ? 'IN' : 'OUT') . '">'
                . '<td><div class="fw-bold small text-dark">' . date('M d, Y', $ts) . '</div>'
                .   '<div class="text-muted" style="font-size: 0.7rem;">' . date('D', $ts) . '</div></td>'
                . '<td class="small fw-bold text-dark">' . date('h:i A', $ts) . '</td>'
                . '<td><span class="plate-badge">' . htmlspecialchars($r['plate_number']) . '</span></td>'
                . '<td class="text-center"><span class="status-badge ' . ($isIn ? 'badge-in' : 'badge-out') . '">'
                .   '<i class="bi ' . ($isIn ? 'bi-arrow-down-left-circle-fill' : 'bi-arrow-up-right-circle-fill') . ' me-1"></i>'
                .   ($isIn ? 'IN' : 'OUT') . '</span></td>'
                . '<td class="text-center">'
                .   ($hasPhoto
                        ? '<a href="' . $photoUrl . '" target="_blank" title="View snapshot"><img src="' . $photoUrl . '" class="drawer-thumb" alt="Snapshot" loading="lazy"></a>'
                        : '<span class="text-muted small">---</span>')
                . '</td>'
                . '</tr>';
        }

        $lastSeen = !empty($ownerLogs) ? date('M d, Y h:i A', strtotime($ownerLogs[0]['log_time'])) : '---';

        echo json_encode([
            'ok'         => true,
            'name'       => $fullName,
            'id_number'  => $ownerRow['id_number'],
            'vehicles'   => $ownerVehicles,
            'total'      => count($ownerLogs),
            'in'         => $totalIn,
            'out'        => $totalOut,
            'last_seen'  => $lastSeen,
            'rows_html'  => $rowsHtml
        ]);
    } catch (PDOException $e) {
        echo json_encode(['ok' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
    exit();
}

// 1. DELETE / RESTORE / PERMANENT DELETE LOGIC
// Delete = move to "Recently Deleted"; it is purged automatically after 30 days.
if (isset($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];
    $mark = $pdo->prepare("UPDATE owners SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL");
    $mark->execute([date('Y-m-d H:i:s'), $delete_id]);
    header("Location: owner_list.php");
    exit();
}

if (isset($_GET['restore'])) {
    $restore_id = (int)$_GET['restore'];
    $res = $pdo->prepare("UPDATE owners SET deleted_at = NULL WHERE id = ?");
    $res->execute([$restore_id]);
    header("Location: owner_list.php?view=trash");
    exit();
}

if (isset($_GET['purge'])) {
    $purge_id = (int)$_GET['purge'];
    // Only owners already in Recently Deleted can be permanently removed
    $chk = $pdo->prepare("SELECT id FROM owners WHERE id = ? AND deleted_at IS NOT NULL");
    $chk->execute([$purge_id]);
    if ($chk->fetch()) {
        purgeOwner($pdo, $purge_id);
    }
    header("Location: owner_list.php?view=trash");
    exit();
}

// 2. SEARCH LOGIC
$isTrash = (isset($_GET['view']) && $_GET['view'] === 'trash');
$search  = isset($_GET['search']) ? trim($_GET['search']) : '';
$deletedClause = $isTrash ? "deleted_at IS NOT NULL" : "deleted_at IS NULL";
$orderBy = $isTrash ? "deleted_at DESC" : "id DESC";

try {
    if (!empty($search)) {
        // Filtered Query (Includes email, address, license_number, and name search)
        $sql = "SELECT * FROM owners WHERE $deletedClause AND (
                firstname LIKE ? OR 
                lastname LIKE ? OR 
                middlename LIKE ? OR 
                id_number LIKE ? OR 
                license_number LIKE ? OR 
                phone_number LIKE ? OR 
                email LIKE ? OR 
                address LIKE ?
                ) ORDER BY $orderBy";
        $stmt = $pdo->prepare($sql);
        $searchTerm = "%$search%";
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    } else {
        // Default Query
        $stmt = $pdo->query("SELECT * FROM owners WHERE $deletedClause ORDER BY $orderBy");
    }
    $owners = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Count of owners waiting in Recently Deleted (for the header button)
    $trashCount = (int)$pdo->query("SELECT COUNT(*) FROM owners WHERE deleted_at IS NOT NULL")->fetchColumn();
} catch(PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Owners | KCC Tracking</title>
    <!-- Bootstrap 5 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        /* Prevents navbar/layout shift when a page has or lacks a scrollbar */
        html {
            overflow-y: scroll;
        }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        /* Top Navigation Header Bar */
        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .nav-link-custom {
            color: #94a3b8;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.875rem;
        }

        .nav-link-custom:hover {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.08);
        }

        .nav-link-custom.active {
            color: #ffffff;
            background-color: #2563eb;
        }

        /* Main Container Wrapper (with smooth page-load fade-in) */
        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            animation: pageFadeIn 0.25s ease-out;
        }

        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        /* Search Box */
        .search-box {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .search-box:focus-within {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        /* Table Styling */
        .table {
            margin-bottom: 0;
            width: 100%;
        }

        .table thead th {
            background: #f8fafc;
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 1rem 1rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
        }

        .table tbody td {
            padding: 1.1rem 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }

        .table tbody tr:last-child td {
            border-bottom: none;
        }

        .owner-row:hover {
            background-color: #f8fafc;
        }

        /* Avatar Styling */
        .owner-img {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid var(--border-color);
            transition: transform 0.2s ease;
        }

        .img-placeholder {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #f1f5f9;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            border: 1px solid var(--border-color);
            transition: transform 0.2s ease, background 0.2s ease;
        }

        .hover-zoom:hover {
            transform: scale(1.08);
            background: #e2e8f0;
        }

        /* License Photo Thumbnail */
        .license-img-thumb {
            width: 54px;
            height: 36px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            transition: transform 0.2s ease;
        }

        .license-img-thumb:hover {
            transform: scale(1.08);
        }

        /* Type Badge */
        .type-badge {
            font-size: 0.7rem;
            font-weight: 700;
            padding: 0.35em 0.7em;
            border-radius: 8px;
            text-transform: uppercase;
        }

        /* Action Buttons */
        .btn-action {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: all 0.2s ease-in-out;
            font-size: 0.95rem;
            border: 0;
            padding: 0;
            cursor: pointer;
        }

        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }

        .btn-primary-custom:hover {
            background-color: var(--accent-blue-hover);
            color: #ffffff;
        }

        .btn-report {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            background: #ffffff;
            font-weight: 600;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-report:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--text-primary);
        }

        /* ---------- Action logs drawer ---------- */
        .offcanvas-logs {
            width: 560px !important;
            max-width: 100vw;
            border-top-left-radius: 20px;
            border-bottom-left-radius: 20px;
            border: none;
            box-shadow: -10px 0 30px rgba(0, 0, 0, 0.1);
        }

        .plate-badge {
            background-color: #1e293b;
            color: #38bdf8;
            padding: 0.3rem 0.65rem;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.78rem;
            letter-spacing: 0.05em;
            display: inline-block;
            border: 1px solid #334155;
            font-family: monospace;
        }

        .status-badge {
            font-size: 0.72rem;
            font-weight: 700;
            padding: 0.3rem 0.75rem;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
        }

        .badge-in  { background-color: #10b981; color: #ffffff; }
        .badge-out { background-color: #ef4444; color: #ffffff; }

        .drawer-thumb {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid var(--border-color);
            transition: transform 0.2s ease;
        }

        .drawer-thumb:hover {
            transform: scale(1.08);
        }

        .stat-mini {
            background: #f8fafc;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0.75rem 0.9rem;
        }

        .stat-mini .label {
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--text-secondary);
        }

        .stat-mini .value {
            font-size: 1.25rem;
            font-weight: 800;
            line-height: 1.2;
        }

        .dir-toggle {
            display: inline-flex;
            background: #f1f5f9;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 4px;
            gap: 4px;
        }

        .dir-btn {
            border: 0;
            background: transparent;
            font-weight: 700;
            font-size: 0.78rem;
            padding: 0.4rem 0.95rem;
            border-radius: 9px;
            color: var(--text-secondary);
            display: inline-flex;
            align-items: center;
            transition: background-color 0.2s ease, color 0.2s ease, box-shadow 0.2s ease;
        }

        .dir-btn:hover { color: var(--text-primary); }

        .dir-btn.active {
            background: #ffffff;
            color: var(--text-primary);
            box-shadow: 0 2px 6px rgba(15, 23, 42, 0.08);
        }

        .dir-btn[data-dir="IN"].active  { color: #10b981; }
        .dir-btn[data-dir="OUT"].active { color: #ef4444; }

        .drawer-table thead th {
            background: #f8fafc;
            color: var(--text-secondary);
            font-size: 0.68rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.75rem 0.75rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 1;
        }

        .drawer-table tbody td {
            padding: 0.7rem 0.75rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }

        .drawer-table tbody tr:hover {
            background-color: #f8fafc;
        }
    </style>
</head>
<body>

<!-- Unified Top Navigation Bar -->
<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo" onerror="this.style.display='none'">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>

        <div class="d-none d-md-flex align-items-center gap-2">
            <a href="dashboard.php" class="nav-link-custom"><i class="bi bi-house-door me-1"></i> Overview</a>
            <a href="owner_list.php" class="nav-link-custom active"><i class="bi bi-people me-1"></i> Owners</a>
            <a href="vehicle_list.php" class="nav-link-custom"><i class="bi bi-car-front me-1"></i> Vehicles</a>
            <a href="logs.php" class="nav-link-custom"><i class="bi bi-journal-text me-1"></i> Logs</a>
        </div>

        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<!-- Main Page Content -->
<main class="main-container">
    <!-- Header Section -->
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <?php if ($isTrash): ?>
                <h4 class="fw-bold mb-1 text-dark">Recently Deleted</h4>
                <p class="text-muted mb-0 small">Deleted owners are kept for <?= DELETE_RETENTION_DAYS ?> days, then permanently removed.</p>
            <?php else: ?>
                <h4 class="fw-bold mb-1 text-dark">Owners Directory</h4>
                <p class="text-muted mb-0 small">Full detailed profile records of registered system owners.</p>
            <?php endif; ?>
        </div>
        <div class="d-flex gap-2 align-items-center flex-wrap">
            <div class="bg-white px-3 py-2 rounded-3 border d-flex align-items-center">
                <i class="bi bi-people-fill me-2 text-primary"></i>
                <span class="small text-muted fw-bold">Total: <?= count($owners); ?> Owners</span>
            </div>
            <?php if ($isTrash): ?>
                <a href="owner_list.php" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                    <i class="bi bi-arrow-left me-2"></i> Back to Owners
                </a>
            <?php else: ?>
                <a href="owner_list.php?view=trash" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                    <i class="bi bi-trash3 me-2"></i> Recently Deleted
                    <?php if ($trashCount > 0): ?>
                        <span class="badge bg-danger ms-2"><?= $trashCount; ?></span>
                    <?php endif; ?>
                </a>
                <a href="add_owner.php" class="btn btn-primary-custom rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                    <i class="bi bi-plus-lg me-2"></i> Add Owner
                </a>
            <?php endif; ?>
        </div>
    </header>

    <!-- Search Bar -->
    <div class="dashboard-card p-2 mb-4">
        <form action="owner_list.php" method="GET" class="row g-2 align-items-center">
            <?php if ($isTrash): ?>
                <input type="hidden" name="view" value="trash">
            <?php endif; ?>
            <div class="col-md-8 col-lg-9">
                <div class="search-box d-flex align-items-center px-3 py-1">
                    <i class="bi bi-search text-muted fs-6 me-2"></i>
                    <input type="text" name="search" class="form-control border-0 shadow-none py-2 bg-transparent text-sm" 
                           placeholder="Search by name, ID, license, phone, email, or address..." 
                           value="<?= htmlspecialchars($search) ?>" autocomplete="off">
                </div>
            </div>
            <div class="col-md-4 col-lg-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary-custom w-100 fw-bold py-2 rounded-3 text-sm">Filter</button>
                <?php if(!empty($search)): ?>
                    <a href="owner_list.php<?= $isTrash ? '?view=trash' : ''; ?>" class="btn btn-report border w-100 fw-bold py-2 rounded-3 text-sm d-flex align-items-center justify-content-center">Reset</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Glass Table Card with Full Info -->
    <div class="dashboard-card overflow-hidden">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Owner</th>
                        <th>ID Number</th>
                        <th>License Details</th>
                        <th>Classification</th>
                        <th>Gender & Birthdate</th>
                        <th>Contact Details</th>
                        <th>Address</th>
                        <?php if ($isTrash): ?><th>Deletes In</th><?php endif; ?>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($owners)): foreach($owners as $owner): 
                        $ownerFullName = trim($owner['firstname'] . ' ' . ($owner['middlename'] ? $owner['middlename'] . ' ' : '') . $owner['lastname']);

                        // Days remaining before permanent deletion (Recently Deleted view only)
                        $daysLeft = null;
                        if ($isTrash && !empty($owner['deleted_at'])) {
                            $secondsLeft = strtotime($owner['deleted_at']) + (DELETE_RETENTION_DAYS * 86400) - time();
                            $daysLeft = max(0, (int)ceil($secondsLeft / 86400));
                        }
                    ?>
                        <tr class="owner-row">
                            <!-- Photo & Full Name -->
                            <td class="ps-4">
                                <div class="d-flex align-items-center gap-3">
                                    <?php if(!empty($owner['photo']) && file_exists("uploads/" . $owner['photo'])): ?>
                                        <img src="uploads/<?= htmlspecialchars($owner['photo']); ?>" class="owner-img shadow-sm hover-zoom" alt="Profile">
                                    <?php else: ?>
                                        <div class="img-placeholder hover-zoom"><i class="bi bi-person-fill"></i></div>
                                    <?php endif; ?>
                                    <div>
                                        <div class="fw-bold text-dark small">
                                            <?= htmlspecialchars($ownerFullName); ?>
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <!-- ID Number -->
                            <td class="fw-bold text-dark font-monospace small">
                                <?= htmlspecialchars($owner['id_number']); ?>
                            </td>

                            <!-- License Number & License Photo -->
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <?php if(!empty($owner['license_photo']) && file_exists("uploads/" . $owner['license_photo'])): ?>
                                        <a href="uploads/<?= htmlspecialchars($owner['license_photo']); ?>" target="_blank" title="View License Photo">
                                            <img src="uploads/<?= htmlspecialchars($owner['license_photo']); ?>" class="license-img-thumb shadow-sm" alt="License">
                                        </a>
                                    <?php endif; ?>
                                    <span class="fw-bold text-dark font-monospace small">
                                        <?= htmlspecialchars($owner['license_number'] ?? 'N/A'); ?>
                                    </span>
                                </div>
                            </td>

                            <!-- Type / Classification -->
                            <td>
                                <span class="badge bg-light text-dark border px-2 py-1 small fw-semibold type-badge">
                                    <?= htmlspecialchars($owner['type']); ?>
                                </span>
                            </td>

                            <!-- Gender & Birthdate -->
                            <td>
                                <div class="small fw-semibold text-dark">
                                    <i class="bi bi-gender-ambiguous me-1 text-secondary"></i><?= htmlspecialchars($owner['gender'] ?? 'N/A'); ?>
                                </div>
                                <div class="text-muted" style="font-size: 0.725rem;">
                                    <i class="bi bi-calendar3 me-1"></i><?= !empty($owner['date_of_birth']) ? date('M d, Y', strtotime($owner['date_of_birth'])) : 'N/A'; ?>
                                </div>
                            </td>

                            <!-- Phone & Email -->
                            <td>
                                <div class="small text-secondary fw-semibold">
                                    <i class="bi bi-telephone me-1 text-primary"></i><?= htmlspecialchars($owner['phone_number'] ?? 'N/A'); ?>
                                </div>
                                <div class="text-muted" style="font-size: 0.725rem;">
                                    <i class="bi bi-envelope me-1 text-secondary"></i><?= htmlspecialchars($owner['email'] ?? 'N/A'); ?>
                                </div>
                            </td>

                            <!-- Home Address -->
                            <td>
                                <div class="small text-secondary" style="min-width: 150px;">
                                    <i class="bi bi-geo-alt me-1 text-danger"></i><?= htmlspecialchars($owner['address'] ?? 'N/A'); ?>
                                </div>
                            </td>

                            <?php if ($isTrash): ?>
                            <!-- Days left before permanent deletion -->
                            <td class="text-nowrap">
                                <span class="badge <?= $daysLeft <= 7 ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning-emphasis'; ?> px-2 py-2">
                                    <i class="bi bi-hourglass-split me-1"></i><?= $daysLeft; ?> day<?= $daysLeft === 1 ? '' : 's'; ?>
                                </span>
                                <div class="text-muted" style="font-size: 0.7rem;">
                                    Deleted <?= date('M d, Y', strtotime($owner['deleted_at'])); ?>
                                </div>
                            </td>
                            <?php endif; ?>

                            <!-- Actions -->
                            <td class="text-center text-nowrap">
                                <?php if ($isTrash): ?>
                                    <a href="owner_list.php?restore=<?= urlencode($owner['id']); ?>"
                                       class="btn-action bg-success-subtle text-success me-1"
                                       onclick="return confirm('Restore this owner?');" title="Restore">
                                        <i class="bi bi-arrow-counterclockwise"></i>
                                    </a>
                                    <a href="owner_list.php?purge=<?= urlencode($owner['id']); ?>"
                                       class="btn-action bg-danger-subtle text-danger"
                                       onclick="return confirm('Permanently delete this owner now? This cannot be undone.');" title="Delete Permanently">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                <?php else: ?>
                                    <button type="button"
                                            class="btn-action bg-primary-subtle text-primary me-1 js-owner-logs"
                                            data-id="<?= (int)$owner['id']; ?>"
                                            data-name="<?= htmlspecialchars($ownerFullName, ENT_QUOTES); ?>"
                                            title="View Action Logs">
                                        <i class="bi bi-journal-text"></i>
                                    </button>
                                    <a href="owner_edit.php?id=<?= urlencode($owner['id']); ?>" class="btn-action bg-warning-subtle text-warning me-1" title="Edit Profile / Vehicles">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="owner_list.php?delete=<?= urlencode($owner['id']); ?>" 
                                       class="btn-action bg-danger-subtle text-danger" 
                                       onclick="return confirm('Delete this owner? They will be kept in Recently Deleted for <?= DELETE_RETENTION_DAYS ?> days, then permanently removed.');" title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr>
                            <td colspan="<?= $isTrash ? 9 : 8; ?>" class="text-center py-5 text-muted">
                                <i class="bi <?= $isTrash ? 'bi-trash3' : 'bi-people'; ?> fs-2 d-block mb-2 text-secondary opacity-50"></i>
                                <?= $isTrash ? 'No recently deleted owners.' : 'No records found matching your criteria.'; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<!-- SLIDE-IN DRAWER: OWNER ACTION LOGS -->
<div class="offcanvas offcanvas-end offcanvas-logs" tabindex="-1" id="ownerLogsOffcanvas" aria-labelledby="ownerLogsLabel">
    <div class="offcanvas-header border-bottom py-3">
        <div>
            <h6 class="offcanvas-title fw-bold text-dark mb-0" id="ownerLogsLabel"><i class="bi bi-journal-text me-2 text-primary"></i>Action Logs</h6>
            <div class="text-muted small mt-1" id="ownerLogsSub">---</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body p-0 d-flex flex-column" id="ownerLogsBody">
        <!-- Filled by JavaScript -->
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str == null ? '' : String(str);
        return div.innerHTML;
    }

    const logsCanvasEl = document.getElementById('ownerLogsOffcanvas');
    const logsBody     = document.getElementById('ownerLogsBody');
    const logsSub      = document.getElementById('ownerLogsSub');

    function showLogsMessage(html) {
        logsBody.innerHTML = '<div class="p-5 text-center text-muted">' + html + '</div>';
    }

    // Tap the Logs button on a row
    document.addEventListener('click', function (e) {
        const btn = e.target.closest('.js-owner-logs');
        if (!btn) return;

        const ownerId = btn.dataset.id;
        logsSub.textContent = btn.dataset.name || '---';
        showLogsMessage('<div class="spinner-border spinner-border-sm text-primary mb-2"></div><div class="small">Loading logs...</div>');
        bootstrap.Offcanvas.getOrCreateInstance(logsCanvasEl).show();

        fetch(window.location.pathname + '?action=owner_logs&id=' + encodeURIComponent(ownerId), { cache: 'no-store' })
            .then(function (res) {
                if (res.status === 401) {
                    window.location.href = 'admin.php';
                    throw new Error('Session expired');
                }
                return res.json();
            })
            .then(function (data) {
                if (!data.ok) {
                    showLogsMessage('<i class="bi bi-exclamation-triangle fs-2 d-block mb-2 text-danger"></i>' + escapeHtml(data.error || 'Could not load logs.'));
                    return;
                }
                renderOwnerLogs(data);
            })
            .catch(function (err) {
                console.warn(err);
                showLogsMessage('<i class="bi bi-wifi-off fs-2 d-block mb-2"></i>Could not load logs. Please try again.');
            });
    });

    function renderOwnerLogs(d) {
        logsSub.textContent = d.name + ' \u2022 ID ' + d.id_number;

        // Registered vehicles
        let vehiclesHtml = '';
        if (d.vehicles.length) {
            vehiclesHtml = d.vehicles.map(function (v) {
                const label = [v.brand, v.model].filter(Boolean).join(' ');
                return '<span class="d-inline-flex align-items-center gap-2 me-2 mb-2">' +
                           '<span class="plate-badge">' + escapeHtml(v.plate_number) + '</span>' +
                           (label ? '<span class="small text-muted">' + escapeHtml(label) + '</span>' : '') +
                       '</span>';
            }).join('');
        } else {
            vehiclesHtml = '<span class="small text-muted">No vehicles registered for this owner.</span>';
        }

        const summary =
            '<div class="p-3 border-bottom">' +
                '<div class="row g-2 mb-3">' +
                    '<div class="col-3"><div class="stat-mini"><div class="label">Total</div><div class="value">' + d.total + '</div></div></div>' +
                    '<div class="col-3"><div class="stat-mini"><div class="label">IN</div><div class="value text-success">' + d.in + '</div></div></div>' +
                    '<div class="col-3"><div class="stat-mini"><div class="label">OUT</div><div class="value text-danger">' + d.out + '</div></div></div>' +
                    '<div class="col-3"><div class="stat-mini"><div class="label">Last seen</div><div class="fw-bold" style="font-size:0.7rem; line-height:1.3;">' + escapeHtml(d.last_seen) + '</div></div></div>' +
                '</div>' +
                '<div class="small text-muted fw-bold text-uppercase mb-2" style="font-size:0.68rem; letter-spacing:0.06em;">Registered vehicles</div>' +
                '<div>' + vehiclesHtml + '</div>' +
            '</div>';

        let listHtml;
        if (d.total === 0) {
            listHtml =
                '<div class="p-5 text-center text-muted flex-grow-1">' +
                    '<i class="bi bi-journal-x fs-2 d-block mb-2 opacity-50"></i>' +
                    'No gate activity recorded for this owner yet.' +
                '</div>';
        } else {
            listHtml =
                '<div class="px-3 py-3 d-flex align-items-center justify-content-between">' +
                    '<span class="small text-muted fw-bold text-uppercase" style="font-size:0.68rem; letter-spacing:0.06em;">Latest ' + d.total + ' activities</span>' +
                    '<div class="dir-toggle" id="drawerDirToggle">' +
                        '<button type="button" class="dir-btn active" data-dir="">All</button>' +
                        '<button type="button" class="dir-btn" data-dir="IN"><i class="bi bi-arrow-down-left-circle-fill me-1"></i>IN</button>' +
                        '<button type="button" class="dir-btn" data-dir="OUT"><i class="bi bi-arrow-up-right-circle-fill me-1"></i>OUT</button>' +
                    '</div>' +
                '</div>' +
                '<div class="flex-grow-1" style="overflow-y:auto; min-height:0;">' +
                    '<table class="table drawer-table align-middle mb-0">' +
                        '<thead><tr>' +
                            '<th class="ps-3">Date</th><th>Time</th><th>Plate</th><th class="text-center">IN/OUT</th><th class="text-center">Photo</th>' +
                        '</tr></thead>' +
                        '<tbody id="drawerLogRows">' + d.rows_html + '</tbody>' +
                    '</table>' +
                '</div>';
        }

        logsBody.innerHTML = summary + listHtml;
    }

    // IN / OUT filter inside the drawer
    document.addEventListener('click', function (e) {
        const btn = e.target.closest('#drawerDirToggle .dir-btn');
        if (!btn) return;

        const dir = btn.dataset.dir || '';
        document.querySelectorAll('#drawerDirToggle .dir-btn').forEach(function (b) {
            b.classList.toggle('active', b === btn);
        });
        document.querySelectorAll('#drawerLogRows .drawer-log-row').forEach(function (row) {
            row.style.display = (dir === '' || row.dataset.dir === dir) ? '' : 'none';
        });
    });
</script>
</body>
</html>