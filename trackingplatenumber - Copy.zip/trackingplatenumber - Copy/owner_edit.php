<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}

$message = "";          // owner update messages
$vehicleMessage = "";   // vehicle registration messages

function alertBox($type, $text, $icon = '') {
    $i = $icon ? "<i class='bi $icon me-2'></i>" : '';
    return "<div class='alert alert-$type border-0 shadow-sm rounded-3 mb-4 d-flex align-items-center py-2 px-3 small fw-medium' role='alert'>$i<div>" . htmlspecialchars($text) . "</div></div>";
}

// 1. Fetch existing owner data safely
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM owners WHERE id = ?");
    $stmt->execute([$id]);
    $owner = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$owner) {
        header("Location: owner_list.php");
        exit();
    }
} else {
    header("Location: owner_list.php");
    exit();
}

// 2. Handle Update Owner
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_owner'])) {
    $id_number = trim($_POST['id_number']);
    $firstname = trim($_POST['firstname']);
    $middlename = trim($_POST['middlename']);
    $lastname = trim($_POST['lastname']);
    $gender = $_POST['gender'];
    $type = $_POST['type'];
    $contact = trim($_POST['phone_number']);
    $email = trim($_POST['email']);
    $photo_name = $owner['photo'];

    // Duplicate ID number check (ignore this owner's own record)
    try {
        $chk = $pdo->prepare("SELECT COUNT(*) FROM owners WHERE id_number = ? AND id <> ?");
        $chk->execute([$id_number, $id]);
        if ($chk->fetchColumn() > 0) {
            $message = alertBox('danger', "ID number already exists!");
        }
    } catch (PDOException $e) {
        $message = alertBox('danger', "Error: " . $e->getMessage());
    }

    if (empty($message) && !empty($_FILES['photo']['name'])) {
        $target_dir = "uploads/";
        $allowed_types = ['jpg', 'jpeg', 'png', 'webp'];
        $file_ext = strtolower(pathinfo($_FILES["photo"]["name"], PATHINFO_EXTENSION));

        if (!in_array($file_ext, $allowed_types)) {
            $message = alertBox('danger', "Invalid profile photo file type.");
        } else {
            $new_photo_name = time() . "_" . preg_replace("/[^a-zA-Z0-9]/", "", $lastname) . "." . $file_ext;

            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_dir . $new_photo_name)) {
                if (!empty($owner['photo']) && file_exists($target_dir . $owner['photo'])) {
                    @unlink($target_dir . $owner['photo']);
                }
                $photo_name = $new_photo_name;
            }
        }
    }

    if (empty($message)) {
        try {
            $sql = "UPDATE owners SET id_number=?, firstname=?, middlename=?, lastname=?, gender=?, type=?, phone_number=?, email=?, photo=? WHERE id=?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id_number, $firstname, $middlename, $lastname, $gender, $type, $contact, $email, $photo_name, $id]);
            header("Location: owner_list.php?status=updated");
            exit();
        } catch (PDOException $e) {
            $message = alertBox('danger', "Update failed: " . $e->getMessage());
        }
    }
}

// 3. Handle Register Vehicle
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register_vehicle'])) {
    $plate_number = strtoupper(trim($_POST['plate_number'] ?? ''));
    $vehicle_type = trim($_POST['vehicle_type'] ?? '');
    $brand        = trim($_POST['brand'] ?? '');
    $model        = trim($_POST['model'] ?? '');
    $color        = trim($_POST['color'] ?? '');

    if ($plate_number && $vehicle_type && $brand && $model && $color) {
        try {
            $chk = $pdo->prepare("SELECT COUNT(*) FROM vehicles WHERE plate_number = ?");
            $chk->execute([$plate_number]);
            if ($chk->fetchColumn() > 0) {
                $vehicleMessage = alertBox('danger', "Plate number already registered!", 'bi-exclamation-triangle-fill');
            } else {
                $stmt = $pdo->prepare("INSERT INTO vehicles (plate_number, vehicle_type, brand, model, color, owner_id) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$plate_number, $vehicle_type, $brand, $model, $color, $id]);
                header("Location: edit_owner.php?id=$id&vstatus=added#vehicles");
                exit();
            }
        } catch (PDOException $e) {
            $vehicleMessage = alertBox('danger', "Error: Plate number already registered.", 'bi-exclamation-triangle-fill');
        }
    } else {
        $vehicleMessage = alertBox('warning', "Please fill all required vehicle fields!", 'bi-exclamation-circle-fill');
    }
}

if (isset($_GET['vstatus']) && $_GET['vstatus'] === 'added') {
    $vehicleMessage = alertBox('success', "Vehicle registered successfully!", 'bi-check-circle-fill');
}

// 4. Registered vehicles of this owner
$stmt_vehicles = $pdo->prepare("SELECT * FROM vehicles WHERE owner_id = ? ORDER BY id DESC");
$stmt_vehicles->execute([$id]);
$registered_vehicles = $stmt_vehicles->fetchAll();

// Classification options
$types = ['Student', 'Faculty', 'Staff', 'Guardian'];
$currentType = $owner['type'] ?? '';
if ($currentType !== '' && !in_array($currentType, $types, true)) {
    array_unshift($types, $currentType);
}

// Keep vehicle form values after an error
function vold($key) { return htmlspecialchars($_POST[$key] ?? '', ENT_QUOTES); }
function vsel($key, $value) { return (($_POST[$key] ?? '') === $value) ? 'selected' : ''; }

$ownerName = trim(($owner['firstname'] ?? '') . ' ' . ($owner['lastname'] ?? ''));
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Owner | KCC Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        html { overflow-y: scroll; scroll-behavior: smooth; }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .nav-link-custom {
            color: #94a3b8;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.875rem;
        }
        .nav-link-custom:hover { color: #ffffff; background-color: rgba(255, 255, 255, 0.08); }
        .nav-link-custom.active { color: #ffffff; background-color: #2563eb; }

        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            animation: pageFadeIn 0.25s ease-out;
        }

        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        .form-card { padding: 2.5rem; }

        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }
        .btn-primary-custom:hover { background-color: var(--accent-blue-hover); color: #ffffff; }

        .btn-report {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            background: #ffffff;
            font-weight: 600;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }
        .btn-report:hover { background: #f1f5f9; border-color: #cbd5e1; color: var(--text-primary); }

        .form-control, .form-select {
            border-color: var(--border-color);
            border-radius: 10px;
            padding: 0.6rem 0.85rem;
            font-size: 0.9rem;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .preview-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #fff;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 0.75rem;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            font-weight: 700;
            color: var(--text-secondary);
        }

        /* Table */
        .table { margin-bottom: 0; width: 100%; }
        .table thead th {
            background: #f8fafc;
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
        }
        .table tbody td {
            padding: 1.1rem 1.25rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }
        .table tbody tr:last-child td { border-bottom: none; }
        .vehicle-row:hover { background-color: #f8fafc; }

        .plate-badge {
            background-color: #1e293b;
            color: #38bdf8;
            padding: 0.35rem 0.75rem;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.825rem;
            letter-spacing: 0.05em;
            display: inline-block;
            border: 1px solid #334155;
            font-family: monospace;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo" onerror="this.style.display='none'">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>

        <div class="d-none d-md-flex align-items-center gap-2">
            <a href="dashboard.php" class="nav-link-custom"><i class="bi bi-house-door me-1"></i> Overview</a>
            <a href="owner_list.php" class="nav-link-custom active"><i class="bi bi-people me-1"></i> Owners</a>
            <a href="vehicle_list.php" class="nav-link-custom"><i class="bi bi-car-front me-1"></i> Vehicles</a>
            <a href="logs.php" class="nav-link-custom"><i class="bi bi-journal-text me-1"></i> Logs</a>
        </div>

        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<main class="main-container">
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark">Update Owner Details</h4>
            <p class="text-muted mb-0 small">Modify information and vehicles of <span class="text-primary fw-bold"><?= htmlspecialchars($ownerName) ?></span>.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="owner_list.php" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                <i class="bi bi-arrow-left me-2"></i> Back to List
            </a>
        </div>
    </header>

    <!-- ===== Owner details form ===== -->
    <div class="dashboard-card form-card">
        <?= $message; ?>
        <form method="POST" enctype="multipart/form-data">
            <div class="row g-4">
                <div class="col-12 d-flex align-items-center mb-2">
                    <div class="me-4">
                        <?php if(!empty($owner['photo']) && file_exists("uploads/".$owner['photo'])): ?>
                            <img src="uploads/<?= htmlspecialchars($owner['photo']) ?>" class="preview-img" id="imgPreview">
                        <?php else: ?>
                            <div class="preview-img bg-light d-flex align-items-center justify-content-center border text-muted" id="imgPreview">
                                <i class="bi bi-person fs-2"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label class="form-label fw-bold small">Profile Photo</label>
                        <input type="file" name="photo" class="form-control form-control-sm" accept="image/*" onchange="previewFile()">
                        <small class="text-muted d-block mt-1">Recommended: Square image (JPG/PNG)</small>
                    </div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-bold small">ID Number</label>
                    <input type="text" name="id_number" class="form-control" value="<?= htmlspecialchars($_POST['id_number'] ?? $owner['id_number'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">First Name</label>
                    <input type="text" name="firstname" class="form-control" value="<?= htmlspecialchars($owner['firstname'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Middle Name</label>
                    <input type="text" name="middlename" class="form-control" value="<?= htmlspecialchars($owner['middlename'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Last Name</label>
                    <input type="text" name="lastname" class="form-control" value="<?= htmlspecialchars($owner['lastname'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Gender</label>
                    <select name="gender" class="form-select">
                        <option value="Male" <?= ($owner['gender'] ?? '') == 'Male' ? 'selected' : '' ?>>Male</option>
                        <option value="Female" <?= ($owner['gender'] ?? '') == 'Female' ? 'selected' : '' ?>>Female</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Type</label>
                    <select name="type" class="form-select">
                        <?php foreach($types as $t): ?>
                            <option value="<?= htmlspecialchars($t) ?>" <?= $currentType === $t ? 'selected' : '' ?>><?= htmlspecialchars($t) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Phone Number</label>
                    <input type="text" name="phone_number" class="form-control" value="<?= htmlspecialchars($owner['phone_number'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Email Address</label>
                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($owner['email'] ?? '') ?>" required>
                </div>

                <div class="col-12 pt-4 border-top">
                    <button type="submit" name="update_owner" class="btn btn-primary-custom px-5 py-2 fw-bold rounded-3 shadow-sm">
                        <i class="bi bi-check-circle me-2"></i> Save Changes
                    </button>
                    <a href="owner_list.php" class="btn btn-report px-4 py-2 rounded-3 ms-2">Cancel</a>
                </div>
            </div>
        </form>
    </div>

    <!-- ===== Register Vehicle ===== -->
    <div class="mt-5" id="vehicles">
        <header class="mb-3">
            <h5 class="fw-bold mb-1 text-dark">Register Vehicle</h5>
            <p class="text-muted small mb-0">Link a new vehicle to this owner's profile.</p>
        </header>

        <div class="dashboard-card form-card">
            <?= $vehicleMessage; ?>
            <form method="POST" action="edit_owner.php?id=<?= $id ?>#vehicles">
                <div class="row g-4">
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-muted text-uppercase">Plate Number</label>
                        <input type="text" name="plate_number" class="form-control text-uppercase" placeholder="ABC 1234" value="<?= vold('plate_number') ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-muted text-uppercase">Vehicle Type</label>
                        <select name="vehicle_type" class="form-select" required>
                            <option value="">Select Type</option>
                            <?php foreach (['Car','Motorcycle','SUV','Van','Truck','Tricycle'] as $vt): ?>
                                <option value="<?= $vt ?>" <?= vsel('vehicle_type', $vt) ?>><?= $vt ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-muted text-uppercase">Color</label>
                        <input type="text" name="color" class="form-control" placeholder="Black, White, Red, etc." value="<?= vold('color') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted text-uppercase">Brand</label>
                        <input type="text" name="brand" class="form-control" placeholder="Toyota, Honda, etc." value="<?= vold('brand') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted text-uppercase">Model</label>
                        <input type="text" name="model" class="form-control" placeholder="Vios, Civic, etc." value="<?= vold('model') ?>" required>
                    </div>
                </div>
                <button type="submit" name="register_vehicle" class="btn btn-primary-custom px-4 py-3 rounded-3 fw-bold w-100 mt-4 shadow-sm">
                    <i class="bi bi-plus-circle me-2"></i> Register Vehicle
                </button>
            </form>
        </div>
    </div>

    <!-- ===== Registered Vehicles ===== -->
    <div class="mt-5">
        <header class="mb-3 d-flex justify-content-between align-items-end">
            <div>
                <h5 class="fw-bold mb-1 text-dark">Registered Vehicles</h5>
                <p class="text-muted small mb-0">Assets linked to this profile.</p>
            </div>
            <div class="bg-white px-3 py-2 rounded-3 border d-flex align-items-center">
                <i class="bi bi-car-front-fill me-2 text-primary"></i>
                <span class="small text-muted fw-bold">Total: <?= count($registered_vehicles); ?></span>
            </div>
        </header>

        <div class="dashboard-card overflow-hidden">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Plate Number</th>
                            <th>Type</th>
                            <th>Brand</th>
                            <th>Model</th>
                            <th class="pe-4">Color</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($registered_vehicles): ?>
                            <?php foreach($registered_vehicles as $vehicle): ?>
                            <tr class="vehicle-row">
                                <td class="ps-4"><span class="plate-badge"><?= htmlspecialchars($vehicle['plate_number'] ?? ''); ?></span></td>
                                <td><span class="badge bg-light text-dark border px-2 py-1 small fw-semibold"><?= htmlspecialchars($vehicle['vehicle_type'] ?? ''); ?></span></td>
                                <td class="fw-bold small"><?= htmlspecialchars($vehicle['brand'] ?? ''); ?></td>
                                <td class="small"><?= htmlspecialchars($vehicle['model'] ?? ''); ?></td>
                                <td class="pe-4 small fw-medium"><?= htmlspecialchars($vehicle['color'] ?? ''); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">
                                    <i class="bi bi-inbox fs-2 d-block mb-2 text-secondary opacity-50"></i>
                                    No vehicles registered yet.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<script>
function previewFile() {
    const preview = document.querySelector('#imgPreview');
    const file = document.querySelector('input[type=file]').files[0];
    if (!file) return;
    const reader = new FileReader();

    reader.onloadend = function () {
        if (preview.tagName === 'IMG') {
            preview.src = reader.result;
        } else {
            const img = document.createElement('img');
            img.src = reader.result;
            img.className = 'preview-img';
            img.id = 'imgPreview';
            preview.parentNode.replaceChild(img, preview);
        }
    }
    reader.readAsDataURL(file);
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>