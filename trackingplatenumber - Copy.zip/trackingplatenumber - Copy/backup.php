<?php
session_start();
require 'config.php';

// Admin only, POST only, CSRF protected
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST'
    || !hash_equals((string)($_SESSION['csrf'] ?? ''), (string)($_POST['csrf'] ?? ''))) {
    http_response_code(403);
    exit('Invalid request.');
}

@set_time_limit(0);
@ini_set('memory_limit', '512M');
ignore_user_abort(true);

// Folders (relative to this file) that are saved into the backup
const BACKUP_FILE_DIRS = ['camdetect'];

function backup_fail($msg) {
    $_SESSION['flash_error'] = $msg;
    header("Location: dashboard.php");
    exit();
}

/** Writes every table (structure + data) as SQL. */
function dump_database(PDO $pdo, $fh) {
    $db = $pdo->query("SELECT DATABASE()")->fetchColumn();
    fwrite($fh, "-- KCC Tracking database backup\n-- Database: $db\n-- Created: " . date('Y-m-d H:i:s') . "\n\n");
    fwrite($fh, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");

    $tables = $pdo->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")->fetchAll(PDO::FETCH_NUM);
    foreach ($tables as $t) {
        $q = '`' . str_replace('`', '``', $t[0]) . '`';
        $create = $pdo->query("SHOW CREATE TABLE $q")->fetch(PDO::FETCH_NUM)[1];
        fwrite($fh, "-- Table: {$t[0]}\nDROP TABLE IF EXISTS $q;\n$create;\n\n");

        $st = $pdo->query("SELECT * FROM $q");
        $batch = [];
        while ($row = $st->fetch(PDO::FETCH_NUM)) {
            $vals = [];
            foreach ($row as $v) $vals[] = $v === null ? 'NULL' : $pdo->quote((string)$v);
            $batch[] = '(' . implode(',', $vals) . ')';
            if (count($batch) >= 200) {
                fwrite($fh, "INSERT INTO $q VALUES\n" . implode(",\n", $batch) . ";\n");
                $batch = [];
            }
        }
        if ($batch) fwrite($fh, "INSERT INTO $q VALUES\n" . implode(",\n", $batch) . ";\n");
        fwrite($fh, "\n");
    }
    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
}

if (!class_exists('ZipArchive')) {
    backup_fail("Backup needs the PHP 'zip' extension. Enable extension=zip in php.ini and restart Apache.");
}

$tmpSql = tempnam(sys_get_temp_dir(), 'kccsql_');
$tmpZip = tempnam(sys_get_temp_dir(), 'kcczip_');

try {
    // 1) Database -> database.sql
    $fh = fopen($tmpSql, 'wb');
    dump_database($pdo, $fh);
    fclose($fh);

    // 2) Zip: database.sql + files
    $zip = new ZipArchive();
    if ($zip->open($tmpZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException("Could not create the backup archive.");
    }
    $zip->addFile($tmpSql, 'database.sql');

    foreach (BACKUP_FILE_DIRS as $dir) {
        $base = realpath(__DIR__ . '/' . $dir);
        if ($base === false) continue;
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS)
        );
        foreach ($it as $file) {
            if ($file->isFile() && !$file->isLink()) {
                $rel = str_replace('\\', '/', substr($file->getPathname(), strlen($base) + 1));
                $zip->addFile($file->getPathname(), $dir . '/' . $rel);
            }
        }
    }
    if (!$zip->close()) throw new RuntimeException("Could not finish the backup archive.");

    // 3) Send to the browser
    $name  = 'kcc_backup_' . date('Ymd_His') . '.zip';
    $token = preg_replace('/[^A-Za-z0-9]/', '', (string)($_POST['token'] ?? ''));
    if ($token !== '') setcookie('backup_done', $token, 0, '/');   // lets the page know the download started

    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Content-Length: ' . filesize($tmpZip));
    header('Cache-Control: no-store');
    readfile($tmpZip);
} catch (Throwable $e) {
    @unlink($tmpSql);
    @unlink($tmpZip);
    backup_fail("Backup failed: " . $e->getMessage());
}

@unlink($tmpSql);
@unlink($tmpZip);
exit();
