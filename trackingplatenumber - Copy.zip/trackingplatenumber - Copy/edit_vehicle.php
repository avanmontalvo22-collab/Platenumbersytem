<?php
session_start(); 
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}

$id = $_GET['id'] ?? null;
if (!$id) die("Vehicle ID missing.");

$stmt = $pdo->prepare("SELECT v.*, o.firstname, o.lastname 
                        FROM vehicles v 
                        LEFT JOIN owners o ON v.owner_id = o.id 
                        WHERE v.id = ?");
$stmt->execute([$id]);
$v = $stmt->fetch();

if (!$v) die("Vehicle not found.");

$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $plate  = strtoupper(trim($_POST['plate_number']));
    $type   = trim($_POST['vehicle_type']);
    $brand  = trim($_POST['brand']);
    $model  = trim($_POST['model']);
    $color  = trim($_POST['color']);

    $update = $pdo->prepare("UPDATE vehicles SET plate_number = ?, vehicle_type = ?, brand = ?, model = ?, color = ? WHERE id = ?");
    if ($update->execute([$plate, $type, $brand, $model, $color, $id])) {
        $message = "
        <div class='alert alert-success border-0 shadow-sm rounded-3 mb-4 d-flex align-items-center py-2 px-3 animate__animated animate__fadeIn' role='alert'>
            <i class='bi bi-check-circle-fill me-2'></i>
            <div class='fw-medium small'>
                <strong>Success!</strong> Registration details updated.
                <a href='vehicle_list.php' class='alert-link ms-2'>Return to list</a>
            </div>
        </div>";
        $v['plate_number'] = $plate;
        $v['vehicle_type'] = $type;
        $v['brand']        = $brand;
        $v['model']        = $model;
        $v['color']        = $color;
    }
}

// Vehicle type options (current value is added automatically if it isn't in the list)
$types = ['Sedan', 'SUV', 'Truck', 'Motorcycle', 'Van', 'Pickup', 'Hatchback', 'Car', 'Tricycle'];
$currentType = $v['vehicle_type'] ?? '';
if ($currentType !== '' && !in_array($currentType, $types, true)) {
    array_unshift($types, $currentType);
}

$ownerName = trim(($v['firstname'] ?? '') . ' ' . ($v['lastname'] ?? '')) ?: 'Unassigned';
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Vehicle | KCC Tracking</title>
    <!-- Bootstrap 5 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        /* Prevents navbar/layout shift when a page has or lacks a scrollbar */
        html {
            overflow-y: scroll;
        }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        /* Top Navigation Header Bar */
        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .nav-link-custom {
            color: #94a3b8;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.875rem;
        }

        .nav-link-custom:hover {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.08);
        }

        .nav-link-custom.active {
            color: #ffffff;
            background-color: #2563eb;
        }

        /* Main Container Wrapper (with smooth page-load fade-in) */
        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            animation: pageFadeIn 0.25s ease-out;
        }

        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        /* Form card sits centered under the full-width header */
        .form-card {
            max-width: 900px;
            margin: 0 auto;
            padding: 2.5rem;
        }

        /* Buttons (shared with other pages) */
        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease, transform 0.2s ease;
        }

        .btn-primary-custom:hover {
            background-color: var(--accent-blue-hover);
            color: #ffffff;
            transform: translateY(-1px);
        }

        .btn-report {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            background: #ffffff;
            font-weight: 600;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-report:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--text-primary);
        }

        /* Form controls */
        .form-control,
        .form-select {
            border-color: var(--border-color);
            border-radius: 10px;
            padding: 0.6rem 0.85rem;
            font-size: 0.9rem;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        /* Plate Preview Box Style (matches .plate-badge, larger) */
        .plate-preview {
            font-family: 'Courier New', Courier, monospace;
            background-color: #1e293b;
            color: #38bdf8;
            font-weight: 800;
            font-size: 1.75rem;
            padding: 0.6rem 1.5rem;
            border-radius: 10px;
            border: 2px solid #334155;
            letter-spacing: 2px;
            display: inline-block;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

<!-- Unified Top Navigation Bar -->
<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo" onerror="this.style.display='none'">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>

        <div class="d-none d-md-flex align-items-center gap-2">
            <a href="dashboard.php" class="nav-link-custom"><i class="bi bi-house-door me-1"></i> Overview</a>
            <a href="owner_list.php" class="nav-link-custom"><i class="bi bi-people me-1"></i> Owners</a>
            <a href="vehicle_list.php" class="nav-link-custom active"><i class="bi bi-car-front me-1"></i> Vehicles</a>
            <a href="logs.php" class="nav-link-custom"><i class="bi bi-journal-text me-1"></i> Logs</a>
        </div>

        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<!-- Main Page Content -->
<main class="main-container">
    <!-- Header Section (same structure as logs.php / vehicle_list.php) -->
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark">Update Registration</h4>
            <p class="text-muted mb-0 small">Editing vehicle for <span class="text-primary fw-bold"><?= htmlspecialchars($ownerName); ?></span></p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="vehicle_list.php" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                <i class="bi bi-arrow-left me-2"></i> Back to List
            </a>
        </div>
    </header>

    <div class="form-card-wrap" style="max-width: 900px; margin: 0 auto;">
        <?= $message; ?>
    </div>

    <div class="dashboard-card form-card">
        <div class="text-center mb-5">
            <div class="small text-muted text-uppercase fw-bold mb-3">Registration Plate Preview</div>
            <div class="plate-preview">
                <?= htmlspecialchars($v['plate_number']); ?>
            </div>
        </div>

        <form method="POST">
            <div class="row">
                <div class="col-md-6 mb-4">
                    <label class="form-label fw-bold small">Plate Number</label>
                    <input type="text" name="plate_number" class="form-control text-uppercase" 
                           value="<?= htmlspecialchars($v['plate_number']); ?>" required>
                </div>
                
                <div class="col-md-6 mb-4">
                    <label class="form-label fw-bold small">Vehicle Type</label>
                    <select name="vehicle_type" class="form-select" required>
                        <?php foreach($types as $t): ?>
                            <option value="<?= htmlspecialchars($t); ?>" <?= $currentType === $t ? 'selected' : ''; ?>><?= htmlspecialchars($t); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-4">
                    <label class="form-label fw-bold small">Brand / Manufacturer</label>
                    <input type="text" name="brand" class="form-control" 
                           placeholder="e.g. Toyota" value="<?= htmlspecialchars($v['brand'] ?? ''); ?>" required>
                </div>
                
                <div class="col-md-6 mb-4">
                    <label class="form-label fw-bold small">Model Series</label>
                    <input type="text" name="model" class="form-control" 
                           placeholder="e.g. Vios XLE" value="<?= htmlspecialchars($v['model'] ?? ''); ?>" required>
                </div>
            </div>

            <div class="row">
                <div class="col-12 mb-4">
                    <label class="form-label fw-bold small">Color</label>
                    <input type="text" name="color" class="form-control" 
                           placeholder="e.g. Black, White, Red" value="<?= htmlspecialchars($v['color'] ?? ''); ?>" required>
                </div>
            </div>

            <div class="pt-4 border-top mt-2">
                <button type="submit" class="btn btn-primary-custom w-100 mb-3 py-3 rounded-3 shadow-sm text-uppercase fw-bold">
                    <i class="bi bi-cloud-arrow-up-fill me-2"></i> Save Changes
                </button>
                <div class="text-center">
                    <a href="vehicle_list.php" class="text-muted small fw-bold text-decoration-none">
                        <i class="bi bi-x-circle me-1"></i> Discard and Exit
                    </a>
                </div>
            </div>
        </form>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>