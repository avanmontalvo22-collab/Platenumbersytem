<?php
session_start();
require 'config.php';

if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
$csrfOk = function () {
    return hash_equals((string)$_SESSION['csrf'], (string)($_POST['csrf'] ?? ''));
};

$error = null;

// 1. ASYNCHRONOUS PYTHON TOOL LAUNCH
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sub'])) {
    if (!$csrfOk()) {
        $error = "Your session expired. Please reload the page and try again.";
    } else {
        // Location of the detection script
        $scriptDir  = 'C:\xampp\htdocs\trackingplatenumber';
        $scriptFile = 'camdetect.py';
        $pythonExe  = 'python';   // if Apache can't find Python, put its full path here, e.g. 'C:\Python312\python.exe'

        if (!is_file($scriptDir . '\\' . $scriptFile)) {
            $error = "Cannot find " . $scriptDir . '\\' . $scriptFile . ". Check the path in guard.php.";
        } else {
            // Run from the script's own folder (so its relative paths like camdetect/ work),
            // detached in the background. The empty "" is the window title that `start` expects.
            $command = 'cd /d "' . $scriptDir . '" && start "" /B ' . $pythonExe . ' "' . $scriptFile . '"';
            pclose(popen($command, "r"));
            header("Location: " . $_SERVER['PHP_SELF'] . "?status=tool_launched");
            exit();
        }
    }
}

// 2. MANUAL LOG ENTRY HANDLER (With optional snapshot capture & vehicle type support)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_entry'])) {
    if (!$csrfOk()) {
        $error = "Your session expired. Please reload the page and try again.";
    } else {
        $plate = strtoupper(trim($_POST['plate_number'] ?? ''));
        $manual_name = ucwords(strtolower(trim($_POST['manual_name'] ?? '')));
        $vehicle_type = ucwords(strtolower(trim($_POST['vehicle_type'] ?? '')));
        $action = isset($_POST['action']) && in_array(strtoupper($_POST['action']), ['IN', 'OUT'], true) ? strtoupper($_POST['action']) : 'IN';
        $photoFileName = null;

        // Handle optional uploaded snapshot file
        if (isset($_FILES['snapshot_photo']) && $_FILES['snapshot_photo']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['snapshot_photo']['tmp_name'];
            $fileExtension = strtolower(pathinfo($_FILES['snapshot_photo']['name'], PATHINFO_EXTENSION));
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];

            // Check the extension AND that the file really is an image
            if (in_array($fileExtension, $allowedExtensions, true) && @getimagesize($fileTmpPath) !== false) {
                if (!is_dir('camdetect')) {
                    mkdir('camdetect', 0755, true);
                }
                $newFileName = 'manual_' . time() . '_' . uniqid() . '.' . $fileExtension;
                $dest_path = 'camdetect/' . $newFileName;

                if (move_uploaded_file($fileTmpPath, $dest_path)) {
                    $photoFileName = $newFileName;
                }
            }
        }

        if (!empty($plate) && !empty($manual_name)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO logs (plate_number, manual_name, vehicle_type, action, photo, log_time) VALUES (?, ?, ?, ?, ?, NOW())");
                if ($stmt->execute([$plate, $manual_name, $vehicle_type, $action, $photoFileName])) {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?status=success");
                    exit();
                }
            } catch (PDOException $e) {
                $error = "Database Error: " . $e->getMessage();
            }
        } else {
            $error = "Please fill in all required fields.";
        }
    }
}

// 3. FETCH LOGS DATA
try {
    $stmtLogs = $pdo->query("
        SELECT 
            l.id, l.plate_number, l.manual_name, l.action, l.photo, l.log_time,
            v.brand, v.model, v.vehicle_type, o.photo as owner_photo,
            CONCAT(o.firstname, ' ', o.lastname) as owner_name
        FROM logs l
        LEFT JOIN vehicles v ON l.plate_number = v.plate_number
        LEFT JOIN owners o ON v.owner_id = o.id
        ORDER BY l.log_time DESC 
        LIMIT 100
    ");
    $logs = $stmtLogs->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $logs = [];
    if (!$error) {
        $error = "Failed to load log history: " . $e->getMessage();
    }
}

// Helper function to render table rows dynamically matching logs.php styling
function renderLogRows(array $logs): string {
    if (empty($logs)) {
        return '<tr><td colspan="10" class="text-center py-5 text-muted"><i class="bi bi-journal-x fs-2 d-block mb-2 opacity-50"></i>No campus activity recorded.</td></tr>';
    }

    $html = '';
    foreach ($logs as $row) {
        // Prioritize log snapshot photo if available, otherwise fall back to owner photo
        $activePhoto = !empty($row['photo']) ? $row['photo'] : (!empty($row['owner_photo']) ? $row['owner_photo'] : '');
        $photoDir = !empty($row['photo']) ? 'camdetect/' : 'uploads/';
        $activePhoto = basename((string)$activePhoto);

        $hasPhoto = $activePhoto !== '' && file_exists($photoDir . $activePhoto);
        $photoPath = $hasPhoto ? $photoDir . $activePhoto : '';

        $ts = strtotime($row['log_time']);
        $fullTime = date('M d, Y - h:i A', $ts);

        // Values go through data-attributes (safe even if a plate/name contains quotes)
        $dataAttrs = ' data-photo="' . htmlspecialchars($photoPath, ENT_QUOTES) . '"'
                   . ' data-plate="' . htmlspecialchars($row['plate_number'], ENT_QUOTES) . '"'
                   . ' data-time="'  . htmlspecialchars($fullTime, ENT_QUOTES) . '"';

        $html .= '<tr class="log-row">';

        // Photo
        $html .= '<td class="ps-3" style="width: 6%;">';
        $html .= '<button type="button" class="btn p-0 border-0 bg-transparent js-open-photo"' . $dataAttrs . '>';
        if ($hasPhoto) {
            $html .= '<img src="' . htmlspecialchars($photoPath, ENT_QUOTES) . '" class="avatar-img shadow-sm hover-zoom" alt="Capture">';
        } else {
            $html .= '<div class="avatar-placeholder hover-zoom" title="Click to view capture info"><i class="bi bi-person-bounding-box"></i></div>';
        }
        $html .= '</button>';
        $html .= '</td>';

        // Plate Number
        $html .= '<td style="width: 11%;"><span class="plate-badge font-monospace">' . htmlspecialchars($row['plate_number']) . '</span></td>';

        // Vehicle Type
        $vType = !empty($row['vehicle_type']) ? $row['vehicle_type'] : 'Guest';
        $html .= '<td style="width: 9%;"><span class="badge bg-light text-dark border px-2 py-1 small fw-semibold">' . htmlspecialchars($vType) . '</span></td>';

        // Brand
        $html .= '<td style="width: 11%;">';
        if (!empty($row['brand'])) {
            $html .= '<span class="fw-semibold text-dark small">' . htmlspecialchars($row['brand']) . '</span>';
        } else {
            $html .= '<span class="fw-semibold text-danger small"><i class="bi bi-exclamation-triangle me-1"></i>Not Registered</span>';
        }
        $html .= '</td>';

        // Color / Model
        $modelStr = !empty($row['model']) ? htmlspecialchars($row['model']) : '---';
        $html .= '<td style="width: 8%;"><span class="text-dark small fw-medium">' . $modelStr . '</span></td>';

        // Owner Name
        $html .= '<td class="small fw-semibold text-dark" style="width: 14%;">';
        $html .= !empty($row['owner_name']) ? htmlspecialchars($row['owner_name']) : '<span class="text-muted fw-normal">Unknown Vehicle</span>';
        $html .= '</td>';

        // Manual Visitor Name
        $html .= '<td class="small text-muted" style="width: 12%;">';
        $html .= !empty($row['manual_name']) ? htmlspecialchars($row['manual_name']) : '--';
        $html .= '</td>';

        // Action Badge (IN / OUT)
        $isIn = isset($row['action']) && strtoupper($row['action']) === 'IN';
        $actionClass = $isIn ? 'badge-in' : 'badge-out';
        $actionIcon = $isIn ? 'bi-arrow-down-left-circle-fill' : 'bi-arrow-up-right-circle-fill';
        $actionVal = htmlspecialchars($row['action'] ?? 'IN');
        $html .= '<td class="text-center col-dir" style="width: 10%;">';
        $html .= '<span class="status-badge ' . $actionClass . '"><i class="bi ' . $actionIcon . ' me-1"></i>' . $actionVal . '</span>';
        $html .= '</td>';

        // Date
        $html .= '<td style="width: 10%;">';
        $html .= '<div class="fw-bold text-dark small">' . date('M d, Y', $ts) . '</div>';
        $html .= '<div class="text-muted" style="font-size: 0.725rem;">' . date('l', $ts) . '</div>';
        $html .= '</td>';

        // Time
        $html .= '<td style="width: 9%;">';
        $html .= '<span class="fw-bold text-dark small">' . date('h:i A', $ts) . '</span>';
        $html .= '</td>';

        $html .= '</tr>';
    }
    return $html;
}

// 4. BACKGROUND REFRESH API ENDPOINT
if (isset($_GET['action']) && $_GET['action'] === 'fetch_logs_updates') {
    header('Content-Type: application/json');
    echo json_encode([
        'table_html' => renderLogRows($logs)
    ]);
    exit();
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KCC Security | Terminal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        /* Prevents layout shift when a page has or lacks a scrollbar */
        html { overflow-y: scroll; }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        .search-box {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);
        }

        .table {
            margin-bottom: 0;
            table-layout: fixed;
            width: 100%;
        }

        .table thead th {
            background: #f8fafc;
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 1rem 1rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
        }

        .table tbody td {
            padding: 1rem 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
            word-break: break-word;
        }

        /* IN/OUT column: tighter padding so the badge always fits */
        .table tbody td.col-dir,
        .table thead th.col-dir {
            padding-left: 0.5rem;
            padding-right: 0.5rem;
        }

        .log-row:hover {
            background-color: #f8fafc;
        }

        .avatar-img {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 10px;
            cursor: pointer;
            transition: transform 0.2s ease;
            border: 1px solid var(--border-color);
        }

        .avatar-placeholder {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #f1f5f9;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            cursor: pointer;
            border: 1px solid var(--border-color);
        }

        .hover-zoom:hover {
            transform: scale(1.08);
        }

        .plate-badge {
            background-color: #1e293b;
            color: #38bdf8;
            padding: 0.35rem 0.75rem;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.825rem;
            letter-spacing: 0.05em;
            display: inline-block;
            border: 1px solid #334155;
        }

        .status-badge {
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0.35rem 0.85rem;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            white-space: nowrap;          /* never wrap the badge text */
            word-break: normal;           /* ignore the table's break-word rule */
        }

        .badge-in { background-color: #10b981; color: #ffffff; }
        .badge-out { background-color: #ef4444; color: #ffffff; }

        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }
        .btn-primary-custom:hover {
            background-color: var(--accent-blue-hover);
            color: #ffffff;
        }

        .pulse-icon {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #10b981;
            box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
            animation: pulse-green 2s infinite;
        }

        @keyframes pulse-green {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
        }

        .offcanvas-photo {
            width: 420px !important;
            max-width: 100vw;
            border-top-left-radius: 20px;
            border-bottom-left-radius: 20px;
        }
    </style>
</head>
<body>

<main class="main-container">
    
    <?php if(isset($_GET['status'])): ?>
        <?php if($_GET['status'] == 'success'): ?>
            <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm mb-4" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i> <strong>Success!</strong> Entry logged successfully.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php elseif($_GET['status'] == 'tool_launched'): ?>
            <div class="alert alert-info alert-dismissible fade show rounded-3 border-0 shadow-sm mb-4" role="alert">
                <i class="bi bi-camera-video me-2"></i> <strong>Tool Active!</strong> Python detection script initiated in the background.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(!empty($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show rounded-3 border-0 shadow-sm mb-4" role="alert">
            <i class="bi bi-exclamation-octagon-fill me-2"></i> <strong>Error!</strong> <?= htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div class="d-flex align-items-center">
            <img src="images-removebg-preview.png" alt="Logo" class="me-3" style="height: 48px;" onerror="this.style.display='none'">
            <div>
                <h4 class="mb-0 fw-bold text-dark">KCC GATEWAY TERMINAL</h4>
                <span class="text-muted small"><i class="bi bi-dot text-success fs-5 align-middle"></i> KCCsmartdetection system active</span>
            </div>
        </div>

        <div class="d-flex gap-2 flex-wrap">
            <form action="" method="post" class="m-0">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
                <button type="submit" name="sub" value="call" class="btn btn-dark rounded-3 px-3 py-2 fw-bold shadow-sm text-sm">
                    <i class="bi bi-camera-video me-2"></i> OPEN TOOL
                </button>
            </form>

            <button class="btn btn-primary-custom rounded-3 px-3 py-2 fw-bold shadow-sm text-sm" data-bs-toggle="modal" data-bs-target="#manualEntryModal">
                <i class="bi bi-plus-lg me-2"></i> Manual Entry
            </button>
        </div>
    </header>

    <div class="dashboard-card p-2 mb-4">
        <div class="search-box d-flex align-items-center px-3 py-1">
            <i class="bi bi-search text-muted fs-6 me-2"></i>
            <input type="text" id="guardSearch" class="form-control border-0 shadow-none py-2 bg-transparent text-sm" placeholder="Search plate, type, color, owner, or visitor..." autocomplete="off">
        </div>
    </div>

    <div class="dashboard-card overflow-hidden">
        <div class="p-3 border-bottom bg-white d-flex align-items-center gap-2">
            <span class="pulse-icon"></span>
            <h6 class="fw-bold mb-0 text-dark">Live Traffic Activity Feed</h6>
        </div>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th class="ps-3" style="width: 6%;">PHOTO</th>
                        <th style="width: 11%;">PLATE</th>
                        <th style="width: 9%;">TYPE</th>
                        <th style="width: 11%;">BRAND</th>
                        <th style="width: 8%;">COLOR</th>
                        <th style="width: 14%;">OWNER</th>
                        <th style="width: 12%;">MANUAL ENTRY</th>
                        <th class="text-center col-dir" style="width: 10%;">IN/OUT</th>
                        <th style="width: 10%;">DATE</th>
                        <th style="width: 9%;">TIME</th>
                    </tr>
                </thead>
                <tbody id="logsTable">
                    <?= renderLogRows($logs) ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<!-- SLIDE-IN OVERLAY / OFFCANVAS FOR CAPTURE PHOTO -->
<div class="offcanvas offcanvas-end offcanvas-photo" tabindex="-1" id="photoOffcanvas">
    <div class="offcanvas-header border-bottom py-3">
        <h6 class="offcanvas-title fw-bold text-dark mb-0"><i class="bi bi-camera me-2 text-primary"></i>Snapshot Preview</h6>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body p-4 text-center">
        <div class="mb-3 text-start">
            <span class="badge bg-dark font-monospace fs-6 px-3 py-2" id="drawerPlateNum">---</span>
            <span class="text-muted small d-block mt-2" id="drawerTimestamp"><i class="bi bi-clock me-1"></i>---</span>
        </div>
        
        <div id="drawerPhotoContainer" class="p-2 border rounded-3 bg-light shadow-sm">
            <!-- Captured image dynamically loaded via JS -->
        </div>

        <a id="drawerDownloadBtn" href="#" download class="btn btn-primary-custom w-100 rounded-3 py-2 mt-4 fw-bold text-sm">
            <i class="bi bi-download me-2"></i> Download Image
        </a>
    </div>
</div>

<!-- MANUAL ENTRY MODAL -->
<div class="modal fade" id="manualEntryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-3 border-0 shadow-lg" style="border-radius: 16px;">
            <div class="modal-header border-0 pb-0">
                <h6 class="fw-bold text-dark mb-0"><i class="bi bi-pencil-square text-primary me-2"></i>Manual Gate Entry Registration</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
                <div class="modal-body py-3">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Full Name (Visitor / Guest)</label>
                        <input type="text" name="manual_name" class="form-control text-sm rounded-3 py-2" placeholder="e.g. Juan Dela Cruz" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Plate Number</label>
                        <input type="text" name="plate_number" class="form-control text-sm font-monospace text-uppercase rounded-3 py-2" placeholder="e.g. ABC1234" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Vehicle Type</label>
                        <select name="vehicle_type" class="form-select text-sm rounded-3 py-2">
                            <option value="">Select Type (Optional)</option>
                            <option value="Car">Car</option>
                            <option value="Motorcycle">Motorcycle</option>
                            <option value="SUV">SUV</option>
                            <option value="Van">Van</option>
                            <option value="Truck">Truck</option>
                            <option value="Tricycle">Tricycle</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Optional Snapshot Capture</label>
                        <input type="file" name="snapshot_photo" class="form-control text-sm rounded-3 py-2" accept="image/*">
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold text-secondary">Gate Direction</label>
                        <div class="d-flex gap-3">
                            <input type="radio" class="btn-check" name="action" id="act_in" value="IN" checked>
                            <label class="btn btn-outline-success w-100 py-2 rounded-3 fw-bold border-1 text-sm text-nowrap" for="act_in"><i class="bi bi-arrow-down-left-circle me-1"></i> IN</label>
                            <input type="radio" class="btn-check" name="action" id="act_out" value="OUT">
                            <label class="btn btn-outline-danger w-100 py-2 rounded-3 fw-bold border-1 text-sm text-nowrap" for="act_out"><i class="bi bi-arrow-up-right-circle me-1"></i> OUT</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-3 px-3 py-2 text-sm fw-medium text-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="manual_entry" class="btn btn-primary-custom rounded-3 px-4 py-2 text-sm fw-bold">Save Entry</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Escape text before putting it into innerHTML
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function openPhotoDrawer(photoUrl, plate, timestamp) {
        document.getElementById('drawerPlateNum').textContent = plate;
        document.getElementById('drawerTimestamp').innerHTML = '<i class="bi bi-clock me-1"></i> ' + escapeHtml(timestamp);

        const photoContainer = document.getElementById('drawerPhotoContainer');
        const downloadBtn = document.getElementById('drawerDownloadBtn');

        if (photoUrl !== "") {
            photoContainer.innerHTML = '<img src="' + escapeHtml(photoUrl) + '" class="img-fluid rounded-3 shadow-sm w-100" alt="Detection Capture">';
            downloadBtn.href = photoUrl;
            downloadBtn.classList.remove('disabled');
        } else {
            photoContainer.innerHTML =
                '<div class="py-5 text-muted">' +
                    '<i class="bi bi-camera-video-off fs-1 opacity-50 d-block mb-2"></i>' +
                    'No camera snapshot available.' +
                '</div>';
            downloadBtn.href = "#";
            downloadBtn.classList.add('disabled');
        }

        bootstrap.Offcanvas.getOrCreateInstance(document.getElementById('photoOffcanvas')).show();
    }

    // Event delegation: keeps working after the table is refreshed in the background
    document.getElementById('logsTable').addEventListener('click', function (e) {
        const btn = e.target.closest('.js-open-photo');
        if (!btn) return;
        openPhotoDrawer(btn.dataset.photo || '', btn.dataset.plate || '', btn.dataset.time || '');
    });

    function applySearchFilter() {
        const filter = document.getElementById('guardSearch').value.toLowerCase();
        document.querySelectorAll('.log-row').forEach(function (row) {
            row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
        });
    }

    document.getElementById('guardSearch').addEventListener('keyup', applySearchFilter);

    // Asynchronous background update polling (replaces full page refresh)
    setInterval(function () {
        const searchInput = document.getElementById('guardSearch');
        const modal = document.getElementById('manualEntryModal');
        const offcanvas = document.getElementById('photoOffcanvas');

        const isModalOpen = modal ? modal.classList.contains('show') : false;
        const isOffcanvasOpen = offcanvas ? offcanvas.classList.contains('show') : false;

        if (document.hidden || searchInput.value.trim() !== "" || isModalOpen || isOffcanvasOpen) return;

        fetch(window.location.pathname + '?action=fetch_logs_updates', { cache: 'no-store' })
            .then(function (response) { return response.json(); })
            .then(function (data) {
                document.getElementById('logsTable').innerHTML = data.table_html;
                applySearchFilter();
            })
            .catch(function (err) { console.warn('Telemetry stream dropped: ', err); });
    }, 5000);
</script>
</body>
</html>