import cv2
import imutils
import easyocr
import mysql.connector
import numpy as np
import time
import os

# Data configuration
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "smart_plate_system" 
}

# Ensure camdetect directory exists for saving snapshots
SNAPSHOT_DIR = "camdetect"
if not os.path.exists(SNAPSHOT_DIR):
    os.makedirs(SNAPSHOT_DIR)

def save_exit_to_db(plate_text, frame_snapshot):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        
        # 1. Fetch Owner AND Vehicle Details (Brand/Type)
        query = """
            SELECT CONCAT(o.firstname, ' ', o.lastname) AS owner_name, v.brand, v.vehicle_type 
            FROM vehicles v
            JOIN owners o ON v.owner_id = o.id
            WHERE REPLACE(v.plate_number, ' ', '') = %s
        """
        cursor.execute(query, (plate_text,))
        result = cursor.fetchone()

        owner_name = None
        brand = None
        vehicle_type = None

        if result:
            owner_name, brand, vehicle_type = result

        # 2. Save Snapshot Photo File
        timestamp_str = time.strftime("%Y%m%d_%H%M%S")
        photo_filename = f"exit_{timestamp_str}_{plate_text}.jpg"
        photo_path = os.path.join(SNAPSHOT_DIR, photo_filename)
        cv2.imwrite(photo_path, frame_snapshot)

        # 3. Insert into LOGS table with the 'OUT' action and photo filename
        log_query = """
            INSERT INTO logs (plate_number, owner_name, brand, vehicle_type, action, photo, log_time) 
            VALUES (%s, %s, %s, %s, 'OUT', %s, NOW())
        """
        cursor.execute(log_query, (plate_text, owner_name, brand, vehicle_type, photo_filename))
        conn.commit()

        if result:
            print(f"🚗 [EXIT] Log Saved: {plate_text} | {brand} | Owner: {owner_name} | Snapshot: {photo_filename}")
        else:
            print(f"⚠️  [UNREGISTERED EXIT] Plate: {plate_text} - Logged with Snapshot: {photo_filename}")

    except mysql.connector.Error as err:
        print(f"❌ [DB Error]: {err}")
    finally:
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()

# Initialize OCR Reader
reader = easyocr.Reader(['en'], gpu=False)

cap = cv2.VideoCapture(0) 
last_detected = ""
last_save_time = 0
cooldown_seconds = 15  # Cooldown to prevent rapid duplicate database entries
frame_count = 0

print("🛑 KCC EXIT System Active (Optimized & Snapshot Enabled)... Press 'q' to stop.")

while True:
    ret, frame = cap.read()
    if not ret: 
        break

    frame_count += 1
    
    # PERFORMANCE FIX: Skip frames to reduce CPU load and prevent rapid multi-firing.
    if frame_count % 5 != 0:
        cv2.imshow('KCC EXIT Plate Detection', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        continue

    processed_frame = imutils.resize(frame, width=640)
    gray = cv2.cvtColor(processed_frame, cv2.COLOR_BGR2GRAY)
    
    # Pre-processing
    bfilter = cv2.bilateralFilter(gray, 11, 17, 17)
    edged = cv2.Canny(bfilter, 30, 200)

    keypoints = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = imutils.grab_contours(keypoints)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]

    location = None
    for contour in contours:
        approx = cv2.approxPolyDP(contour, 10, True)
        if len(approx) == 4:
            location = approx
            break

    if location is not None:
        cv2.drawContours(processed_frame, [location], 0, (0, 0, 255), 3) # Red contour for Exit
        mask = np.zeros(gray.shape, np.uint8)
        cv2.drawContours(mask, [location], 0, 255, -1)
        
        (x, y) = np.where(mask == 255)
        if len(x) > 0:
            (topx, topy) = (np.min(x), np.min(y))
            (bottomx, bottomy) = (np.max(x), np.max(y))
            cropped_gray = gray[max(0, topx-5):bottomx+5, max(0, topy-5):bottomy+5]

            results = reader.readtext(cropped_gray)
            
            if results:
                for res in results:
                    detected_text = res[1].upper().replace(" ", "").replace("-", "")
                    
                    if any(word in detected_text for word in ["PHILIPPINES", "REPUBLIKA", "NCR", "DOTR"]):
                        continue
                    
                    if 5 <= len(detected_text) <= 8:
                        plate_text = detected_text
                        cv2.putText(processed_frame, f"EXIT: {plate_text}", (topy, topx - 10), 
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

                        current_time = time.time()
                        # Check if plate changed OR cooldown has elapsed
                        if plate_text != last_detected or (current_time - last_save_time > cooldown_seconds):
                            save_exit_to_db(plate_text, processed_frame)
                            last_detected = plate_text
                            last_save_time = current_time
                        break 

    cv2.imshow('KCC EXIT Plate Detection', processed_frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()