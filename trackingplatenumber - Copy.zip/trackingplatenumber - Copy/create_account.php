<?php
session_start();
require 'config.php';

// Public signup: anyone can create an account from the login page.
$adminCount = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
$isFirstSetup = ($adminCount === 0);
$isLoggedIn = isset($_SESSION['admin']);

if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));

$message = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_btn'])) {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirm  = (string)($_POST['confirm'] ?? '');
    $error = "";

    if (!hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
        $error = "Your session expired. Please reload the page and try again.";
    } elseif (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $username)) {
        $error = "Username must be 3-30 characters: letters, numbers, dot, dash or underscore.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = "That username is already taken.";
        } else {
            $pdo->prepare("INSERT INTO admins (username, password) VALUES (?, ?)")
                ->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
            $success = true;
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
    }

    if ($error !== "") {
        $message = "<div class='alert alert-danger border-0 small py-2'>" . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . "</div>";
    } elseif ($success) {
        $message = "<div class='alert alert-success border-0 small py-2'>Account created successfully.</div>";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | KCC Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/admin.css">
</head>
<body>
<div class="container">
    <div class="login-card mx-auto">
        <div class="text-center">
            <img src="images-removebg-preview.png" alt="Logo" class="logo-img">
            <h4 class="fw-bold mb-1">Create Account</h4>
            <p class="text-muted small mb-4">
                <?= $isFirstSetup ? 'Set up the first administrator' : 'Add a new administrator' ?>
            </p>
        </div>

        <?= $message; ?>

        <form method="POST" autocomplete="off">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
            <div class="mb-3">
                <label class="form-label small fw-bold text-muted">Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-0"><i class="bi bi-person text-muted"></i></span>
                    <input type="text" name="username" class="form-control bg-light border-0" placeholder="Choose a username" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label small fw-bold text-muted">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-0"><i class="bi bi-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control bg-light border-0" placeholder="At least 8 characters" minlength="8" required>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label small fw-bold text-muted">Confirm Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-0"><i class="bi bi-shield-lock text-muted"></i></span>
                    <input type="password" name="confirm" class="form-control bg-light border-0" placeholder="Repeat password" minlength="8" required>
                </div>
            </div>
            <button type="submit" name="create_btn" class="btn btn-primary w-100 fw-bold shadow-sm">
                Create Account <i class="bi bi-person-plus ms-2"></i>
            </button>
        </form>

        <p class="small text-center text-muted mt-3 mb-0">
            <?php if ($isLoggedIn): ?>
                <a href="dashboard.php" class="fw-bold text-decoration-none">Back to dashboard</a>
            <?php else: ?>
                <a href="admin.php" class="fw-bold text-decoration-none">Back to sign in</a>
            <?php endif; ?>
        </p>

        <div class="mt-4 pt-3 border-top text-center">
            <p class="small text-muted mb-0">&copy; 2026 KCCcamguarddetection</p>
        </div>
    </div>
</div>
</body>
</html>