<?php
require 'config.php';
if (!isset($_SESSION['admin'])) exit();

$id = $_GET['id'] ?? null;

if ($id) {
    try {
        $stmt = $pdo->prepare("DELETE FROM vehicles WHERE id = ?");
        $stmt->execute([$id]);
        
        header("Location: vehicle_list.php?deleted=1");
        exit();
    } catch (PDOException $e) {
        die("Error deleting record: " . $e->getMessage());
    }
} else {
    header("Location: vehicle_list.php");
    exit();
}