<?php
session_start();
require 'config.php';

if(!isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}

$message = "";
$success = false;

// Keep typed values when there is an error
function old(string $key): string {
    global $success;
    if ($success) return '';
    return htmlspecialchars($_POST[$key] ?? '', ENT_QUOTES);
}
function selected(string $key, string $value): string {
    global $success;
    if ($success) return '';
    return (($_POST[$key] ?? '') === $value) ? 'selected' : '';
}
function alertBox(string $type, string $text): string {
    return "<div class='alert alert-$type border-0 shadow-sm rounded-3 mb-4 py-2 px-3 small fw-medium'>" . htmlspecialchars($text) . "</div>";
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // ---- Owner fields ----
    $id_number      = trim($_POST['id_number'] ?? '');
    $license_number = trim($_POST['license_number'] ?? '');
    $lastname       = trim($_POST['lastname'] ?? '');
    $firstname      = trim($_POST['firstname'] ?? '');
    $middlename     = trim($_POST['middlename'] ?? '');
    $type           = $_POST['type'] ?? '';
    $gender         = $_POST['gender'] ?? '';

    $street   = trim($_POST['street'] ?? '');
    $barangay = trim($_POST['barangay'] ?? '');
    $city     = trim($_POST['city'] ?? '');
    $address  = trim("$street, $barangay, $city");

    $phone     = trim($_POST['phone'] ?? '');
    $birthdate = $_POST['birthdate'] ?? '';
    $email     = trim($_POST['email'] ?? '');

    // ---- Vehicle fields (optional section) ----
    $plate_number = strtoupper(trim($_POST['plate_number'] ?? ''));
    $vehicle_type = trim($_POST['vehicle_type'] ?? '');
    $brand        = trim($_POST['brand'] ?? '');
    $model        = trim($_POST['model'] ?? '');
    $color        = trim($_POST['color'] ?? '');
    $hasVehicle   = ($plate_number !== '' || $vehicle_type !== '' || $brand !== '' || $model !== '' || $color !== '');

    $allowed_types = ['jpg', 'jpeg', 'png', 'webp'];
    $errors = [];

    if ($id_number === '' || $lastname === '' || $firstname === '') {
        $errors[] = "Please fill in all required owner fields.";
    }

    // Vehicle: if any field is filled, all must be filled
    if ($hasVehicle && ($plate_number === '' || $vehicle_type === '' || $brand === '' || $model === '' || $color === '')) {
        $errors[] = "Please complete all vehicle fields, or leave the whole vehicle section empty.";
    }

    // Validate license photo extension BEFORE saving anything
    $licenseExt = '';
    if (isset($_FILES['license_photo']) && $_FILES['license_photo']['error'] == 0) {
        $licenseExt = strtolower(pathinfo($_FILES['license_photo']['name'], PATHINFO_EXTENSION));
        if (!in_array($licenseExt, $allowed_types)) $errors[] = "Invalid license photo file type.";
    }

    // ---- Duplicate checks ----
    if (!$errors) {
        try {
            $chk = $pdo->prepare("SELECT COUNT(*) FROM owners WHERE id_number = ?");
            $chk->execute([$id_number]);
            if ($chk->fetchColumn() > 0) {
                $errors[] = "ID number already exists!";
            }

            if ($license_number !== '') {
                $chk = $pdo->prepare("SELECT COUNT(*) FROM owners WHERE license_number = ?");
                $chk->execute([$license_number]);
                if ($chk->fetchColumn() > 0) {
                    $errors[] = "License number already exists!";
                }
            }

            if ($hasVehicle) {
                $chk = $pdo->prepare("SELECT COUNT(*) FROM vehicles WHERE plate_number = ?");
                $chk->execute([$plate_number]);
                if ($chk->fetchColumn() > 0) {
                    $errors[] = "Plate number already registered!";
                }
            }
        } catch (PDOException $e) {
            $errors[] = "Error: " . $e->getMessage();
        }
    }

    // ---- Save ----
    if (!$errors) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) { mkdir($target_dir, 0777, true); }

        $safeId = preg_replace('/[^A-Za-z0-9\-]/', '', $id_number);
        $license_photo_name = "";
        $savedFiles = [];

        if ($licenseExt) {
            $license_photo_name = "license_" . $safeId . "_" . time() . "." . $licenseExt;
            if (move_uploaded_file($_FILES["license_photo"]["tmp_name"], $target_dir . $license_photo_name)) {
                $savedFiles[] = $target_dir . $license_photo_name;
            } else { $license_photo_name = ""; }
        }

        try {
            $pdo->beginTransaction();

            // The `photo` column is kept (empty) so the existing table structure still works.
            $stmt = $pdo->prepare("
                INSERT INTO owners
                (id_number, license_number, lastname, firstname, middlename, type, gender, address, phone_number, date_of_birth, email, photo, license_photo)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?)
            ");
            $stmt->execute([$id_number, $license_number, $lastname, $firstname, $middlename, $type, $gender, $address, $phone, $birthdate, $email, $license_photo_name]);
            $owner_id = $pdo->lastInsertId();

            if ($hasVehicle) {
                $stmtV = $pdo->prepare("INSERT INTO vehicles (plate_number, vehicle_type, brand, model, color, owner_id) VALUES (?, ?, ?, ?, ?, ?)");
                $stmtV->execute([$plate_number, $vehicle_type, $brand, $model, $color, $owner_id]);
            }

            $pdo->commit();
            $success = true;
            $message = alertBox('success', $hasVehicle ? "Owner and vehicle registered successfully!" : "Owner registered successfully!");
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            foreach ($savedFiles as $f) { if (file_exists($f)) unlink($f); }
            // 23000 = integrity constraint violation (duplicate key)
            if ($e->getCode() == 23000) {
                $message = alertBox('danger', "Duplicate entry: ID number, license number or plate number already exists.");
            } else {
                $message = alertBox('danger', "Error: " . $e->getMessage());
            }
        }
    } else {
        foreach ($errors as $err) { $message .= alertBox('danger', $err); }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Owner | KCC Tracking</title>
    <!-- Bootstrap 5 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        html { overflow-y: scroll; }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .nav-link-custom {
            color: #94a3b8;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.875rem;
        }

        .nav-link-custom:hover { color: #ffffff; background-color: rgba(255, 255, 255, 0.08); }
        .nav-link-custom.active { color: #ffffff; background-color: #2563eb; }

        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            animation: pageFadeIn 0.25s ease-out;
        }

        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        .form-card { padding: 2.5rem; }

        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }
        .btn-primary-custom:hover { background-color: var(--accent-blue-hover); color: #ffffff; }

        .btn-report {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            background: #ffffff;
            font-weight: 600;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }
        .btn-report:hover { background: #f1f5f9; border-color: #cbd5e1; color: var(--text-primary); }

        .form-control, .form-select {
            border-color: var(--border-color);
            border-radius: 10px;
            padding: 0.6rem 0.85rem;
            font-size: 0.9rem;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .license-preview-box {
            width: 140px; height: 90px; border-radius: 10px;
            background-color: #f1f5f9; border: 2px dashed #cbd5e1;
            display: flex; align-items: center; justify-content: center;
            overflow: hidden; position: relative; flex-shrink: 0;
        }
        .license-preview-box img { width: 100%; height: 100%; object-fit: cover; }

        .section-title {
            font-size: 0.75rem;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            font-weight: 700;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.5rem;
            margin-top: 1.5rem;
            margin-bottom: 1.25rem;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo" onerror="this.style.display='none'">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>

        <div class="d-none d-md-flex align-items-center gap-2">
            <a href="dashboard.php" class="nav-link-custom"><i class="bi bi-house-door me-1"></i> Overview</a>
            <a href="owner_list.php" class="nav-link-custom active"><i class="bi bi-people me-1"></i> Owners</a>
            <a href="vehicle_list.php" class="nav-link-custom"><i class="bi bi-car-front me-1"></i> Vehicles</a>
            <a href="logs.php" class="nav-link-custom"><i class="bi bi-journal-text me-1"></i> Logs</a>
        </div>

        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<main class="main-container">
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark">Owner Registration</h4>
            <p class="text-muted mb-0 small">Create a new profile (and optionally a vehicle) for the tracking system.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="owner_list.php" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                <i class="bi bi-arrow-left me-2"></i> Back to List
            </a>
        </div>
    </header>

    <div class="dashboard-card form-card">
        <?= $message; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="row mb-4 g-4">
                <div class="col-md-6 d-flex align-items-center gap-3">
                    <div class="license-preview-box" id="licensePreviewBox">
                        <i class="bi bi-card-image text-muted fs-2" id="licenseCamIcon"></i>
                        <img src="" id="licenseImgOutput" class="d-none">
                    </div>
                    <div class="flex-grow-1">
                        <label class="form-label fw-bold small text-muted text-uppercase">License ID Photo</label>
                        <input type="file" name="license_photo" class="form-control" accept="image/*" onchange="previewImage(event, 'licenseImgOutput', 'licenseCamIcon')">
                        <div class="form-text">Upload picture of physical ID/License.</div>
                    </div>
                </div>
            </div>

            <!-- Personal Information -->
            <div class="section-title">Personal Information</div>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label small fw-bold">ID Number <span class="text-danger">*</span></label>
                    <input type="text" name="id_number" class="form-control" placeholder="2024-XXXX" value="<?= old('id_number'); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">License Number</label>
                    <input type="text" name="license_number" class="form-control" placeholder="e.g. N01-23-456789" value="<?= old('license_number'); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Classification <span class="text-danger">*</span></label>
                    <select name="type" class="form-select" required>
                        <option value="">Select Category</option>
                        <?php foreach (['Staff','Student','Faculty','Guardian'] as $t): ?>
                            <option value="<?= $t; ?>" <?= selected('type', $t); ?>><?= $t; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-bold">First Name <span class="text-danger">*</span></label>
                    <input type="text" name="firstname" class="form-control" value="<?= old('firstname'); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Middle Name</label>
                    <input type="text" name="middlename" class="form-control" value="<?= old('middlename'); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Last Name <span class="text-danger">*</span></label>
                    <input type="text" name="lastname" class="form-control" value="<?= old('lastname'); ?>" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-bold">Gender</label>
                    <select name="gender" class="form-select" required>
                        <option value="Male" <?= selected('gender', 'Male'); ?>>Male</option>
                        <option value="Female" <?= selected('gender', 'Female'); ?>>Female</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Birthdate</label>
                    <input type="date" name="birthdate" class="form-control" value="<?= old('birthdate'); ?>">
                </div>
            </div>

            <!-- Home Address Details -->
            <div class="section-title">Home Address Details</div>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Street / Purok / House No.</label>
                    <input type="text" name="street" class="form-control" placeholder="e.g. Purok San Jose" value="<?= old('street'); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Barangay</label>
                    <input type="text" name="barangay" class="form-control" placeholder="e.g. Brg. Talubangi" value="<?= old('barangay'); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">City / Municipality</label>
                    <input type="text" name="city" class="form-control" placeholder="e.g. Kabankalan City" value="<?= old('city'); ?>">
                </div>
            </div>

            <!-- Contact Details -->
            <div class="section-title">Contact Information</div>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Mobile Number</label>
                    <input type="text" name="phone" class="form-control" placeholder="09xxxxxxxxx" value="<?= old('phone'); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="example@email.com" value="<?= old('email'); ?>">
                </div>
            </div>

            <!-- Vehicle Registration -->
            <div class="section-title">
                Vehicle Registration
                <span class="text-muted text-lowercase fw-normal ms-1">(optional — leave empty to register owner only)</span>
            </div>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Plate Number</label>
                    <input type="text" name="plate_number" id="plateInput" class="form-control text-uppercase" placeholder="ABC 1234" value="<?= old('plate_number'); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Vehicle Type</label>
                    <select name="vehicle_type" class="form-select">
                        <option value="">Select Type</option>
                        <?php foreach (['Car','Motorcycle','SUV','Van','Truck','Tricycle'] as $vt): ?>
                            <option value="<?= $vt; ?>" <?= selected('vehicle_type', $vt); ?>><?= $vt; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Brand</label>
                    <input type="text" name="brand" class="form-control" placeholder="Toyota, Honda, etc." value="<?= old('brand'); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Model</label>
                    <input type="text" name="model" class="form-control" placeholder="Vios, Civic, etc." value="<?= old('model'); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Color</label>
                    <input type="text" name="color" class="form-control" placeholder="Black, White, Red, etc." value="<?= old('color'); ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-primary-custom w-100 mt-5 py-3 rounded-3 fw-bold shadow-sm">
                <i class="bi bi-check-circle me-2"></i> Register Owner Profile
            </button>
        </form>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function previewImage(event, outputId, iconId) {
        var file = event.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function(){
            var output = document.getElementById(outputId);
            var icon = document.getElementById(iconId);
            output.src = reader.result;
            output.classList.remove('d-none');
            icon.classList.add('d-none');
        };
        reader.readAsDataURL(file);
    }
</script>
</body>
</html>