<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}

$owner_id = $_GET['id'] ?? null;
if (!$owner_id) { die("Owner ID not provided!"); }

$stmt_owner = $pdo->prepare("SELECT * FROM owners WHERE id = ?");
$stmt_owner->execute([$owner_id]);
$owner = $stmt_owner->fetch();

if (!$owner) { die("Owner not found!"); }

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $plate_number  = strtoupper(trim($_POST['plate_number']));
    $vehicle_type  = trim($_POST['vehicle_type']);
    $brand         = trim($_POST['brand']);
    $model         = trim($_POST['model']);
    $color         = trim($_POST['color']);

    if ($plate_number && $vehicle_type && $brand && $model && $color) {
        try {
            $stmt = $pdo->prepare("INSERT INTO vehicles (plate_number, vehicle_type, brand, model, color, owner_id) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$plate_number, $vehicle_type, $brand, $model, $color, $owner_id])) {
                $message = "
                <div class='alert alert-success border-0 shadow-sm rounded-3 mb-4 d-flex align-items-center py-2 px-3' role='alert'>
                    <i class='bi bi-check-circle-fill me-2'></i>
                    <div class='fw-medium small'>Vehicle registered successfully!</div>
                </div>";
            }
        } catch(PDOException $e) {
            $message = "<div class='alert alert-danger border-0 shadow-sm rounded-3 mb-4 d-flex align-items-center py-2 px-3' role='alert'><i class='bi bi-exclamation-triangle-fill me-2'></i><div class='fw-medium small'>Error: Plate number already registered.</div></div>";
        }
    } else {
        $message = "<div class='alert alert-warning border-0 shadow-sm rounded-3 mb-4 d-flex align-items-center py-2 px-3' role='alert'><i class='bi bi-exclamation-circle-fill me-2'></i><div class='fw-medium small'>Please fill all required fields!</div></div>";
    }
}

if (isset($_GET['status'])) {
    $status_type = $_GET['status'] == 'deleted' ? 'danger' : 'info';
    $status_msg  = $_GET['status'] == 'deleted' ? 'Vehicle removed.' : 'Vehicle updated.';
    $message = "<div class='alert alert-$status_type border-0 shadow-sm rounded-3 mb-4 py-2 px-3 small fw-medium' role='alert'>$status_msg</div>";
}

$stmt_vehicles = $pdo->prepare("SELECT * FROM vehicles WHERE owner_id = ? ORDER BY id DESC");
$stmt_vehicles->execute([$owner_id]);
$registered_vehicles = $stmt_vehicles->fetchAll();

$ownerName = trim(($owner['firstname'] ?? '') . ' ' . ($owner['lastname'] ?? ''));
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Vehicle | KCC Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        /* Prevents navbar/layout shift when a page has or lacks a scrollbar */
        html {
            overflow-y: scroll;
        }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        /* Top Navigation Header Bar */
        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .nav-link-custom {
            color: #94a3b8;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.875rem;
        }

        .nav-link-custom:hover {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.08);
        }

        .nav-link-custom.active {
            color: #ffffff;
            background-color: #2563eb;
        }

        /* Main Container Wrapper (with smooth page-load fade-in) */
        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            animation: pageFadeIn 0.25s ease-out;
        }

        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        .form-card {
            padding: 2rem;
        }

        /* Buttons (shared with other pages) */
        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }

        .btn-primary-custom:hover {
            background-color: var(--accent-blue-hover);
            color: #ffffff;
        }

        .btn-report {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            background: #ffffff;
            font-weight: 600;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-report:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--text-primary);
        }

        /* Form controls */
        .form-control,
        .form-select {
            border-color: var(--border-color);
            border-radius: 10px;
            padding: 0.6rem 0.85rem;
            font-size: 0.9rem;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        /* Owner profile card */
        .owner-info-card {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            color: #ffffff;
            border: none;
            padding: 2rem;
        }

        .owner-photo-large {
            width: 75px;
            height: 75px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #3b82f6;
        }

        .photo-placeholder {
            width: 75px;
            height: 75px;
            border-radius: 50%;
            background-color: #334155;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.75rem;
            color: #94a3b8;
            border: 2px solid #3b82f6;
        }

        .info-pill {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 0.75rem;
            border-radius: 12px;
        }

        /* Table Styling (same as other pages) */
        .table {
            margin-bottom: 0;
            width: 100%;
        }

        .table thead th {
            background: #f8fafc;
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
        }

        .table tbody td {
            padding: 1.1rem 1.25rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }

        .table tbody tr:last-child td {
            border-bottom: none;
        }

        .vehicle-row:hover {
            background-color: #f8fafc;
        }

        .plate-badge {
            background-color: #1e293b;
            color: #38bdf8;
            padding: 0.35rem 0.75rem;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.825rem;
            letter-spacing: 0.05em;
            display: inline-block;
            border: 1px solid #334155;
            font-family: monospace;
        }
    </style>
</head>
<body>

<!-- Unified Top Navigation Bar -->
<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo" onerror="this.style.display='none'">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>

        <div class="d-none d-md-flex align-items-center gap-2">
            <a href="dashboard.php" class="nav-link-custom"><i class="bi bi-house-door me-1"></i> Overview</a>
            <a href="owner_list.php" class="nav-link-custom active"><i class="bi bi-people me-1"></i> Owners</a>
            <a href="vehicle_list.php" class="nav-link-custom"><i class="bi bi-car-front me-1"></i> Vehicles</a>
            <a href="logs.php" class="nav-link-custom"><i class="bi bi-journal-text me-1"></i> Logs</a>
        </div>

        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<main class="main-container">
    <!-- Header Section (same structure as logs.php / vehicle_list.php) -->
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark">Register Vehicle</h4>
            <p class="text-muted mb-0 small">Linking vehicle data to <span class="text-primary fw-bold"><?= htmlspecialchars($ownerName); ?></span>'s profile.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="owner_list.php" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                <i class="bi bi-arrow-left me-2"></i> Back to Owners
            </a>
        </div>
    </header>

    <div class="row g-4">
        <div class="col-lg-7">
            <?= $message; ?>
            <div class="dashboard-card form-card">
                <form method="POST">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted text-uppercase">Plate Number</label>
                            <input type="text" name="plate_number" class="form-control text-uppercase" placeholder="ABC 1234" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted text-uppercase">Vehicle Type</label>
                            <select name="vehicle_type" class="form-select" required>
                                <option value="">Select Type</option>
                                <option value="Car">Car</option>
                                <option value="Motorcycle">Motorcycle</option>
                                <option value="SUV">SUV</option>
                                <option value="Van">Van</option>
                                <option value="Truck">Truck</option>
                                <option value="Tricycle">Tricycle</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted text-uppercase">Brand</label>
                            <input type="text" name="brand" class="form-control" placeholder="Toyota, Honda, etc." required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted text-uppercase">Model</label>
                            <input type="text" name="model" class="form-control" placeholder="Vios, Civic, etc." required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold text-muted text-uppercase">Color</label>
                            <input type="text" name="color" class="form-control" placeholder="Black, White, Red, etc." required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary-custom px-4 py-3 rounded-3 fw-bold w-100 mt-5 shadow-sm">
                        <i class="bi bi-plus-circle me-2"></i> Register Vehicle
                    </button>
                </form>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="dashboard-card owner-info-card h-100">
                <h6 class="text-uppercase fw-bold mb-4 opacity-75 small">Target Owner Profile</h6>
                <div class="d-flex align-items-center mb-5">
                    <div class="me-4">
                        <?php if(!empty($owner['photo']) && file_exists("uploads/" . $owner['photo'])): ?>
                            <img src="uploads/<?= htmlspecialchars($owner['photo']); ?>" class="owner-photo-large shadow" alt="Owner">
                        <?php else: ?>
                            <div class="photo-placeholder shadow"><i class="bi bi-person"></i></div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="small opacity-75">Owner Name</div>
                        <h4 class="fw-bold mb-0"><?= htmlspecialchars($ownerName); ?></h4>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-6">
                        <div class="info-pill">
                            <div class="opacity-50 text-uppercase fw-bold" style="font-size: 0.65rem;">ID Number</div>
                            <div class="fw-bold"><?= htmlspecialchars($owner['id_number'] ?? ''); ?></div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="info-pill">
                            <div class="opacity-50 text-uppercase fw-bold" style="font-size: 0.65rem;">Category</div>
                            <div class="fw-bold"><?= htmlspecialchars($owner['type'] ?? ''); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Registered vehicles -->
    <div class="mt-5">
        <header class="mb-3 d-flex justify-content-between align-items-end">
            <div>
                <h5 class="fw-bold mb-1 text-dark">Registered Vehicles</h5>
                <p class="text-muted small mb-0">Assets linked to this profile.</p>
            </div>
            <div class="bg-white px-3 py-2 rounded-3 border d-flex align-items-center">
                <i class="bi bi-car-front-fill me-2 text-primary"></i>
                <span class="small text-muted fw-bold">Total: <?= count($registered_vehicles); ?></span>
            </div>
        </header>

        <div class="dashboard-card overflow-hidden">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Plate Number</th>
                            <th>Type</th>
                            <th>Brand</th>
                            <th>Model</th>
                            <th class="pe-4">Color</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($registered_vehicles): ?>
                            <?php foreach($registered_vehicles as $vehicle): ?>
                            <tr class="vehicle-row">
                                <td class="ps-4"><span class="plate-badge"><?= htmlspecialchars($vehicle['plate_number'] ?? ''); ?></span></td>
                                <td><span class="badge bg-light text-dark border px-2 py-1 small fw-semibold"><?= htmlspecialchars($vehicle['vehicle_type'] ?? ''); ?></span></td>
                                <td class="fw-bold small"><?= htmlspecialchars($vehicle['brand'] ?? ''); ?></td>
                                <td class="small"><?= htmlspecialchars($vehicle['model'] ?? ''); ?></td>
                                <td class="pe-4 small fw-medium"><?= htmlspecialchars($vehicle['color'] ?? ''); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">
                                    <i class="bi bi-inbox fs-2 d-block mb-2 text-secondary opacity-50"></i>
                                    No vehicles registered yet.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>