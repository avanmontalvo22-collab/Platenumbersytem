<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}

// Validate the month (YYYY-MM); fall back to the current month
$selected_month = (isset($_GET['month']) && preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $_GET['month']))
    ? $_GET['month']
    : date('Y-m');

// Date range for the month (uses the log_time index better than DATE_FORMAT)
$range_start = $selected_month . '-01 00:00:00';
$range_end   = date('Y-m-d 00:00:00', strtotime($range_start . ' +1 month'));

// Shared log query. It reads the same saved fields the Logs page shows (owner, type, brand,
// color). If a log row has none of them (e.g. "Not Registered"), the plate is matched to a
// registered vehicle ignoring spaces, dashes and letter case to fill in the details.
$logSelect = "SELECT l.id, l.plate_number, l.manual_name, l.action, l.photo, l.log_time,
                     COALESCE(NULLIF(NULLIF(l.vehicle_type, 'Not Registered'), ''), v.vehicle_type) AS vehicle_type,
                     COALESCE(NULLIF(NULLIF(l.brand, 'Not Registered'), ''), v.brand) AS brand,
                     COALESCE(NULLIF(l.color, ''), v.color) AS color,
                     COALESCE(NULLIF(NULLIF(l.owner_name, 'Not Registered'), ''),
                              NULLIF(TRIM(CONCAT(o.firstname, ' ', o.lastname)), '')) AS owner_name
              FROM logs l
              LEFT JOIN vehicles v
                     ON REPLACE(REPLACE(UPPER(v.plate_number), ' ', ''), '-', '')
                      = REPLACE(REPLACE(UPPER(l.plate_number), ' ', ''), '-', '')
              LEFT JOIN owners o ON v.owner_id = o.id";

// ---------- CSV EXPORTS ----------
if (isset($_GET['export'])) {
    try {
        if (ob_get_level()) {
            ob_end_clean();
        }

        if ($_GET['export'] === 'daily') {
            // Day-by-day summary
            $stmt = $pdo->prepare("
                SELECT DATE(l.log_time) AS log_day,
                       COUNT(*) AS total,
                       SUM(l.action = 'IN') AS ins,
                       SUM(l.action = 'OUT') AS outs,
                       COUNT(DISTINCT l.plate_number) AS plates
                FROM logs l
                WHERE l.log_time >= ? AND l.log_time < ?
                GROUP BY DATE(l.log_time)
                ORDER BY log_day ASC
            ");
            $stmt->execute([$range_start, $range_end]);
            $daily = $stmt->fetchAll(PDO::FETCH_ASSOC);

            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="KCC_Daily_Summary_' . $selected_month . '.csv"');

            $output = fopen('php://output', 'w');
            fputcsv($output, ['Date', 'Day', 'Total Logs', 'IN', 'OUT', 'Unique Plates']);

            $sumTotal = $sumIn = $sumOut = 0;
            foreach ($daily as $d) {
                fputcsv($output, [
                    $d['log_day'],
                    date('l', strtotime($d['log_day'])),
                    $d['total'],
                    $d['ins'],
                    $d['outs'],
                    $d['plates']
                ]);
                $sumTotal += (int)$d['total'];
                $sumIn    += (int)$d['ins'];
                $sumOut   += (int)$d['outs'];
            }
            fputcsv($output, ['TOTAL', '', $sumTotal, $sumIn, $sumOut, '']);
            fclose($output);
            exit();
        }

        if ($_GET['export'] === 'csv') {
            // Full log list, oldest first, one row per log
            $stmt = $pdo->prepare($logSelect . " WHERE l.log_time >= ? AND l.log_time < ? ORDER BY l.log_time ASC");
            $stmt->execute([$range_start, $range_end]);
            $report_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="KCC_Monthly_Report_' . $selected_month . '.csv"');

            $output = fopen('php://output', 'w');
            fputcsv($output, ['Date', 'Time', 'Plate Number', 'Vehicle Type', 'Brand', 'Color', 'Owner Name', 'Visitor Name (Manual)', 'Direction']);

            foreach ($report_logs as $row) {
                $ts = strtotime($row['log_time']);
                fputcsv($output, [
                    date('Y-m-d', $ts),
                    date('h:i:s A', $ts),
                    $row['plate_number'],
                    $row['vehicle_type'] ?: '---',
                    $row['brand'] ?: 'Not Registered',
                    $row['color'] ?: '---',
                    $row['owner_name'] ?: 'Not Registered',
                    $row['manual_name'] ?: '--',
                    $row['action']
                ]);
            }
            fclose($output);
            exit();
        }
    } catch (PDOException $e) {
        die("Error generating spreadsheet: " . $e->getMessage());
    }
}

// ---------- PAGE DATA ----------
try {
    $stmt = $pdo->prepare($logSelect . " WHERE l.log_time >= ? AND l.log_time < ? ORDER BY l.log_time DESC");
    $stmt->execute([$range_start, $range_end]);
    $monthly_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $monthly_logs = [];
}

// Group the logs day by day (newest day first, because the query is DESC)
$days = [];
$totalIn = 0;
$totalOut = 0;
foreach ($monthly_logs as $log) {
    $key = date('Y-m-d', strtotime($log['log_time']));
    if (!isset($days[$key])) {
        $days[$key] = ['logs' => [], 'in' => 0, 'out' => 0, 'plates' => []];
    }
    $days[$key]['logs'][] = $log;
    if (($log['action'] ?? '') === 'IN') {
        $days[$key]['in']++;
        $totalIn++;
    } else {
        $days[$key]['out']++;
        $totalOut++;
    }
    $days[$key]['plates'][$log['plate_number']] = true;
}

// Daily bar strip data (every day of the month)
$daysInMonth = (int)date('t', strtotime($selected_month . '-01'));
$maxPerDay = 1;
foreach ($days as $d) {
    $maxPerDay = max($maxPerDay, count($d['logs']));
}

// Month dropdown options (last 12 months, plus the selected one if it is older)
$month_options = [];
for ($i = 0; $i < 12; $i++) {
    $month_options[date('Y-m', strtotime("-$i months"))] = date('F Y', strtotime("-$i months"));
}
if (!isset($month_options[$selected_month])) {
    $month_options = [$selected_month => date('F Y', strtotime($selected_month . '-01'))] + $month_options;
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Report | KCC Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        /* Prevents navbar/layout shift when a page has or lacks a scrollbar */
        html {
            overflow-y: scroll;
            scroll-behavior: smooth;
        }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        /* Top Navigation Header Bar */
        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .nav-link-custom {
            color: #94a3b8;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.875rem;
        }

        .nav-link-custom:hover {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.08);
        }

        .nav-link-custom.active {
            color: #ffffff;
            background-color: #2563eb;
        }

        /* Main Container Wrapper (with smooth page-load fade-in) */
        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            animation: pageFadeIn 0.25s ease-out;
        }

        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        .search-box {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .search-box:focus-within {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-select {
            border-color: var(--border-color);
            border-radius: 12px;
            font-size: 0.875rem;
            font-weight: 600;
        }

        .form-select:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        /* Buttons (shared with other pages) */
        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }

        .btn-primary-custom:hover,
        .btn-primary-custom:focus,
        .btn-primary-custom.show {
            background-color: var(--accent-blue-hover);
            color: #ffffff;
        }

        .btn-report {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            background: #ffffff;
            font-weight: 600;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-report:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--text-primary);
        }

        /* Summary stat tiles */
        .stat-tile {
            padding: 1rem 1.25rem;
        }

        .stat-label {
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--text-secondary);
        }

        .stat-value {
            font-size: 1.6rem;
            font-weight: 800;
            line-height: 1.2;
        }

        /* Daily bar strip */
        .day-strip {
            display: flex;
            align-items: flex-end;
            gap: 4px;
            height: 84px;
            overflow-x: auto;
            padding-bottom: 2px;
        }

        .day-bar {
            flex: 1 0 14px;
            min-width: 14px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-end;
            text-decoration: none;
            color: var(--text-secondary);
            font-size: 0.6rem;
            font-weight: 600;
        }

        .day-bar .bar {
            width: 100%;
            border-radius: 4px 4px 0 0;
            background: var(--accent-blue);
            transition: background-color 0.2s ease, transform 0.2s ease;
        }

        .day-bar.empty .bar {
            background: #e2e8f0;
        }

        .day-bar:not(.empty):hover .bar {
            background: var(--accent-blue-hover);
            transform: scaleY(1.04);
        }

        .day-bar span {
            margin-top: 3px;
        }

        /* Table Styling */
        .table {
            margin-bottom: 0;
            width: 100%;
        }

        .table thead th {
            background: #f8fafc;
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 1rem 1rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
        }

        .table tbody td {
            padding: 0.9rem 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }

        /* Day header row */
        .day-header td {
            background: #eef2f7;
            border-top: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
            padding: 0.75rem 1rem;
            scroll-margin-top: 80px;
        }

        .log-row:hover {
            background-color: #f8fafc;
        }

        .plate-badge {
            background-color: #1e293b;
            color: #38bdf8;
            padding: 0.35rem 0.75rem;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.825rem;
            letter-spacing: 0.05em;
            display: inline-block;
            border: 1px solid #334155;
            font-family: monospace;
        }

        .status-badge {
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0.35rem 0.85rem;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
        }

        .badge-in  { background-color: #10b981; color: #ffffff; }
        .badge-out { background-color: #ef4444; color: #ffffff; }
    </style>
</head>
<body>

<!-- Unified Top Navigation Bar -->
<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo" onerror="this.style.display='none'">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>

        <div class="d-none d-md-flex align-items-center gap-2">
            <a href="dashboard.php" class="nav-link-custom"><i class="bi bi-house-door me-1"></i> Overview</a>
            <a href="owner_list.php" class="nav-link-custom"><i class="bi bi-people me-1"></i> Owners</a>
            <a href="vehicle_list.php" class="nav-link-custom"><i class="bi bi-car-front me-1"></i> Vehicles</a>
            <a href="logs.php" class="nav-link-custom active"><i class="bi bi-journal-text me-1"></i> Logs</a>
        </div>

        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<main class="main-container">
    <!-- Header Section (same structure as logs.php / vehicle_list.php) -->
    <header class="d-flex flex-column flex-xl-row justify-content-between align-items-xl-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark">Monthly Activity Report</h4>
            <p class="text-muted mb-0 small">Day-by-day vehicle gate activity for the selected month.</p>
        </div>

        <div class="d-flex flex-wrap gap-2 align-items-center">
            <a href="logs.php" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                <i class="bi bi-arrow-left me-2"></i> Back to Live Logs
            </a>

            <form method="GET" class="m-0">
                <select name="month" class="form-select px-3 py-2 shadow-sm" onchange="this.form.submit()">
                    <?php foreach ($month_options as $m_val => $m_lbl): ?>
                        <option value="<?= htmlspecialchars($m_val); ?>" <?= $m_val === $selected_month ? 'selected' : ''; ?>><?= htmlspecialchars($m_lbl); ?></option>
                    <?php endforeach; ?>
                </select>
            </form>

            <div class="dropdown">
                <button class="btn btn-primary-custom rounded-3 px-3 py-2 text-sm d-flex align-items-center dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-file-earmark-spreadsheet me-2"></i> Export Data
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3 p-2">
                    <li>
                        <a class="dropdown-item rounded-2 small fw-semibold" href="?month=<?= urlencode($selected_month); ?>&export=daily">
                            <i class="bi bi-calendar-week me-2"></i> Daily summary (day by day)
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item rounded-2 small fw-semibold" href="?month=<?= urlencode($selected_month); ?>&export=csv">
                            <i class="bi bi-list-ul me-2"></i> Full log list
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <!-- Summary tiles -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <div class="dashboard-card stat-tile">
                <div class="stat-label">Total Logs</div>
                <div class="stat-value" id="logCountBadge"><?= count($monthly_logs); ?></div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="dashboard-card stat-tile">
                <div class="stat-label">Vehicles IN</div>
                <div class="stat-value text-success"><?= $totalIn; ?></div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="dashboard-card stat-tile">
                <div class="stat-label">Vehicles OUT</div>
                <div class="stat-value text-danger"><?= $totalOut; ?></div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="dashboard-card stat-tile">
                <div class="stat-label">Active Days</div>
                <div class="stat-value"><?= count($days); ?> <span class="fs-6 text-muted fw-semibold">/ <?= $daysInMonth; ?></span></div>
            </div>
        </div>
    </div>

    <!-- Day-by-day bar strip -->
    <div class="dashboard-card p-3 mb-4">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <span class="small text-muted fw-bold text-uppercase">
                Daily activity &mdash; <span class="text-dark"><?= date('F Y', strtotime($selected_month . '-01')); ?></span>
            </span>
            <span class="small text-muted">Click a bar to jump to that day</span>
        </div>
        <div class="day-strip">
            <?php for ($d = 1; $d <= $daysInMonth; $d++):
                $key   = sprintf('%s-%02d', $selected_month, $d);
                $count = isset($days[$key]) ? count($days[$key]['logs']) : 0;
                $h     = $count > 0 ? max(8, (int)round($count / $maxPerDay * 60)) : 4;
                $tip   = date('M d', strtotime($key)) . ': ' . $count . ' log' . ($count === 1 ? '' : 's');
            ?>
                <?php if ($count > 0): ?>
                    <a href="#day-<?= $key; ?>" class="day-bar" title="<?= htmlspecialchars($tip); ?>">
                        <div class="bar" style="height: <?= $h; ?>px;"></div>
                        <span><?= $d; ?></span>
                    </a>
                <?php else: ?>
                    <div class="day-bar empty" title="<?= htmlspecialchars($tip); ?>">
                        <div class="bar" style="height: <?= $h; ?>px;"></div>
                        <span><?= $d; ?></span>
                    </div>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
    </div>

    <!-- Search -->
    <div class="dashboard-card p-2 mb-4">
        <div class="search-box d-flex align-items-center px-3 py-1">
            <i class="bi bi-search text-muted fs-6 me-2"></i>
            <input type="text" id="tableSearch" class="form-control border-0 shadow-none py-2 bg-transparent text-sm" placeholder="Search plate, type, brand, color, owner, or visitor..." autocomplete="off">
        </div>
    </div>

    <!-- Logs grouped day by day -->
    <div class="dashboard-card overflow-hidden">
        <div class="table-responsive">
            <table class="table align-middle mb-0" id="logsTable">
                <thead>
                    <tr>
                        <th class="ps-4">Plate Number</th>
                        <th>Type</th>
                        <th>Brand</th>
                        <th>Color</th>
                        <th>Owner Name</th>
                        <th>Manual Entry</th>
                        <th>Time</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>

                <?php if ($days): foreach ($days as $dayKey => $day): ?>
                <tbody class="day-group" id="day-<?= $dayKey; ?>">
                    <tr class="day-header">
                        <td colspan="8">
                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-calendar-event text-primary"></i>
                                    <span class="fw-bold text-dark"><?= date('l, F d, Y', strtotime($dayKey)); ?></span>
                                </div>
                                <div class="d-flex flex-wrap gap-2">
                                    <span class="badge bg-dark rounded-pill px-3 py-2"><?= count($day['logs']); ?> log<?= count($day['logs']) === 1 ? '' : 's'; ?></span>
                                    <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2"><i class="bi bi-arrow-down-left-circle-fill me-1"></i><?= $day['in']; ?> IN</span>
                                    <span class="badge bg-danger-subtle text-danger rounded-pill px-3 py-2"><i class="bi bi-arrow-up-right-circle-fill me-1"></i><?= $day['out']; ?> OUT</span>
                                    <span class="badge bg-light text-dark border rounded-pill px-3 py-2"><i class="bi bi-car-front me-1"></i><?= count($day['plates']); ?> vehicle<?= count($day['plates']) === 1 ? '' : 's'; ?></span>
                                </div>
                            </div>
                        </td>
                    </tr>

                    <?php foreach ($day['logs'] as $log):
                        $hasBrand = !empty($log['brand']);
                        $hasOwner = !empty($log['owner_name']);
                        $isIn     = ($log['action'] ?? '') === 'IN';
                    ?>
                    <tr class="log-row">
                        <td class="ps-4"><span class="plate-badge"><?= htmlspecialchars($log['plate_number']); ?></span></td>
                        <td>
                            <?php if (!empty($log['vehicle_type'])): ?>
                                <span class="badge bg-light text-dark border px-2 py-1 small fw-semibold"><?= htmlspecialchars($log['vehicle_type']); ?></span>
                            <?php else: ?>
                                <span class="text-muted small">---</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($hasBrand): ?>
                                <span class="fw-semibold text-dark small"><?= htmlspecialchars($log['brand']); ?></span>
                            <?php elseif ($hasOwner): ?>
                                <span class="text-muted small">Registered</span>
                            <?php else: ?>
                                <span class="fw-semibold text-danger small"><i class="bi bi-exclamation-triangle me-1"></i>Not Registered</span>
                            <?php endif; ?>
                        </td>
                        <td class="small fw-medium"><?= !empty($log['color']) ? htmlspecialchars($log['color']) : '<span class="text-muted">---</span>'; ?></td>
                        <td class="small fw-semibold text-dark"><?= $hasOwner ? htmlspecialchars($log['owner_name']) : '<span class="text-muted fw-normal">Not Registered</span>'; ?></td>
                        <td class="small text-muted"><?= !empty($log['manual_name']) ? htmlspecialchars($log['manual_name']) : '--'; ?></td>
                        <td class="small fw-bold text-dark"><?= date('h:i A', strtotime($log['log_time'])); ?></td>
                        <td class="text-center">
                            <span class="status-badge <?= $isIn ? 'badge-in' : 'badge-out'; ?>">
                                <i class="bi <?= $isIn ? 'bi-arrow-down-left-circle-fill' : 'bi-arrow-up-right-circle-fill'; ?> me-1"></i><?= htmlspecialchars($log['action'] ?? ''); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <?php endforeach; else: ?>
                <tbody>
                    <tr id="noRecordsRow">
                        <td colspan="8" class="text-center py-5 text-muted">
                            <i class="bi bi-journal-x fs-2 d-block mb-2 opacity-50"></i>
                            No records found for this month.
                        </td>
                    </tr>
                </tbody>
                <?php endif; ?>

                <tbody>
                    <tr id="noMatchesRow" style="display: none;">
                        <td colspan="8" class="text-center py-5 text-muted">No matching records found.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Real-time search: filters rows and hides any day that has no matching rows
    document.getElementById('tableSearch').addEventListener('input', function () {
        const query = this.value.toLowerCase().trim();
        const rows = document.querySelectorAll('.log-row');
        let visibleCount = 0;

        rows.forEach(function (row) {
            const match = row.textContent.toLowerCase().includes(query);
            row.style.display = match ? '' : 'none';
            if (match) visibleCount++;
        });

        document.querySelectorAll('.day-group').forEach(function (group) {
            const anyVisible = Array.from(group.querySelectorAll('.log-row'))
                .some(function (r) { return r.style.display !== 'none'; });
            group.style.display = anyVisible ? '' : 'none';
        });

        const badge = document.getElementById('logCountBadge');
        if (badge) badge.textContent = visibleCount;

        const noMatches = document.getElementById('noMatchesRow');
        if (noMatches) {
            noMatches.style.display = (visibleCount === 0 && rows.length > 0) ? '' : 'none';
        }
    });
</script>
</body>
</html>