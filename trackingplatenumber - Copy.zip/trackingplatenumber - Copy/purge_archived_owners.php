<?php
/**
 * Permanently purge owners that have been archived for more than 30 days.
 *
 * Run this script daily using the server's cron/scheduled-task facility:
 *   php /path/to/your/project/purge_archived_owners.php
 *
 * Keep this script CLI-only so it cannot be triggered from a public URL.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("CLI only.\n");
}

require __DIR__ . '/config.php';

$cutoff = (new DateTimeImmutable('now'))->modify('-30 days')->format('Y-m-d H:i:s');

$stmt = $pdo->prepare(
    "SELECT id, photo, license_photo
     FROM owners
     WHERE deleted_at IS NOT NULL AND deleted_at <= ?"
);
$stmt->execute([$cutoff]);
$owners = $stmt->fetchAll(PDO::FETCH_ASSOC);

$deleted = 0;
foreach ($owners as $owner) {
    $ownerId = (int)$owner['id'];

    try {
        $pdo->beginTransaction();

        $stmtLogs = $pdo->prepare("
            DELETE l FROM logs l
            INNER JOIN vehicles v
                ON REPLACE(REPLACE(UPPER(v.plate_number), ' ', ''), '-', '')
                 = REPLACE(REPLACE(UPPER(l.plate_number), ' ', ''), '-', '')
            WHERE v.owner_id = ?
        ");
        $stmtLogs->execute([$ownerId]);

        $stmtVehicles = $pdo->prepare("DELETE FROM vehicles WHERE owner_id = ?");
        $stmtVehicles->execute([$ownerId]);

        $stmtOwner = $pdo->prepare(
            "DELETE FROM owners WHERE id = ? AND deleted_at IS NOT NULL AND deleted_at <= ?"
        );
        $stmtOwner->execute([$ownerId, $cutoff]);

        $pdo->commit();

        if ($stmtOwner->rowCount() > 0) {
            foreach (['photo', 'license_photo'] as $field) {
                if (!empty($owner[$field])) {
                    $path = __DIR__ . '/uploads/' . basename($owner[$field]);
                    if (is_file($path)) {
                        @unlink($path);
                    }
                }
            }
            $deleted++;
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Archived owner purge failed for owner {$ownerId}: " . $e->getMessage());
    }
}

echo "Purged {$deleted} archived owner record(s).\\n";
