import sys
sys.stdout.reconfigure(encoding='utf-8')
import os

# Always run from this script's own folder, so "camdetect/" snapshots land next to
# index.php no matter where PHP/Apache launched the process from.
os.chdir(os.path.dirname(os.path.abspath(__file__)))

import cv2
import imutils
import easyocr
import mysql.connector
import numpy as np
import time
import winsound

os.makedirs("camdetect", exist_ok=True)

db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "smart_plate_system"
}

def process_plate_automatic(plate_text, frame):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # 1. Alamin muna ang huling action (IN o OUT) ng platong ito sa database
        cursor.execute(
            """
            SELECT action, UNIX_TIMESTAMP(log_time) FROM logs
            WHERE REPLACE(plate_number, ' ', '') = %s
            ORDER BY log_time DESC, id DESC
            LIMIT 1
            """,
            (plate_text,)
        )
        last_row = cursor.fetchone()
        
        current_time = time.time()
        
        # 2. COOLDOWN CHECK: Kung na-detect na ito wala pang 2 minutes (120 seconds), huwag munang galawin
        if last_row:
            last_action, last_timestamp = last_row
            time_diff = current_time - last_timestamp
            if time_diff < 120:  # 120 seconds = 2 minutes
                # Tahimik lang tayong mag-skip habang pasok pa sa 2-minute window
                return False

        # 3. AUTOMATIC TOGGLE: Kung walang record pa o lampas na sa 2 minuto, baligtarin ang huling status
        if last_row and last_row[0] == "IN":
            new_action = "OUT"
        else:
            new_action = "IN"

        # Generate unique photo filename with timestamp
        timestamp_str = time.strftime("%Y%m%d_%H%M%S")
        photo_filename = f"{plate_text}_{timestamp_str}.jpg"
        photo_path = os.path.join("camdetect", photo_filename)

        # Save the frame snapshot to disk
        cv2.imwrite(photo_path, frame)

        # Hanapin ang may-ari sa vehicles/owners table
        search_query = """
            SELECT v.brand, v.vehicle_type, CONCAT(o.firstname, ' ', o.lastname)
            FROM vehicles v
            JOIN owners o ON v.owner_id = o.id
            WHERE REPLACE(v.plate_number, ' ', '') = %s
        """
        cursor.execute(search_query, (plate_text,))
        result = cursor.fetchone()

        if result:
            brand, v_type, full_name = result
            log_query = """
                INSERT INTO logs (plate_number, manual_name, brand, vehicle_type, action, log_time, photo)
                VALUES (%s, %s, %s, %s, %s, NOW(), %s)
            """
            cursor.execute(log_query, (plate_text, full_name, brand, v_type, new_action, photo_filename))
            conn.commit()

            print(f"✅ [AUTOMATIC {new_action}] Log Saved & Snapshot Captured: {plate_text} | {brand} | Owner: {full_name}")
            winsound.Beep(1200 if new_action == "IN" else 900, 250)
            return True
        else:
            log_query = """
                INSERT INTO logs (plate_number, manual_name, brand, vehicle_type, action, log_time, photo)
                VALUES (%s, %s, %s, %s, %s, NOW(), %s)
            """
            cursor.execute(log_query, (plate_text, "Not Registered", "Not Registered", "Not Registered", new_action, photo_filename))
            conn.commit()

            print(f"⚠️ [UNREGISTERED AUTOMATIC {new_action}] Log Saved: {plate_text}. Registered as Guest.")
            winsound.Beep(500, 100)
            time.sleep(0.05)
            winsound.Beep(500, 1850)
            return True

    except mysql.connector.Error as err:
        print(f"❌ [DB Error]: {err}")
        return False
    finally:
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()

print("⏳ Loading OCR model (first run may download files)...")
reader = easyocr.Reader(['en'], gpu=False)

# Open the camera (DirectShow is the most reliable backend on Windows)
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
if not cap.isOpened():
    cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ [Camera Error]: Could not open camera 0. Check that it is plugged in.")
    sys.exit(1)

print("🚀 KCC Tracking System Active (Automatic 2-Minute Cooldown & IN/OUT Toggle)... Press 'q' to stop.")

show_window = True

while True:
    ret, frame = cap.read()
    if not ret:
        print("❌ [Camera Error]: Lost the camera feed. Stopping.")
        break

    frame = imutils.resize(frame, width=640)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    bfilter = cv2.bilateralFilter(gray, 11, 17, 17)
    edged = cv2.Canny(bfilter, 30, 200)

    keypoints = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = imutils.grab_contours(keypoints)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]

    location = None
    for contour in contours:
        approx = cv2.approxPolyDP(contour, 10, True)
        if len(approx) == 4:
            location = approx
            break

    if location is not None:
        cv2.drawContours(frame, [location], 0, (0, 255, 0), 3)
        mask = np.zeros(gray.shape, np.uint8)
        cv2.drawContours(mask, [location], 0, 255, -1)

        (x, y) = np.where(mask == 255)
        if len(x) > 0:
            (topx, topy) = (np.min(x), np.min(y))
            (bottomx, bottomy) = (np.max(x), np.max(y))
            cropped_gray = gray[max(0, topx-5):bottomx+5, max(0, topy-5):bottomy+5]

            results = reader.readtext(cropped_gray)

            if results:
                for res in results:
                    detected_text = res[1].upper().replace(" ", "").replace("-", "")

                    if any(word in detected_text for word in ["PHILIPPINES", "REPUBLIKA", "NCR", "DOTR"]):
                        continue

                    if 5 <= len(detected_text) <= 8:
                        plate_text = detected_text
                        cv2.putText(frame, plate_text, (topy, topx - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                        # Isinasagawa ang automatic detection at 2-minute restriction dito
                        process_plate_automatic(plate_text, frame)
                        break

    if show_window:
        try:
            cv2.imshow('KCC Smart Plate Detection', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        except Exception as e:
            show_window = False
            print(f"⚠️ Display fallback: {e}")

cap.release()
cv2.destroyAllWindows()