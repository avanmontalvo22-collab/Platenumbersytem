-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2026 at 08:23 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_plate_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `phone_verified` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `created_at`, `email`, `phone`, `email_verified`, `phone_verified`) VALUES
(1, 'admin', '$2y$10$683R2G1m7aDFFcyzjjVcruqgrJIFWyKSrGnxSTy8jflcu5RG/nPaG', '2026-02-25 14:51:46', NULL, NULL, 0, 0),
(2, 'AVANMONTALVO22', 'a41a19d414c04f86070b68a5f034c1aa', '2026-10-11 09:47:20', NULL, NULL, 0, 0),
(3, 'avanmontal', '48c43f355e1a12452be861deeb78df27', '2026-10-11 09:58:20', NULL, NULL, 0, 0),
(4, 'avanmontalvo', '$2y$10$6XlCRqJSpMWcp.cOubAOxeqMYrUbhs/apoDovd03wh8/TfxDGazyC', '2026-10-22 07:47:36', NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `manual_name` varchar(255) DEFAULT NULL,
  `owner_name` varchar(150) NOT NULL,
  `vehicle_type` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `color` varchar(50) DEFAULT NULL,
  `log_time` datetime NOT NULL DEFAULT current_timestamp(),
  `action` enum('IN','OUT') NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `photo_vehicle` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `plate_number`, `manual_name`, `owner_name`, `vehicle_type`, `brand`, `color`, `log_time`, `action`, `photo`, `photo_vehicle`) VALUES
(152, 'NCB1234', NULL, 'Avan Montalvo', '', '', NULL, '2026-04-05 20:35:07', 'IN', NULL, NULL),
(153, 'NCB1234', NULL, 'Avan Montalvo', '', '', NULL, '2026-04-05 20:55:47', 'IN', NULL, NULL),
(154, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-05 21:00:27', 'OUT', NULL, NULL),
(155, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-05 21:04:39', 'IN', NULL, NULL),
(156, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-05 23:18:12', 'IN', NULL, NULL),
(157, 'BORJAK', NULL, 'AVAN MONTA', 'SUV', 'KARBAW', NULL, '2026-04-05 23:21:46', 'IN', NULL, NULL),
(158, 'BORJAK', NULL, 'AVAN MONTA', 'SUV', 'KARBAW', NULL, '2026-04-06 14:43:09', 'IN', NULL, NULL),
(159, 'TOTO1', NULL, 'AVAN MONTA', 'Car', 'TRUCK', NULL, '2026-04-06 15:16:46', 'IN', NULL, NULL),
(160, 'BORJAK', NULL, 'AVAN MONTA', 'SUV', 'KARBAW', NULL, '2026-04-07 10:06:35', 'IN', NULL, NULL),
(161, 'BORJAK', NULL, 'AVAN MONTA', 'SUV', 'KARBAW', NULL, '2026-04-07 10:06:58', 'IN', NULL, NULL),
(162, 'BORJAK', NULL, 'AVAN MONTA', 'SUV', 'KARBAW', NULL, '2026-04-07 10:09:17', 'OUT', NULL, NULL),
(163, 'BORJAK', NULL, '', '', '', NULL, '2026-04-07 15:59:53', 'IN', NULL, NULL),
(164, 'NCB1234', NULL, '', '', '', NULL, '2026-04-07 16:00:00', 'OUT', NULL, NULL),
(165, '2213123', NULL, '', '', '', NULL, '2026-04-07 16:05:15', 'IN', NULL, NULL),
(166, 'TUKO123', NULL, 'avan staana', 'Sedan', 'Toyota', NULL, '2026-04-07 16:52:19', 'IN', NULL, NULL),
(167, 'TUKO123', NULL, 'avan staana', 'Motorcycle', 'Toyota', NULL, '2026-04-07 17:01:39', 'OUT', NULL, NULL),
(168, 'TUKO123', NULL, 'avan staana', 'Motorcycle', 'Toyota', NULL, '2026-04-07 17:02:10', 'IN', NULL, NULL),
(169, 'TUKO123', NULL, 'avan staana', 'Motorcycle', 'Toyota', NULL, '2026-04-07 17:02:21', 'OUT', NULL, NULL),
(170, 'TUKO123', NULL, 'avan staana', 'Motorcycle', 'Toyota', NULL, '2026-04-07 17:02:22', 'IN', NULL, NULL),
(171, 'TUKO123', NULL, 'avan staana', 'Motorcycle', 'Toyota', NULL, '2026-04-07 17:02:23', 'OUT', NULL, NULL),
(172, 'TUKO123', NULL, '', '', '', NULL, '2026-04-07 17:25:01', 'IN', NULL, NULL),
(173, 'TUKO', NULL, '', '', '', NULL, '2026-04-07 17:35:45', 'IN', NULL, NULL),
(174, '123123', NULL, '', '', '', NULL, '2026-04-07 17:36:08', 'IN', NULL, NULL),
(175, '123123', NULL, '', '', '', NULL, '2026-04-07 17:39:59', 'IN', NULL, NULL),
(176, '123123', NULL, '', '', '', NULL, '2026-04-14 17:08:26', 'IN', NULL, NULL),
(177, 'ASDAS12312', 'asdas', '', '', '', NULL, '2026-04-14 17:30:53', 'IN', NULL, NULL),
(178, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-15 15:04:24', 'IN', NULL, NULL),
(179, 'NCB 1234', 'avan', '', '', '', NULL, '2026-04-15 15:05:11', 'IN', NULL, NULL),
(180, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-15 16:27:43', 'OUT', NULL, NULL),
(181, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-15 17:13:34', 'IN', NULL, NULL),
(182, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-15 17:13:49', 'OUT', NULL, NULL),
(183, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-16 16:44:45', 'IN', NULL, NULL),
(184, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-04-16 16:45:18', 'OUT', NULL, NULL),
(185, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-10 17:59:31', 'IN', NULL, NULL),
(186, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-10 18:00:37', 'OUT', NULL, NULL),
(187, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-10 18:02:33', 'IN', NULL, NULL),
(188, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-10 18:08:35', 'OUT', NULL, NULL),
(189, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-10 18:08:45', 'IN', NULL, NULL),
(190, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-10 18:51:19', 'OUT', NULL, NULL),
(191, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-14 08:32:00', 'IN', NULL, NULL),
(192, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-14 08:32:02', 'OUT', NULL, NULL),
(193, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-14 08:32:05', 'IN', NULL, NULL),
(194, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-14 08:32:07', 'OUT', NULL, NULL),
(195, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-14 08:32:23', 'IN', NULL, NULL),
(196, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-14 08:32:57', 'OUT', NULL, NULL),
(197, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-14 08:34:16', 'IN', NULL, NULL),
(198, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-14 08:34:24', 'OUT', NULL, NULL),
(199, 'PILPINA', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:22:34', 'IN', NULL, NULL),
(200, 'TYT2451', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:22:35', 'IN', NULL, NULL),
(201, 'TYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:22:36', 'IN', NULL, NULL),
(202, 'ALIIS', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:25:33', 'IN', NULL, NULL),
(203, 'PILIPINE', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:25:34', 'IN', NULL, NULL),
(204, 'TYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:25:35', 'OUT', NULL, NULL),
(205, 'TYT245)', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:25:37', 'IN', NULL, NULL),
(206, 'FYT245]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:35:26', 'IN', NULL, NULL),
(207, 'FYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:35:26', 'IN', NULL, NULL),
(208, 'FYT245]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:35:27', 'OUT', NULL, NULL),
(209, 'TYT2451', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:35:28', 'OUT', NULL, NULL),
(210, 'TYT245]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:35:29', 'IN', NULL, NULL),
(211, 'FYT245]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:35:30', 'IN', NULL, NULL),
(212, 'TYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:35:30', 'IN', NULL, NULL),
(213, 'TYT245)', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:35:31', 'OUT', NULL, NULL),
(214, 'FY1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:39:09', 'IN', NULL, NULL),
(215, 'TYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:39:10', 'OUT', NULL, NULL),
(216, 'TYT245)', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:39:23', 'IN', NULL, NULL),
(217, 'ITYT2451', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:42:12', 'IN', NULL, NULL),
(218, 'TYT2451', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:42:15', 'IN', NULL, NULL),
(219, 'TYT245/', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-18 14:42:16', 'IN', NULL, NULL),
(220, 'TYT2451', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 12:08:33', 'OUT', NULL, NULL),
(221, '6N245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 12:08:34', 'IN', NULL, NULL),
(222, 'ATYT2454', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 12:08:35', 'IN', NULL, NULL),
(223, 'TYT2451', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 12:08:38', 'IN', NULL, NULL),
(224, '920039', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 16:07:29', 'IN', NULL, NULL),
(225, '123123123A', 'Avava123', '', '', '', NULL, '2026-05-21 17:28:45', 'IN', NULL, NULL),
(226, 'TYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:23:00', 'IN', NULL, NULL),
(227, 'TYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:23:22', 'OUT', NULL, NULL),
(228, 'MLE124', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:23:42', 'IN', NULL, NULL),
(229, 'CB1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:23:54', 'IN', NULL, NULL),
(230, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-21 18:23:55', 'IN', NULL, NULL),
(231, 'NCB12J', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:25:15', 'IN', NULL, NULL),
(232, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-21 18:25:16', 'OUT', NULL, NULL),
(233, 'NCB123+', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:25:20', 'IN', NULL, NULL),
(234, 'TYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:27:42', 'IN', NULL, NULL),
(235, 'TVT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:27:52', 'IN', NULL, NULL),
(236, '12,54', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:28:17', 'IN', NULL, NULL),
(237, 'NCB1234|', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:28:29', 'IN', NULL, NULL),
(238, 'NCB123', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:28:45', 'IN', NULL, NULL),
(239, 'NCB1254', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:28:51', 'IN', NULL, NULL),
(240, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-21 18:29:01', 'IN', NULL, NULL),
(241, '12,J\"', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:56:23', 'IN', NULL, NULL),
(242, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-21 18:56:32', 'OUT', NULL, NULL),
(243, 'TYT245/', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:56:52', 'OUT', NULL, NULL),
(244, 'ITYT2451', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 18:56:56', 'OUT', NULL, NULL),
(245, 'TYT245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 19:13:05', 'OUT', NULL, NULL),
(246, '1234|', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-21 19:13:26', 'IN', NULL, NULL),
(247, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-21 19:13:28', 'IN', NULL, NULL),
(248, '1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-27 18:34:59', 'IN', NULL, NULL),
(249, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-05-27 18:35:13', 'OUT', NULL, NULL),
(250, '1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-05-27 18:35:13', 'OUT', NULL, NULL),
(251, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-06-05 17:25:46', 'IN', NULL, NULL),
(252, 'NCB1234|', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:25:47', 'OUT', NULL, NULL),
(253, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-06-05 17:26:22', 'OUT', NULL, NULL),
(254, 'TYT245]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:26:48', 'OUT', NULL, NULL),
(255, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-06-05 17:28:45', 'IN', NULL, NULL),
(256, 'NCB1234)', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:28:45', 'IN', NULL, NULL),
(257, 'NCB1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:28:58', 'IN', NULL, NULL),
(258, '12341', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:29:10', 'IN', NULL, NULL),
(259, 'NCB1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:30:00', 'OUT', NULL, NULL),
(260, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-06-05 17:30:03', 'OUT', NULL, NULL),
(261, 'NCB1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:30:03', 'IN', NULL, NULL),
(262, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-06-05 17:30:06', 'IN', NULL, NULL),
(263, 'NCB1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:30:08', 'OUT', NULL, NULL),
(264, '41234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:30:11', 'IN', NULL, NULL),
(265, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-06-05 17:34:57', 'OUT', NULL, NULL),
(266, 'NCB1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-06-05 17:35:01', 'IN', NULL, NULL),
(267, 'ISE8J', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-09-22 15:10:06', 'IN', NULL, NULL),
(268, 'AESL&/', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-09-22 15:10:12', 'IN', NULL, NULL),
(269, 'OUIUM', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-09-22 15:10:32', 'IN', NULL, NULL),
(270, 'AGSLUJ6', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-09-22 15:11:29', 'IN', NULL, NULL),
(271, 'NE1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-09-22 15:13:00', 'IN', NULL, NULL),
(272, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-09-22 15:13:04', 'IN', NULL, NULL),
(273, 'PPINES', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-09-22 15:13:33', 'IN', NULL, NULL),
(274, '\'^134', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-09-23 14:38:11', 'IN', '\'^134_20260923_143811.jpg', NULL),
(275, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-09-23 14:49:59', 'OUT', 'exit_20260923_144959_NCB1234.jpg', NULL),
(276, 'NCB123', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-07 17:40:02', 'OUT', 'NCB123_20261007_174002.jpg', NULL),
(277, 'CD1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-07 17:40:26', 'IN', 'CD1234_20261007_174026.jpg', NULL),
(278, 'NCB23', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-07 17:40:33', 'IN', 'NCB23_20261007_174033.jpg', NULL),
(279, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-10-08 14:49:57', 'IN', 'NCB1234_20261008_144957.jpg', NULL),
(280, 'NNCB1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-08 14:49:58', 'IN', 'NNCB1234_20261008_144958.jpg', NULL),
(281, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-10-08 14:50:22', 'OUT', 'NCB1234_20261008_145022.jpg', NULL),
(282, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-10-08 14:50:38', 'IN', 'NCB1234_20261008_145038.jpg', NULL),
(283, 'NCB1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-08 14:50:54', 'OUT', 'NCB1234]_20261008_145054.jpg', NULL),
(284, 'NNCB1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-08 14:50:56', 'OUT', 'NNCB1234_20261008_145056.jpg', NULL),
(285, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-10-08 14:50:59', 'OUT', 'NCB1234_20261008_145059.jpg', NULL),
(286, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-10-09 15:49:04', 'IN', 'NCB1234_20261009_154904.jpg', NULL),
(287, 'NCB1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-09 15:49:06', 'IN', 'NCB1234]_20261009_154906.jpg', NULL),
(288, 'KCD12348', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-09 15:50:47', 'IN', 'KCD12348_20261009_155047.jpg', NULL),
(289, 'WCB1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-09 15:50:50', 'IN', 'WCB1234_20261009_155050.jpg', NULL),
(290, 'NCB1234', NULL, 'Avan Montalvo', 'Motorcycle', 'NMAX', NULL, '2026-10-09 15:51:27', 'OUT', 'NCB1234_20261009_155126.jpg', NULL),
(291, 'NCE1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-09 15:51:27', 'IN', 'NCE1234_20261009_155127.jpg', NULL),
(292, 'Y:1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-09 15:51:30', 'IN', 'Y:1234_20261009_155130.jpg', NULL),
(293, '12341', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-09 15:51:42', 'OUT', '12341_20261009_155142.jpg', NULL),
(294, 'WTELLTE', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-12 15:38:23', 'IN', 'WTELLTE_20261012_153823.jpg', NULL),
(295, 'LAEERIA', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-12 15:38:37', 'IN', 'LAEERIA_20261012_153837.jpg', NULL),
(296, 'MESTERN', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-12 15:39:20', 'IN', 'MESTERN_20261012_153920.jpg', NULL),
(297, 'WESTERN', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-12 15:39:23', 'IN', 'WESTERN_20261012_153923.jpg', NULL),
(298, '56781', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-12 15:39:26', 'IN', '56781_20261012_153926.jpg', NULL),
(299, 'ENTRY', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-13 15:44:15', 'IN', 'ENTRY_20261013_154415.jpg', NULL),
(300, 'CUTSA', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:01:29', 'IN', 'CUTSA_20261016_160129.jpg', NULL),
(301, 'FAC5678', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:01:39', 'IN', 'FAC5678_20261016_160139.jpg', NULL),
(302, 'WESTERN', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:01:42', 'IN', 'WESTERN_20261016_160142.jpg', NULL),
(303, '5678]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:01:47', 'IN', '5678]_20261016_160147.jpg', NULL),
(304, 'REGIONVI', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:01:55', 'IN', 'REGIONVI_20261016_160155.jpg', NULL),
(305, 'FAC56781', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:01:58', 'IN', 'FAC56781_20261016_160158.jpg', NULL),
(306, 'FAC56281', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:02:04', 'IN', 'FAC56281_20261016_160204.jpg', NULL),
(307, 'WESTERN', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:02:07', 'IN', 'WESTERN_20261016_160207.jpg', NULL),
(308, 'FAC5678', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:02:09', 'IN', 'FAC5678_20261016_160209.jpg', NULL),
(309, 'FAC56781', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:02:12', 'IN', 'FAC56781_20261016_160212.jpg', NULL),
(310, 'IFAT7659', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:27:04', 'IN', 'IFAT7659_20261016_162704.jpg', NULL),
(311, 'FAT3095', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:38:56', 'IN', 'FAT3095_20261016_163854.jpg', NULL),
(312, 'FB923N', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:42:38', 'IN', 'FB923N_20261016_164238.jpg', NULL),
(313, 'J214T', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:50:25', 'IN', 'J214T_20261016_165025.jpg', NULL),
(314, 'FJ214T', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:50:28', 'IN', 'FJ214T_20261016_165028.jpg', NULL),
(315, 'JFJ214]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:50:30', 'IN', 'JFJ214]_20261016_165030.jpg', NULL),
(316, '[J2161', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:50:32', 'IN', '[J2161_20261016_165032.jpg', NULL),
(317, 'FIE3747', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:50:44', 'IN', 'FIE3747_20261016_165044.jpg', NULL),
(318, 'FC5O54', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:51:27', 'IN', 'FC5O54_20261016_165127.jpg', NULL),
(319, 'FG857Q', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:51:38', 'IN', 'FG857Q_20261016_165138.jpg', NULL),
(320, 'FG8570', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:51:40', 'IN', 'FG8570_20261016_165140.jpg', NULL),
(321, 'FG857Q,', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:51:42', 'IN', 'FG857Q,_20261016_165142.jpg', NULL),
(322, 'FG8570,', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-16 16:51:45', 'IN', 'FG8570,_20261016_165145.jpg', NULL),
(323, 'YUMUUAY', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-20 16:10:14', 'IN', 'YUMUUAY_20261020_161014.jpg', NULL),
(324, 'V1SUUAV', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-20 16:10:16', 'IN', 'V1SUUAV_20261020_161016.jpg', NULL),
(325, '(ECZ1', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-20 16:10:18', 'IN', '(ECZ1_20261020_161018.jpg', NULL),
(326, 'V150QAY', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-20 16:10:20', 'IN', 'V150QAY_20261020_161020.jpg', NULL),
(327, 'COUGH', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-20 16:11:57', 'IN', 'COUGH_20261020_161157.jpg', NULL),
(328, '\"ZLVO', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-20 16:16:26', 'IN', '\"ZLVO_20261020_161626.jpg', NULL),
(329, 'ZIZECG', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:40:47', 'IN', 'ZIZECG_20261022_144046.jpg', NULL),
(330, 'BJ:3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:40:58', 'IN', 'BJ:3212_20261022_144058.jpg', NULL),
(331, 'BJ3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:41:55', 'IN', 'BJ3212_20261022_144155.jpg', NULL),
(332, 'STATE', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:42:20', 'IN', 'STATE_20261022_144220.jpg', NULL),
(333, 'SFATE', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:42:28', 'IN', 'SFATE_20261022_144228.jpg', NULL),
(334, 'STATE', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:42:31', 'IN', 'STATE_20261022_144231.jpg', NULL),
(335, 'SMART', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:42:34', 'IN', 'SMART_20261022_144234.jpg', NULL),
(336, 'BJ3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:42:50', 'IN', 'BJ3212_20261022_144250.jpg', NULL),
(337, 'BJ3212|', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:42:58', 'IN', 'BJ3212|_20261022_144258.jpg', NULL),
(338, 'BJ3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:43:08', 'IN', 'BJ3212_20261022_144308.jpg', NULL),
(339, 'BJ3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:45:12', 'IN', 'BJ3212_20261022_144512.jpg', NULL),
(340, 'BJ:3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:45:28', 'IN', 'BJ:3212_20261022_144528.jpg', NULL),
(341, 'BJ3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:45:32', 'IN', 'BJ3212_20261022_144532.jpg', NULL),
(342, '3J.3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:45:40', 'IN', '3J.3212_20261022_144540.jpg', NULL),
(343, 'BJ3242', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:46:05', 'IN', 'BJ3242_20261022_144605.jpg', NULL),
(344, 'BJ*3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:46:07', 'IN', 'BJ*3212_20261022_144607.jpg', NULL),
(345, 'BJ3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:46:10', 'IN', 'BJ3212_20261022_144610.jpg', NULL),
(346, 'STATE', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:46:17', 'IN', 'STATE_20261022_144617.jpg', NULL),
(347, 'BJ3212', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:46:21', 'IN', 'BJ3212_20261022_144621.jpg', NULL),
(348, 'QW1245', NULL, 'toto sta ana', 'Motorcycle', '123', NULL, '2026-10-22 14:56:56', 'IN', 'QW1245_20261022_145656.jpg', NULL),
(349, 'OW1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-22 14:56:58', 'IN', 'OW1245_20261022_145658.jpg', NULL),
(350, 'QW1245', NULL, 'toto sta ana', 'Motorcycle', '123', NULL, '2026-10-22 14:57:02', 'IN', 'QW1245_20261022_145702.jpg', NULL),
(351, 'AVAN', 'Toto', '', 'Car', '', NULL, '2026-10-23 16:00:21', 'IN', 'manual_1792742421_6adb1415adc8c.png', NULL),
(352, 'Q1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:15:46', 'IN', 'Q1245_20261023_161546.jpg', NULL),
(353, '0W1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:15:49', 'IN', '0W1245_20261023_161549.jpg', NULL),
(354, 'QW1245', NULL, 'toto sta ana', 'Motorcycle', '123', NULL, '2026-10-23 16:15:53', 'IN', 'QW1245_20261023_161553.jpg', NULL),
(355, 'QW1245', NULL, 'toto sta ana', 'Motorcycle', '123', NULL, '2026-10-23 16:16:23', 'IN', 'QW1245_20261023_161623.jpg', NULL),
(356, '0W1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:16:26', 'IN', '0W1245_20261023_161626.jpg', NULL),
(357, 'QW1245', NULL, 'toto sta ana', 'Motorcycle', '123', NULL, '2026-10-23 16:16:28', 'IN', 'QW1245_20261023_161628.jpg', NULL),
(358, 'OM1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:16:31', 'IN', 'OM1245_20261023_161631.jpg', NULL),
(359, 'QW1245', NULL, 'toto sta ana', 'Motorcycle', '123', NULL, '2026-10-23 16:16:33', 'IN', 'QW1245_20261023_161633.jpg', NULL),
(360, 'QH1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:16:57', 'IN', 'QH1245_20261023_161657.jpg', NULL),
(361, '0W1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:17:14', 'IN', '0W1245_20261023_161714.jpg', NULL),
(362, '0W245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:17:17', 'IN', '0W245_20261023_161717.jpg', NULL),
(363, '0W1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:17:20', 'IN', '0W1245_20261023_161720.jpg', NULL),
(364, 'ELROO)', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:17:47', 'IN', 'ELROO)_20261023_161747.jpg', NULL),
(365, 'QW1245', NULL, 'toto sta ana', 'Motorcycle', '123', NULL, '2026-10-23 16:31:21', 'OUT', 'QW1245_20261023_163121.jpg', NULL),
(366, 'NCB1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:36:50', 'IN', 'NCB1234_20261023_163650.jpg', NULL),
(367, 'NCB1234]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:36:56', 'OUT', 'NCB1234]_20261023_163656.jpg', NULL),
(368, 'OW1245', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:38:03', 'OUT', 'OW1245_20261023_163803.jpg', NULL),
(369, 'QW1245', NULL, 'toto sta ana', 'Motorcycle', '123', NULL, '2026-10-23 16:38:05', 'IN', 'QW1245_20261023_163805.jpg', NULL),
(370, 'NCB1234', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-23 16:39:00', 'OUT', 'NCB1234_20261023_163900.jpg', NULL),
(371, 'FAH30091', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:11:53', 'IN', 'FAH30091_20261026_161153.jpg', NULL),
(372, '[F1\"C5', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:11:57', 'IN', '[F1\"C5_20261026_161157.jpg', NULL),
(373, 'ECORCO', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:12:40', 'IN', 'ECORCO_20261026_161240.jpg', NULL),
(374, 'KBH1722', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:12:42', 'IN', 'KBH1722_20261026_161242.jpg', NULL),
(375, 'IEBING', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:13:28', 'IN', 'IEBING_20261026_161328.jpg', NULL),
(376, '[63430J', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:17:30', 'IN', '[63430J_20261026_161730.jpg', NULL),
(377, '[6J430J', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:17:32', 'IN', '[6J430J_20261026_161732.jpg', NULL),
(378, '710501', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:25:01', 'IN', '710501_20261026_162501.jpg', NULL),
(379, 'EAJ1146', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:25:17', 'IN', 'EAJ1146_20261026_162517.jpg', NULL),
(380, 'EAJ11461', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:25:20', 'IN', 'EAJ11461_20261026_162520.jpg', NULL),
(381, 'EAJ1146]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:25:23', 'IN', 'EAJ1146]_20261026_162523.jpg', NULL),
(382, 'EAJ1146', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:25:25', 'OUT', 'EAJ1146_20261026_162525.jpg', NULL),
(383, 'EAJ1146_', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:25:27', 'IN', 'EAJ1146__20261026_162527.jpg', NULL),
(384, 'EAJ1146]', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:25:30', 'OUT', 'EAJ1146]_20261026_162530.jpg', NULL),
(385, 'FBA14454', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:25:35', 'IN', 'FBA14454_20261026_162535.jpg', NULL),
(386, 'NCP1392', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:01', 'IN', 'NCP1392_20261026_162601.jpg', NULL),
(387, '13921', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:03', 'IN', '13921_20261026_162603.jpg', NULL),
(388, 'FAT2727', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:10', 'IN', 'FAT2727_20261026_162610.jpg', NULL),
(389, 'FAD8620', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:16', 'IN', 'FAD8620_20261026_162616.jpg', NULL),
(390, 'FAD8020', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:18', 'IN', 'FAD8020_20261026_162618.jpg', NULL),
(391, 'FD,8020', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:21', 'IN', 'FD,8020_20261026_162621.jpg', NULL),
(392, '7002D', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:23', 'IN', '7002D_20261026_162623.jpg', NULL),
(393, 'FAU6716', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:25', 'IN', 'FAU6716_20261026_162625.jpg', NULL),
(394, 'FAU6710', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:30', 'IN', 'FAU6710_20261026_162630.jpg', NULL),
(395, 'FFAU6710', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:32', 'IN', 'FFAU6710_20261026_162632.jpg', NULL),
(396, 'FAI2098', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:37', 'IN', 'FAI2098_20261026_162637.jpg', NULL),
(397, 'FAL2028', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:40', 'IN', 'FAL2028_20261026_162640.jpg', NULL),
(398, 'FAI9935', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:46', 'IN', 'FAI9935_20261026_162646.jpg', NULL),
(399, 'FAI9935', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:26:51', 'OUT', 'FAI9935_20261026_162651.jpg', NULL),
(400, 'FAT3095', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:27:06', 'OUT', 'FAT3095_20261026_162706.jpg', NULL),
(401, '3095,', NULL, 'Not Registered', 'Not Registered', 'Not Registered', NULL, '2026-10-26 16:27:09', 'IN', '3095,_20261026_162709.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE `owners` (
  `id` int(11) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `license_number` varchar(50) DEFAULT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `type` enum('Teacher','Student','Faculty','Guardian') NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `license_photo` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`id`, `id_number`, `license_number`, `lastname`, `firstname`, `middlename`, `type`, `gender`, `photo`, `address`, `phone_number`, `date_of_birth`, `email`, `created_at`, `license_photo`, `deleted_at`) VALUES
(12, '12312313', NULL, 'Pitongs', 'toto', 'jason', 'Student', 'Male', 'owner_12312313_1791710570.jpg', 'muhon, binix, kabankalan city', '0925123121', '2005-04-24', 'jasonpitongs@gmail.com', '2026-10-11 09:22:50', 'license_12312313_1791710570.jpg', NULL),
(14, '12312122', '1122ssd', 'sta ana', 'toto', 'evan', 'Faculty', 'Male', 'owner_12312122_1791715149.jpg', 'alogbati, gi, sipalax', '092851233', '2004-02-11', 'avanmontalvo22@gmail.com', '2026-10-11 10:39:09', 'license_12312122_1791715149.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `vehicle_type` varchar(50) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `owner_id`, `plate_number`, `vehicle_type`, `brand`, `model`, `color`, `created_at`) VALUES
(13, 14, 'BJ2312', 'SUV', 'Honda', 'Civic', 'Blue', '2026-10-12 07:18:02'),
(14, 14, 'QW1245', 'Motorcycle', '123', 'qweqwewq', 'Blue', '2026-10-22 06:47:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_number` (`id_number`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plate_number` (`plate_number`),
  ADD KEY `owner_id` (`owner_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=402;

--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
