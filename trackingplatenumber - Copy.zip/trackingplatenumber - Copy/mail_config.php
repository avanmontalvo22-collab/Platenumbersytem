<?php
// ---- SMTP (Gmail example: use an App Password, NOT your normal password) ----
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'youraddress@gmail.com');
define('MAIL_PASS', 'your-16-char-app-password');
define('MAIL_FROM', 'youraddress@gmail.com');
define('MAIL_FROM_NAME', 'KCC Tracking');

// ---- SMS (Semaphore - https://semaphore.co) ----
define('SEMAPHORE_API_KEY', 'your-semaphore-api-key');
define('SEMAPHORE_SENDER', 'SEMAPHORE');   // approved sender name

// ---- OTP settings ----
define('OTP_SECRET', 'change-this-to-a-long-random-string');
define('OTP_TTL', 600);            // code valid for 10 minutes
define('OTP_RESEND_WAIT', 60);     // seconds before a new code can be requested
define('OTP_MAX_ATTEMPTS', 5);     // wrong guesses allowed per code
