<?php
session_start();
require 'config.php';

if (isset($_SESSION['admin'])) { header("Location: dashboard.php"); exit(); }

if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));

$message = "";

$MAX_FAILS = 5;          // failed attempts allowed...
$LOCK_SECONDS = 300;     // ...before a 5-minute lockout (per browser session)

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['login_btn'])) {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $error = "";

    $fails = (int)($_SESSION['login_fails'] ?? 0);
    $lockedUntil = (int)($_SESSION['login_locked_until'] ?? 0);

    if (!hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
        $error = "Your session expired. Please reload the page and try again.";
    } elseif ($lockedUntil > time()) {
        $error = "Too many failed attempts. Try again in a few minutes.";
    } else {
        $stmt = $pdo->prepare("SELECT id, username, password FROM admins WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        $ok = false;
        if ($admin) {
            $stored = (string)$admin['password'];
            if (password_verify($password, $stored)) {
                $ok = true;
                if (password_needs_rehash($stored, PASSWORD_DEFAULT)) {
                    $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?")
                        ->execute([password_hash($password, PASSWORD_DEFAULT), $admin['id']]);
                }
            } elseif (strlen($stored) === 32 && hash_equals($stored, md5($password))) {
                // Legacy md5 account: accept once, then upgrade to a secure hash
                $ok = true;
                $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?")
                    ->execute([password_hash($password, PASSWORD_DEFAULT), $admin['id']]);
            }
        }

        if ($ok) {
            session_regenerate_id(true);
            unset($_SESSION['login_fails'], $_SESSION['login_locked_until']);
            $_SESSION['admin'] = $admin['username'];
            header("Location: dashboard.php");
            exit();
        }

        $fails++;
        $_SESSION['login_fails'] = $fails;
        if ($fails >= $MAX_FAILS) {
            $_SESSION['login_locked_until'] = time() + $LOCK_SECONDS;
            $_SESSION['login_fails'] = 0;
        }
        $error = "Invalid credentials.";
    }

    if ($error !== "") {
        $message = "<div class='alert alert-danger border-0 small py-2'>" . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . "</div>";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | KCC Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/admin.css">
</head>
<body>
<div class="container">
    <div class="login-card mx-auto">
        <div class="text-center">
            <img src="images-removebg-preview.png" alt="Logo" class="logo-img">
            <h4 class="fw-bold mb-1">KCC Tracking</h4>
            <p class="text-muted small mb-4">Secure Administrative Portal</p>
        </div>

        <?= $message; ?>

        <form method="POST">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
            <div class="mb-3">
                <label class="form-label small fw-bold text-muted">Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-0"><i class="bi bi-person text-muted"></i></span>
                    <input type="text" name="username" class="form-control bg-light border-0" placeholder="Enter username" required>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label small fw-bold text-muted">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-0"><i class="bi bi-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control bg-light border-0" placeholder="••••••••" required>
                </div>
            </div>
            <button type="submit" name="login_btn" class="btn btn-primary w-100 fw-bold shadow-sm">
                Sign In <i class="bi bi-arrow-right ms-2"></i>
            </button>
        </form>

        <p class="small text-center text-muted mt-3 mb-0">
            Don't have an account? <a href="create_account.php" class="fw-bold text-decoration-none">Create account</a>
        </p>

        <div class="mt-4 pt-3 border-top text-center">
            <p class="small text-muted mb-0">&copy; 2026 KCCcamguarddetection</p>
        </div>
    </div>
</div>
</body>
</html>