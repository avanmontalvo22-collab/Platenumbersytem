<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}

$search = trim($_GET['search'] ?? '');

try {
    if (!empty($search)) {
        $stmt = $pdo->prepare("SELECT v.*, o.firstname, o.lastname, o.photo 
                               FROM vehicles v 
                               LEFT JOIN owners o ON v.owner_id = o.id 
                               WHERE v.plate_number LIKE ? 
                                  OR v.brand LIKE ? 
                                  OR v.model LIKE ? 
                                  OR v.license_number LIKE ? 
                                  OR CONCAT(o.firstname, ' ', o.lastname) LIKE ?
                               ORDER BY v.id DESC");
        $term = "%$search%";
        $stmt->execute([$term, $term, $term, $term, $term]);
    } else {
        $stmt = $pdo->query("SELECT v.*, o.firstname, o.lastname, o.photo 
                               FROM vehicles v 
                               LEFT JOIN owners o ON v.owner_id = o.id 
                               ORDER BY v.id DESC");
    }
    $vehicles = $stmt->fetchAll();
} catch(PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Fleet | KCC Tracking</title>
    <!-- Bootstrap 5 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --font-family-base: 'Plus Jakarta Sans', sans-serif;
            --bg-body: #f0f4f8;
            --panel-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-blue: #2563eb;
            --accent-blue-hover: #1d4ed8;
            --card-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
            --border-radius: 16px;
        }

        /* Prevents navbar/layout shift when a page has or lacks a scrollbar */
        html {
            overflow-y: scroll;
        }

        body {
            font-family: var(--font-family-base);
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            margin: 0;
        }

        /* Top Navigation Header Bar */
        .navbar {
            background: linear-gradient(90deg, #0f172a 0%, #1e293b 100%) !important;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-bottom: 2px solid #2563eb;
        }

        .navbar-logo {
            height: 40px;
            width: auto;
            object-fit: contain;
            filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.2));
        }

        .tracking-brand-text {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.05em;
        }

        .nav-link-custom {
            color: #94a3b8;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.875rem;
        }

        .nav-link-custom:hover {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.08);
        }

        .nav-link-custom.active {
            color: #ffffff;
            background-color: #2563eb;
        }

        /* Main Container Wrapper (with smooth page-load fade-in) */
        .main-container {
            max-width: 1320px;
            margin: 0 auto;
            padding: 2.5rem 1.5rem;
            animation: pageFadeIn 0.25s ease-out;
        }

        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .dashboard-card {
            background: var(--panel-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }

        /* Search Box */
        .search-box {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .search-box:focus-within {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        /* Table Styling */
        .table {
            margin-bottom: 0;
            width: 100%;
        }

        .table thead th {
            background: #f8fafc;
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
        }

        .table tbody td {
            padding: 1.1rem 1.25rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }

        .table tbody tr:last-child td {
            border-bottom: none;
        }

        .vehicle-row:hover {
            background-color: #f8fafc;
        }

        /* Avatar Styling */
        .owner-avatar {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid var(--border-color);
            transition: transform 0.2s ease;
        }

        .avatar-placeholder {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #f1f5f9;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            border: 1px solid var(--border-color);
            transition: transform 0.2s ease, background 0.2s ease;
        }

        .hover-zoom:hover {
            transform: scale(1.08);
            background: #e2e8f0;
        }

        /* License Plate Badge */
        .plate-badge {
            background-color: #1e293b;
            color: #38bdf8;
            padding: 0.35rem 0.75rem;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.825rem;
            letter-spacing: 0.05em;
            display: inline-block;
            border: 1px solid #334155;
            font-family: monospace;
        }

        /* Action Buttons */
        .btn-action {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: all 0.2s ease-in-out;
            font-size: 0.95rem;
        }

        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .btn-primary-custom {
            background-color: var(--accent-blue);
            color: #ffffff;
            border: none;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }

        .btn-primary-custom:hover {
            background-color: var(--accent-blue-hover);
            color: #ffffff;
        }

        .btn-report {
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            background: #ffffff;
            font-weight: 600;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-report:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--text-primary);
        }
    </style>
</head>
<body>

<!-- Unified Top Navigation Bar -->
<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container-fluid px-4 d-flex justify-content-between align-items-center">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold m-0" href="dashboard.php">
            <img src="images-removebg-preview.png" alt="KCC Logo" class="navbar-logo" onerror="this.style.display='none'">
            <span class="tracking-brand-text">KCC TRACKING</span>
        </a>

        <div class="d-none d-md-flex align-items-center gap-2">
            <a href="dashboard.php" class="nav-link-custom"><i class="bi bi-house-door me-1"></i> Overview</a>
            <a href="owner_list.php" class="nav-link-custom"><i class="bi bi-people me-1"></i> Owners</a>
            <a href="vehicle_list.php" class="nav-link-custom active"><i class="bi bi-car-front me-1"></i> Vehicles</a>
            <a href="logs.php" class="nav-link-custom"><i class="bi bi-journal-text me-1"></i> Logs</a>
        </div>

        <div class="d-flex align-items-center">
            <a href="logout.php" class="btn btn-outline-danger btn-sm fw-bold px-3 py-2"><i class="bi bi-box-arrow-left me-2"></i>Sign Out</a>
        </div>
    </div>
</nav>

<!-- Main Page Content -->
<main class="main-container">
    <!-- Header Section (same structure as logs.php) -->
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark">Vehicle Fleet</h4>
            <p class="text-muted mb-0 small">Manage active vehicle registrations and owner assignments.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <div class="bg-white px-3 py-2 rounded-3 border d-flex align-items-center">
                <i class="bi bi-car-front-fill me-2 text-primary"></i>
                <span class="small text-muted fw-bold">Total: <?= count($vehicles); ?> Vehicles</span>
            </div>
            <a href="monthlyreport.php" class="btn btn-report rounded-3 px-3 py-2 text-sm d-flex align-items-center">
                <i class="bi bi-file-earmark-bar-graph me-2"></i> Reports
            </a>
        </div>
    </header>

    <!-- Search & Filter Bar -->
    <div class="dashboard-card p-2 mb-4">
        <form method="GET" class="row g-2 align-items-center">
            <div class="col-md-8 col-lg-9">
                <div class="search-box d-flex align-items-center px-3 py-1">
                    <i class="bi bi-search text-muted fs-6 me-2"></i>
                    <input type="text" name="search" class="form-control border-0 shadow-none py-2 bg-transparent text-sm" 
                           placeholder="Search by plate number, owner name, brand, or model..." 
                           value="<?= htmlspecialchars($search); ?>" autocomplete="off">
                </div>
            </div>
            <div class="col-md-4 col-lg-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary-custom w-100 fw-bold py-2 rounded-3 text-sm">Filter</button>
                <?php if(!empty($search)): ?>
                    <a href="vehicle_list.php" class="btn btn-report border w-100 fw-bold py-2 rounded-3 text-sm d-flex align-items-center justify-content-center">Reset</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Vehicles Table Card -->
    <div class="dashboard-card overflow-hidden">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Plate Number</th>
                        <th>Vehicle Details</th>
                        <th>Color</th>
                        <th>Owner</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($vehicles): ?>
                        <?php foreach($vehicles as $v): ?>
                        <tr class="vehicle-row">
                            <td class="ps-4">
                                <span class="plate-badge"><?= htmlspecialchars($v['plate_number'] ?? ''); ?></span>
                            </td>
                            <td>
                                <div class="fw-bold text-dark small"><?= htmlspecialchars(($v['brand'] ?? '') . ' ' . ($v['model'] ?? '')); ?></div>
                                <span class="badge bg-light text-dark border px-2 py-1 small fw-semibold mt-1">
                                    <?= htmlspecialchars($v['vehicle_type'] ?? 'Vehicle'); ?>
                                </span>
                            </td>
                            <td>
                                <span class="text-dark small fw-medium"><?= htmlspecialchars($v['color'] ?? '---'); ?></span>
                            </td>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <?php if(!empty($v['photo']) && file_exists("uploads/" . $v['photo'])): ?>
                                        <img src="uploads/<?= htmlspecialchars($v['photo']); ?>" class="owner-avatar shadow-sm hover-zoom" alt="Owner Avatar">
                                    <?php else: ?>
                                        <div class="avatar-placeholder hover-zoom"><i class="bi bi-person-fill"></i></div>
                                    <?php endif; ?>
                                    <div class="small fw-semibold text-dark">
                                        <?= htmlspecialchars(trim(($v['firstname'] ?? '') . ' ' . ($v['lastname'] ?? '')) ?: 'Unassigned'); ?>
                                    </div>
                                </div>
                            </td>
                            <td class="text-center">
                                <a href="edit_vehicle.php?id=<?= urlencode($v['id']); ?>" class="btn-action bg-warning-subtle text-warning me-1" title="Edit Vehicle">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <a href="delete_vehicle.php?id=<?= urlencode($v['id']); ?>" class="btn-action bg-danger-subtle text-danger" onclick="return confirm('Are you sure you want to remove this vehicle?');" title="Delete Vehicle">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-2 d-block mb-2 text-secondary opacity-50"></i>
                                No matching vehicles found in the fleet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>